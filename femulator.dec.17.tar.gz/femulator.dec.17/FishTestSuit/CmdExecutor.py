import subprocess
import GlobalDefinition
import time
import signal
from SystemcallController import SystemcallController
import os
from SyscallClassifier import SyscallClassifier

class CmdExecutor:
	def __init__(self,systemcallController,resultAnalyzer):
		self.systemcallController = systemcallController
		self.resultAnalyzer = resultAnalyzer
		self.contentToFile = ''
		self.injectionHeader = ''
		self.hasInjection = False
		self.pNameCmd = None
		self.shellProc = None
		self.targetPid = None
		self.actualRetValueWithInjection = None
		self.injectionCmdHook = ''
		self.isFindSyscall = False
		self.syscallName = ''
		self.inType = ''
		self.injectionSuccess = False
		self.removeSuccess = False
		self.inVerifySuccess = False
		self.rmVerifySuccess = False
		self.rowIndex = 0
		self.injectionOut = []
		self.removeOut = []
		self.inVerifyOut = []
		self.rmVerifyOut = []

	def GetProgramValidName(self,pName):
		pureInfoList = self.PureInfoList((pName.split(GlobalDefinition.SPACE_SYMBOL))[0].split('/'))
		return pureInfoList[len(pureInfoList)-1]

	def PureInfoList(self,infoList):
		while('' in infoList):
			infoList.remove('')
		return infoList
			
	def InitializeBeforeRunInjection(self):
		self.contentToFile = ''	
		self.injectionHeader = ''
		self.hasInjection = False	
		self.pNameCmd = None
		self.shellProc = None
		self.targetPid = None
		self.actualRetValueWithInjection = None
		self.injectionCmdHook = ''
		self.isFindSyscall = False
		self.syscallName = ''
		self.injectionSuccess = False
		self.removeSucces = False
		self.inVerifySuccess = False
		self.rmVerifySuccess = False
		self.injectionOut = []
		self.removeOut = []
		self.inVerifyOut = []
		self.rmVerifyOut = []
		pass

	def fillInjectionOthers(self,row):
		partsInfo = self.systemcallController.mapFile.split('p')
		version = partsInfo[len(partsInfo)-1]
		tag = str(version) + 's' + self.inType + '_' + str(row)
		self.resultAnalyzer.XlsWrite(2*row,1,tag)
		self.resultAnalyzer.XlsWrite(2*row,2,'nofault')
		self.resultAnalyzer.XlsWrite(2*row,3,'install')
		self.resultAnalyzer.XlsWrite(2*row,4,'workdir')
		self.resultAnalyzer.XlsWrite(2*row,5,'root')
		if('i' == self.inType):
			self.resultAnalyzer.XlsWrite(2*row,6,'pid_s')
		elif('n' == self.inType):
			self.resultAnalyzer.XlsWrite(2*row,6,'pname_s')
		self.resultAnalyzer.XlsWrite(2*row,7,'shell')
		self.resultAnalyzer.XlsWrite(2*row,8,'insuc,trisuc')	
		self.resultAnalyzer.XlsWrite(2*row,12,'sunya')

		pass

	def fillRemoveOthers(self,row):
		partsInfo = self.systemcallController.mapFile.split('p')
		version = partsInfo[len(partsInfo)-1]
		tag = str(version) + 's' + self.inType+ 'r_' + str(row)
		self.resultAnalyzer.XlsWrite(2*row + 1,1,tag)
		self.resultAnalyzer.XlsWrite(2*row + 1,2,'hastargetfault')
		self.resultAnalyzer.XlsWrite(2*row + 1,3,'install')
		self.resultAnalyzer.XlsWrite(2*row + 1,4,'workdir')
		self.resultAnalyzer.XlsWrite(2*row + 1,5,'root')
		if('i' == self.inType):
			self.resultAnalyzer.XlsWrite(2*row + 1,6,'pid_s')
		elif('n' == self.inType):
			self.resultAnalyzer.XlsWrite(2*row + 1,6,'pname_s')
		self.resultAnalyzer.XlsWrite(2*row + 1,7,'shell')
		self.resultAnalyzer.XlsWrite(2*row + 1,8,'rmsuc,versuc')		
		self.resultAnalyzer.XlsWrite(2*row + 1,12,'sunya')
		pass


	def RunInjectionCmd(self,cmd,cmdIndex):
		self.InitializeBeforeRunInjection()	
		self.rowIndex = cmdIndex
		self.injectionHeader = str(self.InjectionCmdInfo(cmd,cmdIndex))
		self.resultAnalyzer.RecordOutputInfo(self.injectionHeader)
		print(self.injectionHeader)

		if(not isinstance(self.systemcallController,SystemcallController)):
			self.contentToFile += GlobalDefinition.INJECTION_FAIL + ": no systemcallController" + '\n' 
			return GlobalDefinition.INJECTION_FAIL
		try:
			self.actualRetValueWithInjection = self.GetActualRetValueWithoutInjection(cmd)		

			pNameCmd,shellProc,targetPid = self.GenerateWorkloadTargetProc(cmd)
			if(GlobalDefinition.INJECTION_FAIL == pNameCmd):
				return GlobalDefinition.INJECTION_FAIL
		
			cmdByPid = self.GenerateInjectionCmd(cmd,targetPid,pNameCmd)
		
			injectionProc = subprocess.Popen(cmdByPid,shell = True,stdout = subprocess.PIPE,stderr = subprocess.PIPE)
			injectionProc.wait()

			self.resultAnalyzer.XlsWrite(self.rowIndex*2,0,cmdByPid)
			self.fillInjectionOthers(cmdIndex)
			
			self.injectionCmdHook = cmdByPid
			self.hasInjection = True
			self.DealInjectionSuccessfulInfo(injectionProc,cmdByPid)
			self.RunSystemcallCmd(pNameCmd,shellProc,targetPid)
			self.HookSystemcall(pNameCmd,shellProc,targetPid)
			
			return GlobalDefinition.INJECTION_SUCCESS

		except Exception,e:
			self.contentToFile += GlobalDefinition.INJECTION_FAIL + str(e) + '\n'
			return GlobalDefinition.INJECTION_FAIL
	
	
	def RunSystemcallCmd(self,systemcallCmd,shellProc,syscallPid):

		expectedRetValue = self.GetExpectedRetValue(systemcallCmd)
		if(expectedRetValue == GlobalDefinition.INVALID_RET_VALUE_STR):
			return GlobalDefinition.INVALID_RET_VALUE_STR

		os.kill(syscallPid,signal.SIGCONT)
		pass

	def GetActualRetValueWithoutInjection(self,cmd):
		stdout = ''
		stderr = ''
		syscallHook = ''
		try:
			
			faultType = self.systemcallController.GetMappingFaultType(cmd)
			actionId = self.systemcallController.GetFaultActionId(cmd)
			if(faultType != GlobalDefinition.RET_FAULT_TYPE or int(actionId) == 854 ): # 854 is sys_pause
				raise Exception	
		except Exception,e:
			self.contentToFile += '\n not return fault type : do it by hand\n'
			raise e
		try:
			pNameCmd = self.systemcallController.GenerateSyscallCmd(cmd)	
			if(GlobalDefinition.NO_MAPPING_LINE == pNameCmd):
				self.contentToFile += GlobalDefinition.INJECTION_FAIL + ": " + GlobalDefinition.NO_MAPPING_LINE + '\n'
				raise Exception
			syscallWithNoStopCmd = pNameCmd.replace(GlobalDefinition.WITH_STOP_FILE_SUFFIX,GlobalDefinition.NO_STOP_FILE_SUFFIX)
			syscallHook = syscallWithNoStopCmd	
			systemcallProc = subprocess.Popen(syscallWithNoStopCmd,shell = True,stdout = subprocess.PIPE,stderr = subprocess.PIPE)
			systemcallProc.wait()
			stdout = systemcallProc.stdout.readlines()
			stderr = systemcallProc.stderr.readlines()
			actualRetValue = self.GetActualRetValue(stdout[len(stdout) -1])
			self.isFindSyscall = True
			faultActionId = self.systemcallController.GetFaultActionId(cmd)
			self.syscallName = self.systemcallController.GetSyscallName(faultActionId)
			return actualRetValue
			
		except Exception,e:
			syscallFailInfo = '\nGet actual return value without injection fail by exception:' + str(e) + '\n' 
			syscallFailInfo += '\nsyscall program: ' + syscallHook + '\n'
			syscallFailInfo += 'stdout:' + ''.join(stdout)
			syscallFailInfo += 'stderr:' + ''.join(stderr)
			self.resultAnalyzer.RecordSyscallFailInfo(syscallFailInfo + '\n')
			self.contentToFile += syscallFailInfo
			raise e
	
	def HookSystemcall(self,pNameCmd,shellProc,targetPid):
		self.pNameCmd = pNameCmd
		self.shellProc = shellProc
		self.targetPid = targetPid
		pass
	
	def hasSystemcallHooked(self):
		if(None == self.pNameCmd or None == self.shellProc or None == self.targetPid):
			return False
		return True
	
	def GenerateWorkloadTargetProc(self,cmd):
		try:
			pNameCmd = self.systemcallController.GenerateSyscallCmd(cmd)
			if(GlobalDefinition.NO_MAPPING_LINE == pNameCmd):
				self.contentToFile += GlobalDefinition.INJECTION_FAIL + ": " + GlobalDefinition.NO_MAPPING_LINE + '\n'
				raise Exception
				
			self.contentToFile += '\nworkload program:' + pNameCmd + '\n'
			shellProc , targetPid = self.GenerateWorkloadProc(pNameCmd)	# shellPorc is the parent of real target workload process 
			if(GlobalDefinition.INVALID_PID == targetPid):
				self.contentToFile += GlobalDefinition.INJECTION_FAIL + ' can not fork:' + pNameCmd + '\n'
				raise Exception
			
			return pNameCmd,shellProc,targetPid
		except Exception,e:
			raise e

	def GenerateWorkloadProc(self,cmd):
		
		procHook = subprocess.Popen(cmd,shell = True,stdout = subprocess.PIPE,stderr = subprocess.PIPE)
		time.sleep(0.1)#danger
		try:
			targetPid = self.GetRealTargetProcPid(procHook)
			return procHook,targetPid
		except Exception,e:
			raise e
	def GetRealTargetProcPid(self,parentProc):		
	
		queryCmd = 'pstree -p ' + str(parentProc.pid)
		queryProc = subprocess.Popen(queryCmd,shell = True,stdout = subprocess.PIPE,stderr = subprocess.PIPE)	
		queryProc.wait()
		
		output = queryProc.stdout.readlines()
		errput = queryProc.stderr.readlines()
		self.contentToFile += '\npstree output:'+''.join(output)
		self.contentToFile += 'pstree errput:'+''.join(errput) + '\n\n'
		if(len(output) > 1):
			self.contentToFile +='!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!'
			self.contentToFile += ''.join(output)
		if(0 == len(output)):
			self.contentToFile +='!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!'
			self.contentToFile += 'parent pid :' + str(parentProc.pid) + '  no child process'
			return GlobalDefinition.INVALID_PID
		try:		#analyze it with the actual output
			partsInfo = output[0].split(')')
			# pstree output is different format between suse(16) and ubuntu(32,34)
			if('16' in self.systemcallController.mapFile):
				middlePart = partsInfo[0]#suse
			else:
				middlePart = partsInfo[1]#ubuntu
			middlePartInfo = middlePart.split('(')
			finalPart = middlePartInfo[1]		
			return int(finalPart.replace(')','').replace('\n',''))
		except Exception,e:
			self.contentToFile += str(e) + '\nsyscall_emu is not stopped?\n'
			self.contentToFile += '\nworkload stdout(should be no data here):' + ''.join(parentProc.stdout.readlines()) 
			self.contentToFile += '\nworkload stderr(should be no data here):' + ''.join(parentProc.stderr.readlines()) 
			raise e

	def GetExpectedRetValue(self,pName):

		try:
			partsInfoList = pName.split(GlobalDefinition.SPACE_SYMBOL)
			return int(partsInfoList[len(partsInfoList) -1 ])
		except Exception,e:
			self.contentToFile += "invalid pName:" + pName + '\n' + str(e)
			return GlobalDefinition.INVALID_RET_VALUE_STR
 
	def GetActualRetValue(self,outputLine):
		try:
			partsInfoList = outputLine.split(GlobalDefinition.COLON_SYMBOL)
			partsInfoList = self.PureInfoList(partsInfoList)
			return int(partsInfoList[len(partsInfoList) - 1].replace(GlobalDefinition.LINE_SEPERATOR,''))
		except Exception,e:
			self.contentToFile += 'invalid syscall output:\n' + ''.join(outputLine) + str(e)
			raise e
	
	def isActionSuccessful(self,isSuccessful):
		if(False == isSuccessful):
			self.contentToFile += "action fail , checked by syscall\n"
			return False

		self.contentToFile += "action successful , checked by syscall\n"
		return True

	def isSameValue(self,expectedRetValue,actualRetValue):
		try:
			if( expectedRetValue == actualRetValue):
				return True
			return False
		except Exception,e:
			self.contentToFile += str(e)
			raise e
	def GetRemoveCmd(self,injectionCmd):
		if(GlobalDefinition.T1_OPTION in injectionCmd):
			return injectionCmd.replace(GlobalDefinition.T1_OPTION,GlobalDefinition.REMOVE_OPTION)
		if(GlobalDefinition.T2_OPTION in injectionCmd):
			return injectionCmd.replace(GlobalDefinition.T2_OPTION,GlobalDefinition.REMOVE_OPTION)
		return injectionCmd + GlobalDefinition.SPACE_SYMBOL + GlobalDefinition.REMOVE_OPTION

	def RemoveInjection(self):
		if(True == self.hasInjection):
			removeCmd = self.GetRemoveCmd(self.injectionCmdHook)
			removeProc = subprocess.Popen(removeCmd,shell = True,stdout = subprocess.PIPE,stderr = subprocess.PIPE)
			removeProc.wait()
			self.fillRemoveOthers(self.rowIndex)
			self.resultAnalyzer.XlsWrite(self.rowIndex*2 + 1,0,removeCmd)
			self.DealRemoveInjectionInfo(removeProc,removeCmd)
			self.CheckRemoveSuccessful()
		else:
			self.contentToFile += '<<<<<<<<<<<<<<<<<<<<<<<<<<<remove<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n'
			self.contentToFile += 'no injection,so no removing\n'			
			return GlobalDefinition.ACTION_SUCCESS

	def DealRemoveInjectionInfo(self,removeProc,removeCmd):
		removeSeperator = '<<<<<<<<<<<<<<<<<<<<<<<<<<<remove<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n'		
		output,errOut = removeProc.communicate()
		self.removeOut = output
		if('succeed' in output):
			self.removeSuccess = True
		self.DealEachSegmentInfo(output,errOut,removeCmd,removeSeperator)
	
	def CheckRemoveSuccessful(self):
		if(not self.hasSystemcallHooked()):
			self.contentToFile += '\nsystemcall hook fail\n'
			return GlobalDefinition.ACTION_FAIL

		try:
			self.RunSystemcallCmd(self.pNameCmd,self.shellProc,self.targetPid)
		except Exception,e:

			return GlobalDefinition.ACTION_FAIL
	def fillActualResult(self):
		if(not self.injectionSuccess and not self.inVerifySuccess):
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,9,'infail,verfail')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,13,'exist')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,14,''.join(self.injectionOut) + '\n' + ''.join(self.inVerifyOut))
		if(not self.injectionSuccess and self.inVerifySuccess):
			self.resultAnalyzer,XlsWrite(self.rowIndex*2,9,'infail,versuc')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,13,'exist')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,14,''.join(self.injectionOut) + '\n' + ''.join(self.inVerifyOut))
		if(self.injectionSuccess and not self.inVerifySuccess):
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,9,'insuc,verfail')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,13,'exist')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,14,''.join(self.injectionOut) + '\n' + ''.join(self.inVerifyOut))
		if( self.injectionSuccess and self.inVerifySuccess):
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,9,'insuc,versuc')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,13,'none')

		if(not self.removeSuccess and not self.rmVerifySuccess):
			self.resultAnalyzer.XlsWrite(self.rowIndex*2 + 1,9,'rmfail,verfail')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2+1,13,'exist')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2+1,14,''.join(self.removeOut) + '\n' + ''.join(self.rmVerifyOut))
		if(not self.removeSuccess and self.rmVerifySuccess):
			self.resultAnalyzer.XlsWrite(self.rowIndex*2 + 1,9,'rmfail,versuc')	
			self.resultAnalyzer.XlsWrite(self.rowIndex*2+1,13,'exist')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2+1,14,''.join(self.removeOut) + '\n' + ''.join(self.rmVerifyOut))
		if(self.removeSuccess and not self.rmVerifySuccess):
			self.resultAnalyzer.XlsWrite(self.rowIndex*2 + 1,9,'rmsuc,verfail')	
			self.resultAnalyzer.XlsWrite(self.rowIndex*2+1,13,'exist')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2+1,14,''.join(self.removeOut) + '\n' + ''.join(self.rmVerifyOut))
		if(self.removeSuccess and self.rmVerifySuccess):
			self.resultAnalyzer.XlsWrite(self.rowIndex*2 + 1,9,'rmsuc,versuc')	
			self.resultAnalyzer.XlsWrite(self.rowIndex*2+1,13,'none')
		
		pass
		

	def VerifySystemcallOutput(self):	

		try:		
			self.contentToFile += '\n=============================verify injection and remove action===============================\n'
			if(not self.hasSystemcallHooked()):
				raise Exception

			output = self.shellProc.stdout.readlines()
			errput = self.shellProc.stderr.readlines()

			self.contentToFile += 'system call pid:'+ str(self.targetPid) + '\n'
			self.contentToFile += '\nsyscall stdout:\n' + ''.join(output)
			self.contentToFile += '\nsyscall stderr:\n' + ''.join(errput)
		
			injectionRetOutput,removeRetOurput = self.GetSystemcallRetOutput(output)
			expectedRetValue = self.GetExpectedRetValue(self.pNameCmd)
			
			isInjectionSuccessful = self.isInjectionActionSuccessful(injectionRetOutput,expectedRetValue)
			isRemoveSuccessful = self.isRemoveActionSuccessful(removeRetOurput)
			
			self.inVerifySuccess = isInjectionSuccessful
			self.rmVerifySuccess = isRemoveSuccessful

			isSuccessful = isInjectionSuccessful and isRemoveSuccessful
			if( False == isSuccessful and True == self.isFindSyscall ):
				self.resultAnalyzer.RecordInjectionFailInfo(self.injectionHeader)
				self.resultAnalyzer.RecordInjectionFailInfo(self.contentToFile)
				self.fillActualResult()
				self.resultAnalyzer.XlsSave()

				return GlobalDefinition.ACTION_FAIL
			self.fillActualResult()
			self.resultAnalyzer.XlsSave()
			return GlobalDefinition.ACTION_SUCCESS
			
		except Exception,e:
			self.contentToFile += '\naction fail by exception:' + str(e)
			if(True == self.isFindSyscall):
				self.resultAnalyzer.RecordInjectionFailInfo(self.injectionHeader)
				self.resultAnalyzer.RecordInjectionFailInfo(self.contentToFile)
				self.fillActualResult()
				self.resultAnalyzer.XlsSave()
			return GlobalDefinition.ACTION_FAIL
			
	def GetSystemcallRetOutput(self,systemcallOutput):
		try:		
			injectionRetOutput = ''
			removeRetOurput = ''	
			for index in range(0,len(systemcallOutput)):
				if(GlobalDefinition.INJECTION_OUTPUT_TAG == systemcallOutput[index]):
					injectionRetOutput = systemcallOutput[index + 1]
				if(GlobalDefinition.REMOVE_OUTPUT_TAG == systemcallOutput[index]):
					removeRetOurput = systemcallOutput[index + 1]

			return injectionRetOutput,removeRetOurput
		except Exception,e:
			raise e

	def isInjectionActionSuccessful(self,injectionRetOutput,expectedRetValue):
		try:
			if(''==injectionRetOutput ):
				 self.contentToFile += '\ninjection to systemcall no output: so fail\n'
				 self.inVerifyOut = ['injection to systemcall no output: so fail']
			else:
				self.contentToFile += '\nExpected ret value: ' + str(expectedRetValue) + '\n'
				self.inVerifyOut = ['Expected ret value: ' + str(expectedRetValue)]
				self.inVerifyOut.append('\n' + injectionRetOutput)
				self.contentToFile += 'injection to systemcall output:\n' + injectionRetOutput 
				actualRetValue = self.GetActualRetValue(injectionRetOutput)
				injectionSuccessful = self.isSameValue(expectedRetValue,self.ChangeActualRetValueByRetRule(actualRetValue))
				return self.isActionSuccessful(injectionSuccessful)
		except Exception,e:
				raise e
	
	def ChangeActualRetValueByRetRule(self,retValue):
		return -retValue

		
	def isRemoveActionSuccessful(self,removeRetOurput):
		try:
			if(''==removeRetOurput ):
				self.contentToFile += '\nremove injection to systemcall  no output: so fail\n'
				self.rmVerifyOut = ['remove injection to systemcall  no output: so fail']
			else:
				self.contentToFile += '\nAcutal ret value without before injection: ' + str(self.actualRetValueWithInjection) + '\n'
				self.rmVerifyOut = ['Acutal ret value without before injection: ' + str(self.actualRetValueWithInjection) + '\n']
				self.rmVerifyOut.append('\nremove injection to systemcall output:\n' + removeRetOurput )
				self.contentToFile += 'remove injection to systemcall output:\n' + removeRetOurput 
				removeSuccessful = self.isSameValue(self.actualRetValueWithInjection,self.GetActualRetValue(removeRetOurput))
				return self.isActionSuccessful(removeSuccessful)
		except Exception,e:
			raise e
		
		
		return GlobalDefinition.OPEN_FILE_SUCCESS
	
	
	def InjectionCmdInfo(self,cmd,cmdIndex):
		return '\n\n\nCmdIndex:' + str(cmdIndex) + ' >>>>>>>>>>>>>>injection  Cmd:' + cmd + '>>>>>>>>>>>>>>>>>>>>>>>>>> ' + '\n'	

	def DealEachSegmentInfo(self,output,errOut,cmd,seperator):	
		self.contentToFile += seperator + 'Cmd:' + cmd + '\n' + 'errOut:' + ''.join(errOut) + '\nstdout:' + ''.join(output)
		return output


	def DealInjectionSuccessfulInfo(self,injectionProc,cmd):
		seperator = ''	
		output,errOut = injectionProc.communicate()
		self.injectionOut = output
		if('succeed' in output):
			self.injectionSuccess = True
		self.DealEachSegmentInfo(output,errOut,cmd,seperator)


