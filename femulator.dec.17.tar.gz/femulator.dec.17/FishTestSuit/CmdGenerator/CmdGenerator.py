global EXECUTION_FILE_PATH
EXECUTION_FILE_PATH = '/home/ub/FEmulator/fish'

global INJECTION_OPTION 
INJECTION_OPTION = '-i'

global SPACE_SYMBOL 
SPACE_SYMBOL = str(' ')
global COLON_SYMBOL
COLON_SYMBOL = ':'
global LINE_SEPERATOR
LINE_SEPERATOR = '\n'

global OPEN_FILE_FAIL
OPEN_FILE_FAIL = 'open file fail!\n'
global INDICATOR_FILE_WRONG_CONTENT
INDICATOR_FILE_WRONG_CONTENT = 'indicator file wrong content!\n'

global CMD_QUANTITY_LINE_INDEX
CMD_QUANTITY_LINE_INDEX = 0

class CmdGenerator:
	def __init__(self,indicatorFile,cmdOutputFile):
		self.indicatorFile = indicatorFile
		self.cmdOutputFile = cmdOutputFile
	
	def GenerateCmdOutputFile(self):
		cmdQuantity = self.__GetCmdQuantityNumber()
		if(INDICATOR_FILE_WRONG_CONTENT == 	cmdQuantity):
			return 	INDICATOR_FILE_WRONG_CONTENT

		cmdOutputFile = open(self.cmdOutputFile,'a+')
		if(not cmdOutputFile):
			return OPEN_FILE_FAIL + self.cmdOutputFile + LINE_SEPERATOR
		
		for index in range(0,cmdQuantity):
			cmdOutputFile.write(self.GenerateCmdWithPid() + LINE_SEPERATOR)
		
		cmdOutputFile.close()
		
		return cmdQuantity
		

	def __GetCmdQuantityNumber(self):
		quantityLine = self.__GetCmdQuantityLine()
		if(INDICATOR_FILE_WRONG_CONTENT == quantityLine):
			return INDICATOR_FILE_WRONG_CONTENT
		
		parts = quantityLine.split(COLON_SYMBOL)
		if(len(parts) < 2):	
			return 	INDICATOR_FILE_WRONG_CONTENT
		
		return int(parts[1])

	def __GetCmdQuantityLine(self):
		return self.__GetFileLineByIndex(self.indicatorFile,CMD_QUANTITY_LINE_INDEX)

	def __GetFileLineByIndex(self,fileName,index):
		cmdGenerationIndicator = open(fileName,'r')
		if(not cmdGenerationIndicator):
			return OPEN_FILE_FAIL + self.indicatorFile + LINE_SEPERATOR
		lines = cmdGenerationIndicator.readlines()
		cmdGenerationIndicator.close()

		if(index >= len(lines) ):
			return INDICATOR_FILE_WRONG_CONTENT

		return lines[index].replace(LINE_SEPERATOR,'')	
		
	def __GenerateFaultId(self):
		return str(339)
	
	def __GeneratePid(self):
		return str(1944)
	
	def __GenerateProcessName(self):
		return 'pidName'
	
	def __GenerateFileName(self):
		return 'textFile'
	
	def GenerateCmdWithPid(self):
		return EXECUTION_FILE_PATH + SPACE_SYMBOL + INJECTION_OPTION + SPACE_SYMBOL + self.__GenerateFaultId() +  SPACE_SYMBOL + '-p' + SPACE_SYMBOL + self.__GeneratePid() + SPACE_SYMBOL

	def GenerateCmdWithProcessName(self):
		return EXECUTION_FILE_PATH + SPACE_SYMBOL + INJECTION_OPTION + SPACE_SYMBOL + self.__GenerateFaultId() +  SPACE_SYMBOL +  '-n' + SPACE_SYMBOL + self.__GenerateProcessName() + SPACE_SYMBOL

	def __GenerateFname(self):
		return 'fname'	

	def AddFnameToCmd(self,cmd):
		return cmd + SPACE_SYMBOL +  '-f' + SPACE_SYMBOL + self.__GenerateFname()

	
		
