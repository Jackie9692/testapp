from CmdGenerator import CmdGenerator


global CMD_GENERATION_INDICATION_FILE
CMD_GENERATION_INDICATION_FILE = 'CmdGenerationIndicator.txt'
global CMD_OUTPUT_FILE
CMD_OUTPUT_FILE = 'CmdOutput.txt'

cmdGenerator = CmdGenerator(CMD_GENERATION_INDICATION_FILE,CMD_OUTPUT_FILE )
cmdGenerator.GenerateCmdOutputFile()


