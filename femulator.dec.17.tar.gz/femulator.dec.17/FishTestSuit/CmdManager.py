import GlobalDefinition
import random

class CmdManager:
	def __init__(self,cmdFileName,targetCmdIndex):
		self.cmdFileName = cmdFileName
		self.nextCmdIndex = 0
		self.cmdFileHandle = None
		self.isMissionComplete = False
		self.AdjustFileCursorForTargetCmd(targetCmdIndex)

	def __del__(self):
		self.CleanFileHandle()
	
	@property
	def nextCmdIndex(self):
		return self.nextCmdIndex
	@property
	def isMissionComplete(self):
		return self.isMissionComplete

	def AdjustFileCursorForTargetCmd(self,targetCmdIndex):
		if(targetCmdIndex < 0):
			return GlobalDefinition.CURSOR_INDEX_INVALID

		self.CleanFileHandle()

		self.cmdFileHandle = open(self.cmdFileName,'r')
		if(not self.cmdFileHandle):
			self.cmdFileHandle = None
		
		self.nextCmdIndex = self.AdjustCursor(targetCmdIndex)

		return GlobalDefinition.ADJUST_SUCCESS 
	
	def GetNextCmd(self):
		if(None == self.cmdFileHandle):
			return GlobalDefinition.INVALID_FILE

		nextCmd = self.cmdFileHandle.readline()

		if(self.isEOF(nextCmd)):
			self.isMissionComplete = True
			return nextCmd

		self.nextCmdIndex += 1
		
		nextCmd = nextCmd.replace(GlobalDefinition.LINE_SEPERATOR,'')
		return nextCmd

	def isEOF(self,line):
		return '' == line

	def CleanFileHandle(self):	
		if(None != self.cmdFileHandle):
			self.cmdFileHandle.close()
			self.cmdFileHandle = None

	def AdjustCursor(self,targetCmdIndex):
		index = 0
		while(index < targetCmdIndex):
			if(self.isEOF(self.cmdFileHandle.readline())):
				self.isMissionComplete = True
				return index
			index += 1

		return targetCmdIndex

	
