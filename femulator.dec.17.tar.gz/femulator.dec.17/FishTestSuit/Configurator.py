import GlobalDefinition
from InjectionTracer import InjectionTracer 
from CmdManager import CmdManager 
from PNameCmdExecutor import PNameCmdExecutor 
from PidCmdExecutor import PidCmdExecutor 
from SystemcallController import SystemcallController
from ResultAnalyzer import ResultAnalyzer

class Configurator:
	def __init__(self,configurationFileName,mapFileKey,unistdFileKey,executorType):
		self.configurationFileName = configurationFileName
		self.mapFileKey = mapFileKey
		self.unistdFileKey = unistdFileKey
		self.executorType = executorType
	
	def GetDataFilePaths(self):
		dataFile = open(self.configurationFileName,'r')
		if(not dataFile):
			return {} #empty dictionary
		configurationInfo = dataFile.readlines()
		dataFile.close()

		return self.__GenerateFilePathsDictionaryByFile(configurationInfo)
	
	def __GenerateFilePathsDictionaryByFile(self,configurationInfo):
		filePathsDict = {}
		for line in configurationInfo:
			if(len(line) == 0 ):
				continue
			if(GlobalDefinition.ANNOTATION_SYMBOL == line[0]):
				continue

			parts = line.split(GlobalDefinition.COLON_SYMBOL)
			if(len(parts) > 1):
				filePathsDict[parts[GlobalDefinition.KEY_INDEX]] = parts[GlobalDefinition.VALUE_INDEX].replace('\n','')

		return filePathsDict

	def GetEachModule(self):
		
		try:
			filePathsDict = self.GetDataFilePaths()
			print(filePathsDict)			

			injectionTracer = InjectionTracer(filePathsDict[GlobalDefinition.TRACE_FILE_KEY])

			cmdManager = CmdManager(filePathsDict[GlobalDefinition.COMMAND_FILE_KEY],injectionTracer.ReadNextCmdIndex())

			systemcallController = SystemcallController(filePathsDict[GlobalDefinition.SYSTEMCALL_EMU_FILE_KEY],filePathsDict[self.mapFileKey],filePathsDict[self.unistdFileKey])#DEBUG ME LATER:creator factory instead
			
			executor = self.CreateExecutor(filePathsDict,systemcallController,self.executorType)
			self.executorRef = executor
		
			return injectionTracer,cmdManager,systemcallController,executor

		except Exception,e:
			print(e)
			raise e

	def CreateExecutor(self,filePathsDict,systemcallController,executorType):
		try:
			if(GlobalDefinition.PID_EXECUTOR_TYPE == executorType):
			
				resultAnalyzer = ResultAnalyzer(filePathsDict[GlobalDefinition.PID_RESULT_FILE_KEY],filePathsDict[GlobalDefinition.PID_INJECTION_FAIL_FILE_KEY ],filePathsDict[GlobalDefinition.PID_SYSCALL_FAIL_FILE_KEY])
				return PidCmdExecutor(systemcallController,resultAnalyzer)

			if(GlobalDefinition.PNAME_EXECUTOR_TYPE == executorType):
				resultAnalyzer = ResultAnalyzer(filePathsDict[GlobalDefinition.PNAME_RESULT_FILE_KEY],filePathsDict[GlobalDefinition.PNAME_INJECTION_FAIL_FILE_KEY ],filePathsDict[GlobalDefinition.PNAME_SYSCALL_FAIL_FILE_KEY])
				return PNameCmdExecutor(systemcallController,resultAnalyzer)
	
			return None
		except Exception,e:
			print(e)
			raise e

		
