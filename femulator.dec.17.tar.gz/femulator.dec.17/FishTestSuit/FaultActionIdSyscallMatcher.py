from SystemcallController import SystemcallController
import GlobalDefinition

class FaultActionIdSyscallMatcher:
	def __init__(self):
		self.mappingResultFile = 'DataFiles/mappingResult.txt'
		self.mapFile = '../lib/map64.34'
		self.commandFile = 'DataFiles/command.txt'
	
	def FaultActionIdSyscallMappingCheck(self):
		
		systemcallController = SystemcallController('',self.mapFile,'')
		commandFileHandler = open(self.commandFile,'r')
		
		cmdLines = commandFileHandler.readlines()
		for index in range(0,len(cmdLines)):
			cmd = cmdLines[index]
			mappingResult = systemcallController.GenerateSyscallCmd(cmd)
			
		print('check done!\n')
		commandFileHandler.close()
		
	
	
