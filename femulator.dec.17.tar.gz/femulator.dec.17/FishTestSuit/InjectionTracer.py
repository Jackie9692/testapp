import GlobalDefinition
import os

class InjectionTracer:
	def __init__(self,traceFileName):
		self.traceFileName = traceFileName

	def ReadNextCmdIndex(self):	

		line = self.__ReadLineByIndex(GlobalDefinition.COMMAND_INDEX_TRACE_LINE_INDEX )
		return self.__ParseLineToGetIndex(line)

	def ReadLastCommandStatus(self):

		line = self.__ReadLineByIndex(GlobalDefinition.LAST_COMMAND_STATUS_TRACE_LINE_INDEX)
		return self.__ParseLineToGetLastCmdStatus(line)
	
	def __ReadLineByIndex(self,index):
		traceFile = open(self.traceFileName,'r')
		if(not traceFile):
			return GlobalDefinition.OPEN_FILE_FAIL 
		
		lines = traceFile.readlines()
		traceFile.close()

		if(index >= len(lines)):
			return GlobalDefinition.FILE_END_LINE

		return lines[index].replace(GlobalDefinition.LINE_SEPERATOR,'')

	def WriteNextCmdIndex(self,nextCmdIndex):		

		statusline = self.__ReadLineByIndex(GlobalDefinition.LAST_COMMAND_STATUS_TRACE_LINE_INDEX)
		statusline = statusline + GlobalDefinition.LINE_SEPERATOR

		traceFile = os.open(self.traceFileName,os.O_SYNC|os.O_WRONLY)
		if(not traceFile):
			return GlobalDefinition.OPEN_FILE_FAIL

		os.write(traceFile,statusline)
		os.write(traceFile,self.__GetCmdIndexTraceLineInfo(nextCmdIndex))
		os.close(traceFile)

		return GlobalDefinition.TRACE_SUCCESSFUL_STR
	
	def WriteLastCmdStatus(self,lastCmdStatus):

		indexline = self.__ReadLineByIndex(GlobalDefinition.COMMAND_INDEX_TRACE_LINE_INDEX )
		indexline = indexline + GlobalDefinition.LINE_SEPERATOR

		traceFile = os.open(self.traceFileName,os.O_SYNC|os.O_WRONLY)
		if(not traceFile):
			return GlobalDefinition.OPEN_FILE_FAIL
		
		os.write(traceFile,self.__GetLastCmdStatusTraceLineInfo(lastCmdStatus))
		os.write(traceFile,indexline)
		os.close(traceFile)

		return GlobalDefinition.TRACE_SUCCESSFUL_STR

	def __GetCmdIndexTraceLineInfo(self,nextCmdIndex):
		return "next command index:" + str(nextCmdIndex) + GlobalDefinition.LINE_SEPERATOR
	def __GetLastCmdStatusTraceLineInfo(self,lastCmdStatus):
		return "last command status:" + str(lastCmdStatus) + GlobalDefinition.LINE_SEPERATOR

	def __ParseLineToGetContent(self,line):
		if(None == line):
			return GlobalDefinition.INVALID_INDEX
		
		infoParts = line.split(GlobalDefinition.COLON_SYMBOL)
		if(len(infoParts) < 2):
			return GlobalDefinition.INVALID_INDEX
		return infoParts[1]
	
	def __ParseLineToGetIndex(self,line):
		return int(self.__ParseLineToGetContent(line))
	
	def __ParseLineToGetLastCmdStatus(self,line):
		return str(self.__ParseLineToGetContent(line))
