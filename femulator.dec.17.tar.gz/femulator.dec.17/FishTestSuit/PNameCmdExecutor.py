from CmdExecutor import CmdExecutor
from SystemcallController import SystemcallController
import subprocess
import signal
import os
import time
import GlobalDefinition
from SyscallClassifier import SyscallClassifier

class PNameCmdExecutor(CmdExecutor):
	def __init__(self,systemcallController,resultAnalyzer):
		CmdExecutor.__init__(self,systemcallController,resultAnalyzer)
		self.inType = 'p'
		pass

	def GenerateInjectionCmd(self,cmd,pid,pName):
		return cmd +  GlobalDefinition.SPACE_SYMBOL +  GlobalDefinition.INJECTION_BY_PNAME_OPTION + GlobalDefinition.SPACE_SYMBOL + str(self.GetProgramValidName(pName)) + GlobalDefinition.SPACE_SYMBOL# + SyscallClassifier.GetTOptionBySyscall(self.syscallName,self.systemcallController.GetBitVersion())#by pName

		
	
	


	


	
	
	
	
	
	


