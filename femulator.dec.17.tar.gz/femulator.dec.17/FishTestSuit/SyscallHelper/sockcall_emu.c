#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>

int main(int argc, char *argv[])
{
        int flag;
        char *callname;
        int ret, retval, myerrno;
        if (argc < 2) {
                puts("usage: sockcall_emu <sockcall> <retval>");
                return -1;
        }
        callname = argv[1] + 4;
        retval = atoi(argv[2]);
		
        ret = -1;
        errno = 0;
        if (strcmp(callname, "sendto") == 0)
                callname = "sent";
        else if (strcmp(callname, "recvfrom") == 0)
                callname = "recf";
        else if (strcmp(callname, "sendmsg") == 0)
                callname = "senm";
        else if (strcmp(callname, "recvmsg") == 0)
                callname = "recm";
        else if (strcmp(callname, "socketpair") == 0)
                callname = "socp";
        else if (strcmp(callname, "getsockopt") == 0)
                callname = "geto";
        flag = htonl(*(int *)callname);

		int counter = 0;
		while(counter < 2){
			if(0 == counter){
				printf("injection:\n");			
			}
			if(1 == counter){
				printf("remove injection:\n");
			}
		    switch (flag)
		    {
		    case (int)'sock':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = socket(0, 0, 0);
		            break;
		    case (int)'bind':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = bind(0, 0, 0);
		            break;
		    case (int)'conn':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = connect(0, 0, 0);
		            break;
		    case (int)'list':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = listen(0, 0, 0);
		            break;
		    case (int)'acce':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = accept(0, 0, 0);
		            break;
		    case (int)'gets':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = getsockname(0, 0, 0);
		            break;
		    case (int)'getp':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = getpeername(0, 0, 0);
		            break;
		    case (int)'socp':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = socketpair(0, 0, 0);
		            break;
		    case (int)'send':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = send(0, 0, 0);
		            break;
		    case (int)'recv':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = recv(0, 0, 0);
		            break;
		    case (int)'sent':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = sendto(0, 0, 0);
		            break;
		    case (int)'recf':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = recvfrom(0, 0, 0);
		            break;
		    case (int)'shut':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = shutdown(0, 0, 0);
		            break;
		    case (int)'sets':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = setsockopt(0, 0, 0);
		            break;
		    case (int)'geto':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = getsockopt(0, 0, 0);
		            break;
		    case (int)'senm':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = sendmsg(0, 0, 0);
		            break;
		    case (int)'recm':
					kill(getpid(),SIGSTOP);//stop before real syscall
		            ret = recvmsg(0, 0, 0);
		            break;
		    }
	
		    myerrno = errno;

		    printf("return: %d errno: %d\n", ret, myerrno);
		    perror("sockcall");
			++counter;
		}

        if (myerrno != retval*-1) {
                return -1;
        }

        return 0;
}

