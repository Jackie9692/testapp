#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>


static char grep_word[256];
static char buffer[256];

int main(int argc, char *argv[])
{
        FILE *fp;
        int ret, num, retval, fd, fd_pos;
        char *sys_call, *uni_filename, *filename;
				
	
        if (argc < 4) {
				printf("before argc\n");
                puts("usage: <unistd.h> <sys_call> <retval> [filename] [position]");
                return -1;
        }
        sys_call = argv[2] + 4;
        uni_filename = argv[1];
        fd = -1;
        filename = NULL;
        fd_pos = 0;
        retval = atoi(argv[3]);
        if (argc == 6) {
                filename = argv[4];
                fd_pos = atoi(argv[5]);
        }

        sprintf(grep_word, "grep -E \"#define __NR_%s[[:space:]]+[0-9]*$\" %s", sys_call, uni_filename);
        //puts(grep_word);

		
        fp = popen(grep_word, "r");
        if (fp == NULL) {
                perror("popen");
				printf("before popen\n");
                return -1;
        }
        fscanf(fp, "#define %s %d", buffer, &num);
        pclose(fp);

        /* __NR_*** */
        if (strcmp(buffer + 5, sys_call) != 0) {
				printf("before strcmp\n");
                fprintf(stderr, "can not find sys_%s\n", sys_call);
                return -2;
        }

        printf("%s, %d\n", buffer, num);

        if (filename) {
                fd = open(filename, O_CREAT);
                if (fd == -1) {
                        perror("open");
                        return -1;
                }
        }

        printf("fd_pos: %d\n", fd_pos);
		
		int counter = 0;
		while(counter < 2){
			if(0 == counter){
				printf("injection:\n");			
			}
			if(1 == counter){
				printf("remove injection:\n");
			}
			 switch (fd_pos) {
				case 1:
						kill(getpid(),SIGSTOP);//stop before real syscall
				        ret = syscall(num, fd, 0x55667788, 0x99aabbcc, 0xddeeff00, 0x12345678, 0x9abcdef0);
						printf("sys_%s return: %d errno: %d\n", sys_call, ret, errno);
			  			perror(sys_call);
				        break;
				case 2:
						kill(getpid(),SIGSTOP);//stop before real syscall
				        ret = syscall(num, 0x11223344, fd, 0x99aabbcc, 0xddeeff00, 0x12345678, 0x9abcdef0);
						printf("sys_%s return: %d errno: %d\n", sys_call, ret, errno);
			   			perror(sys_call);
				        break;
				case 3:
						kill(getpid(),SIGSTOP);//stop before real syscall
				        ret = syscall(num, 0x11223344, 0x55667788, fd, 0xddeeff00, 0x12345678, 0x9abcdef0);
						printf("sys_%s return: %d errno: %d\n", sys_call, ret, errno);
			   			perror(sys_call);
				        break;
				case 4:
						kill(getpid(),SIGSTOP);//stop before real syscall
				        ret = syscall(num, 0x11223344, 0x55667788, 0x99aabbcc, fd, 0x12345678, 0x9abcdef0);
						printf("sys_%s return: %d errno: %d\n", sys_call, ret, errno);
			 			perror(sys_call);
				        break;
				case 5:
						kill(getpid(),SIGSTOP);//stop before real syscall
				        ret = syscall(num, 0x11223344, 0x55667788, 0x99aabbcc, 0xddeeff00, fd, 0x9abcdef0);
						printf("sys_%s return: %d errno: %d\n", sys_call, ret, errno);
			   			perror(sys_call);
				        break;
				case 6:
						kill(getpid(),SIGSTOP);//stop before real syscall
				        ret = syscall(num, 0x11223344, 0x55667788, 0x99aabbcc, 0xddeeff00, 0x12345678, fd);
						printf("sys_%s return: %d errno: %d\n", sys_call, ret, errno);
			   			perror(sys_call);
				        break;
				default:
						kill(getpid(),SIGSTOP);//stop before real syscall
				        ret = syscall(num, 0x11223344, 0x55667788, 0x99aabbcc, 0xddeeff00, 0x12345678, 0x9abcdef0);
						printf("sys_%s return: %d errno: %d\n", sys_call, ret, errno);
						perror(sys_call);
				        break;
			}
			++counter;

		}

       

        if (fd > 0 && close(fd) < 0) {
                perror("warning: close");
        }

        if (errno != 0 && ret == -1 || ret == -1 && errno != retval) {
                return -1;
        }

        return 0;
}

