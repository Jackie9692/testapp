from Configurator import Configurator 
from InjectionTracer import InjectionTracer 
from CmdManager import CmdManager  
from SystemcallController import SystemcallController
from ResultAnalyzer import ResultAnalyzer
import GlobalDefinition

class TestController:
	
	def __init__(self,configurator):
		self.executorRef = None
		self.configurator = configurator
		pass

	def StartTest(self):
		try:
			injectionTracer,cmdManager,systemcallController,executor = self.configurator.GetEachModule()

			while(not cmdManager.isMissionComplete):
				if(GlobalDefinition.LAST_COMMAND_DIE == injectionTracer.ReadLastCommandStatus()):
					self.__ActionForLastDeadCmd(executor,cmdManager,injectionTracer)
					continue

				self.__ActionForLastSurviveCmd(executor,cmdManager,injectionTracer)
			
			print('all commands testing done!\n')
		
		except Exception, e:
			if(None != self.executorRef):
				self.executorRef.RecordResultInfo(str(e))
			print e

	def __ActionForLastDeadCmd(self,executor,cmdManager,injectionTracer):

		executor.resultAnalyzer.RecordOutputInfo("\nthis command die!!!\n")
		cmdManager.AdjustFileCursorForTargetCmd(cmdManager.nextCmdIndex + 1)
		injectionTracer.WriteNextCmdIndex(cmdManager.nextCmdIndex)
		injectionTracer.WriteLastCmdStatus(GlobalDefinition.LAST_COMMAND_SURVIVE)
	
	def __ActionForLastSurviveCmd(self,executor,cmdManager,injectionTracer):
		nextCmd = cmdManager.GetNextCmd()
		if(GlobalDefinition.FILE_END_LINE == nextCmd):		#invalid command
			return nextCmd

		injectionTracer.WriteLastCmdStatus(GlobalDefinition.LAST_COMMAND_DIE)
		executor.RunInjectionCmd(nextCmd,cmdManager.nextCmdIndex - 1)
		injectionTracer.WriteLastCmdStatus(GlobalDefinition.LAST_COMMAND_SURVIVE)

		injectionTracer.WriteNextCmdIndex(cmdManager.nextCmdIndex)

		executor.RemoveInjection()
		executor.VerifySystemcallOutput()
		executor.resultAnalyzer.RecordOutputInfo(executor.contentToFile)
		print(executor.contentToFile)
	


