import sys
sys.path.append('../TestSuitBase/')
sys.path.append('../FishTestSuit/')

from FaultActionIdSyscallMatcher import FaultActionIdSyscallMatcher

matcher = FaultActionIdSyscallMatcher()
matcher.FaultActionIdSyscallMappingCheck()
