import subprocess
import GlobalDefinition
import time
import signal
from SystemcallController import SystemcallController
import os
from SyscallClassifier import SyscallClassifier

global FISH_CMD_PREFIX
FISH_CMD_PREFIX = '/home/ub/Desktop/FEmulator/fish -i '
global INVALID_EXPECTED_RET_VALUE
INVALID_EXPECTED_RET_VALUE = 10101
global FISH_REMOVE_CMD
FISH_REMOVE_CMD = '/home/ub/Desktop/FEmulator/fish -q'

class MultiExecutor:
	def __init__(self,systemcallController,resultAnalyzer):
		self.systemcallController = systemcallController
		self.resultAnalyzer = resultAnalyzer
		self.contentToFile = ''
		self.injectionHeader = ''
		self.hasInjection = False
		self.pNameCmd = None
		self.shellProc = None
		self.targetPid = None
		self.actualRetValueWithInjection = None
		self.injectionCmdHook = ''
		self.isFindSyscall = False
		self.syscallName = ''
		self.actualRetValueDict = {}
		self.expectedRetValueDict = {}
		self.injectionCmdList = []
		self.inType = ''
		self.injectionSuccess = True
		self.removeSuccess = True
		self.inVerifySuccess = True
		self.rmVerifySuccess = True
		self.rowIndex = 0
		self.injectionOut = []
		self.removeOut = []
		self.inVerifyOut = []
		self.rmVerifyOut = []

	
	#public 

	def GetProgramValidName(self,pName):
		pureInfoList = self.PureInfoList((pName.split(GlobalDefinition.SPACE_SYMBOL))[0].split('/'))
		return pureInfoList[len(pureInfoList)-1]

	def RunInjectionCmdList(self,mappingList,counter):
		
		try:
			self.InitializeBeforeRunInjection()
			self.rowIndex = counter
			self.actualRetValueDict = {}
			self.expectedRetValueDict = {}
			self.injectionHeader =  self.InjectionHeader(counter)	
			self.contentToFile += self.injectionHeader

			cmdByPidList,syscallNameList = self.GetValidInjectionTestList(mappingList)
			self.DoInjectionCmdList(cmdByPidList)
			self.ContinueTargetWorkload()
			time.sleep(0.05)
			#self.RemoveInjection()
			self.RemoveInjectionByM()
			self.ContinueTargetWorkload()
			self.VerifySystemcallOutput()
			self.fillActualResult()
			self.resultAnalyzer.XlsSave()
			self.resultAnalyzer.RecordOutputInfo(self.contentToFile)
			print(self.contentToFile)
			
		except Exception,e:
			self.contentToFile += GlobalDefinition.INJECTION_FAIL  + '\n' + str(e) + '\n'
			print(self.contentToFile)
			return GlobalDefinition.INJECTION_FAIL

	def VerifySystemcallOutput(self):
		try:		
			self.contentToFile += '\n=============================verify injection and remove action===============================\n'
			if(not self.hasSystemcallHooked()):
				raise Exception

			output = self.shellProc.stdout.readlines()
			errput = self.shellProc.stderr.readlines()
			self.contentToFile += 'system call pid:'+ str(self.targetPid) + '\n'
			
			self.contentToFile += '\nactual ret value without injection:\n' + str(self.actualRetValueDict) + '\n'
			self.contentToFile += '\nexpected ret value :\n' + str(self.expectedRetValueDict) + '\n'
			self.contentToFile += '\nsyscall stdout:\n' + ''.join(output) + '\n'
			self.contentToFile += '\nsyscall stderr:\n' + ''.join(errput) + '\n'
			
			injectionRetOutput,removeRetOurput = self.GetSystemcallRetOutput(output)
			
			isInjectionSuccessful = self.isInjectionActionSuccessful(injectionRetOutput)
			isRemoveSuccessful = self.isIRemoveActionSuccessful(removeRetOurput)
			
			self.inVerifySuccess = isInjectionSuccessful
			self.rmVerifySuccess = isRemoveSuccessful
			
			isSuccessful = isInjectionSuccessful and isRemoveSuccessful
			if( not isSuccessful):
				
				self.resultAnalyzer.RecordInjectionFailInfo(self.injectionHeader)
				self.resultAnalyzer.RecordInjectionFailInfo(self.contentToFile)
				return GlobalDefinition.ACTION_FAIL
				
			return GlobalDefinition.ACTION_SUCCESS
			
		except Exception,e:
			self.contentToFile += '\naction fail by exception:' + str(e)
			self.resultAnalyzer.RecordInjectionFailInfo(self.injectionHeader)
			self.resultAnalyzer.RecordInjectionFailInfo(self.contentToFile)
			return GlobalDefinition.ACTION_FAIL

	def isInjectionActionSuccessful(self,injectionRetOutput):
		isSuccessful = True
		for oneLine in injectionRetOutput:
			systemName = self.GetSyscallNameFromSyscallEmuOutputLine(oneLine)
			expectedRetValue = self.expectedRetValueDict[systemName]
			actualRetValueWithFault = self.GetSyscallRetValueFromSyscallEmuOutputLine(oneLine)
			if(expectedRetValue != -actualRetValueWithFault):
				self.contentToFile += '\ninjection action fail:' + systemName +'\n'
				self.inVerifyOut.append('injection action fail:' + systemName +'\n')
				isSuccessful  =  False
		if(isSuccessful):
			self.contentToFile += '\ninjection action successful\n'
		return isSuccessful

	def isIRemoveActionSuccessful(self,removeOutput):
		isSuccessful = True
		for oneLine in removeOutput:
			systemName = self.GetSyscallNameFromSyscallEmuOutputLine(oneLine)
			actualRetValue = self.actualRetValueDict[systemName]
			actualRetValueWithFault = self.GetSyscallRetValueFromSyscallEmuOutputLine(oneLine)
			if(actualRetValue != actualRetValueWithFault):
				self.contentToFile += '\nremove action fail:' + systemName +'\n'
				self.rmVerifyOut.append('remove action fail:' + systemName +'\n')
				isSuccessful = False
		if(isSuccessful):
			self.contentToFile += '\nremove action successful\n'
		return isSuccessful

	def GetSyscallNameFromSyscallEmuOutputLine(self,outputLine):
		outputLine = outputLine.replace(GlobalDefinition.LINE_SEPERATOR,'')
		partsInfoList = self.PureInfoList(outputLine.split(GlobalDefinition.SPACE_SYMBOL))	
		
		return str(partsInfoList[0])
		
	def GetSyscallRetValueFromSyscallEmuOutputLine(self,outputLine):
		outputLine = outputLine.replace(GlobalDefinition.LINE_SEPERATOR,'')
		partsInfoList = self.PureInfoList(outputLine.split(GlobalDefinition.COLON_SYMBOL))	
		
		return int(partsInfoList[2].replace(GlobalDefinition.SPACE_SYMBOL,''))

	def RemoveInjection(self):
		if(True == self.hasInjection):
			removeCmd = FISH_REMOVE_CMD
			removeProc = subprocess.Popen(removeCmd,shell = True,stdout = subprocess.PIPE,stderr = subprocess.PIPE)
			removeProc.wait()
			self.DealRemoveInjectionInfo(removeProc,removeCmd)
		else:
			self.contentToFile += '<<<<<<<<<<<<<<<<<<<<<<<<<<<remove<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n'
			self.contentToFile += 'no injection,so no removing\n'
			return GlobalDefinition.ACTION_SUCCESS
	
	def GetRemoveCmd(self,injectionCmd):
		if(GlobalDefinition.T1_OPTION in injectionCmd):
			return injectionCmd.replace(GlobalDefinition.T1_OPTION,GlobalDefinition.REMOVE_OPTION)
		if(GlobalDefinition.T2_OPTION in injectionCmd):
			return injectionCmd.replace(GlobalDefinition.T2_OPTION,GlobalDefinition.REMOVE_OPTION)
		return injectionCmd + GlobalDefinition.SPACE_SYMBOL + GlobalDefinition.REMOVE_OPTION

	def RemoveInjectionByM(self):
		if(True == self.hasInjection):
			removeCmdList = []
			for cmd in self.injectionCmdList:
				removeCmd = self.GetRemoveCmd(cmd)
				removeProc = subprocess.Popen(removeCmd,shell = True,stdout = subprocess.PIPE,stderr = subprocess.PIPE)
				removeProc.wait()
				removeCmdList.append(removeCmd)
				self.DealRemoveInjectionInfo(removeProc,removeCmd)
			self.fillRemoveOthers(self.rowIndex)
			self.resultAnalyzer.XlsWrite(self.rowIndex*2 + 1,0,'\n'.join(removeCmdList))
		else:
			self.contentToFile += '<<<<<<<<<<<<<<<<<<<<<<<<<<<remove<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n'
			self.contentToFile += 'no injection,so no removing\n'
			return GlobalDefinition.ACTION_SUCCESS	

	def DoInjectionCmdList(self,cmdByPidList):
		for cmdByPid in cmdByPidList:
			cmdByPid = cmdByPid.replace(GlobalDefinition.LINE_SEPERATOR,'')
			injectionProc = subprocess.Popen(cmdByPid,shell = True,stdout = subprocess.PIPE,stderr = subprocess.PIPE)
			injectionProc.wait()
			self.DealInjectionSuccessfulInfo(injectionProc,cmdByPid)
			self.hasInjection = True
		self.resultAnalyzer.XlsWrite(self.rowIndex*2,0,'\n'.join(cmdByPidList).replace('-T1','').replace('-T2',''))
		self.fillInjectionOthers(self.rowIndex)

	def GenerateMultiFaultPName(self,syscallNameList):
		emuFile = SyscallClassifier.emuFile[GlobalDefinition.NORMAL_SYSCALL] # multi fault injection only uses syscall_emu
		return self.systemcallController.systemcallEmuFilePath + emuFile + GlobalDefinition.SPACE_SYMBOL + self.systemcallController.unistdFile + GlobalDefinition.SPACE_SYMBOL + '^'.join(syscallNameList) + '^' + GlobalDefinition.SPACE_SYMBOL+ str(INVALID_EXPECTED_RET_VALUE)

	def GetValidInjectionTestList(self,mappingList):

		cmdPrefixList = self.GenerateInjectionCmdPrefixList(mappingList)
		syscallNameList = []
		tempDict = {}
		for index in range(0,len(cmdPrefixList)):
			cmdPrefix = cmdPrefixList[index]
			try:#get valid prefix cmd
				
				tempDict[cmdPrefix] = self.GetActualRetValueWithoutInjection(cmdPrefix)
				faultActionId = self.GetFaultActionIdFromCmdPrefix(cmdPrefix)
				syscallName = self.GetSyscallNameFromMappingLineList(faultActionId,mappingList)
				syscallNameList.append(syscallName)
				if(syscallName in self.actualRetValueDict):
					print(cmdPrefix + "+++++++"+faultActionId)
					print('syscall name : '+ syscallName)
				(self.actualRetValueDict)[syscallName] = tempDict[cmdPrefix]		
				(self.expectedRetValueDict)[syscallName] = self.GetExpectedRetValueFromMappingLineList(faultActionId,mappingList)
			except Exception,e:
				pNameCmd = self.systemcallController.GenerateSyscallCmd(cmdPrefix)
				self.resultAnalyzer.RecordSyscallFailInfo('syscall fail:' + cmdPrefix + '\n' + pNameCmd)
				self.contentToFile += 'syscall fail:'  + cmdPrefix + '\n'  + pNameCmd + '\n'  + '\n'
				print(pNameCmd)
		if(0 == len(syscallNameList)):
			self.contentToFile = '\nfail: no valid cmd prefix\n'
			print(self.contentToFile)
			raise Exception

		pNameCmd,shellProc,targetPid = self.GenerateWorkloadTargetProc(syscallNameList)
		self.HookSystemcall(pNameCmd,shellProc,targetPid)
		
		cmdByPidList = []	
		for cmdPrefix in tempDict:
			cmdByPid = self.GenerateInjectionCmd(cmdPrefix,targetPid,pNameCmd)
			cmdByPidList.append(cmdByPid)
		self.injectionCmdList = cmdByPidList
					
		self.contentToFile += '\ncmdByPidList:\n' + '\n'.join(cmdByPidList) + '\n'
		self.contentToFile += '\nsyscallNameList:\n' + '\n'.join(syscallNameList)+ '\n'
		return cmdByPidList,syscallNameList

	def GenerateWorkloadTargetProc(self,syscallNameList):
		try:
			multiFaultPName  = self.GenerateMultiFaultPName(syscallNameList)
			self.contentToFile += '\n\nWorkload Program: \n' + multiFaultPName + '\n'
			shellProc , targetPid = self.GenerateWorkloadProc(multiFaultPName)	# shellPorc is the parent of real target workload process 
			if(GlobalDefinition.INVALID_PID == targetPid):
				self.contentToFile += GlobalDefinition.INJECTION_FAIL + ' can not fork:' + multiFaultPName + '\n'
				raise Exception
			
			return multiFaultPName,shellProc,targetPid
		except Exception,e:
			raise e	
	
	def ContinueTargetWorkload(self):
		if(not self.hasSystemcallHooked()):
			self.contentToFile += '\nhook fail\n'
			raise Exception
		os.kill(self.targetPid,signal.SIGCONT)
			

	def GenerateInjectionCmdPrefixList(self,mappingLineList):
		try:
			cmdPrefixList = []
			for index in range(0,len(mappingLineList)):
				faultActionId= (mappingLineList[index].split(GlobalDefinition.SPACE_SYMBOL))[0]
				cmdPrefix = FISH_CMD_PREFIX + GlobalDefinition.SPACE_SYMBOL + str(faultActionId)
				cmdPrefixList.append(cmdPrefix)
		
			self.contentToFile += 'CmdPrefixList:\n' + ''.join(cmdPrefixList) + '\n\n'
			return cmdPrefixList
		except Exception,e:
			self.contentToFile += 'Command list generate fail by exception:' + str(e)
			raise e
	
	def InjectionHeader(self,counter):
		return '\n\n >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>index:'+ str(counter) + '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n'
	def GetFaultActionIdFromCmdPrefix(self,cmdPrefix):
		purePartsInfoList = self.PureInfoList(cmdPrefix.split(GlobalDefinition.SPACE_SYMBOL))
		return str(purePartsInfoList[len(purePartsInfoList)-1])
	
	def GetSyscallNameFromMappingLineList(self,faultActionId,mappingLineList):
		for target in mappingLineList:
			pureInfoList = self.PureInfoList(target.replace('\n','').split(' '))
			if(int(faultActionId) == int(pureInfoList[GlobalDefinition.FAULT_ACTION_ID_INDEX_IN_MAP_LINE])):
				return self.GetSyscallNameFromMappingLine(target)
		return GlobalDefinition.NO_MAPPING_LINE	

	def GetSyscallNameFromMappingLine(self,mappingLine):
		pureLine = mappingLine.replace(GlobalDefinition.LINE_SEPERATOR,'')
		purePartsInfo = self.PureInfoList(pureLine.split(GlobalDefinition.SPACE_SYMBOL))
		syscallNameInMap = str(purePartsInfo[GlobalDefinition.SYSCALL_NAME_INDEX_IN_MAP_LINE])
		syscallName = SyscallClassifier.SyscallNameExchange(syscallNameInMap,self.systemcallController.GetBitVersion())
		return syscallName

	def GetExpectedRetValueFromMappingLineList(self,faultActionId,mappingLineList):
		
		for target in mappingLineList:
			pureInfoList = self.PureInfoList(target.replace('\n','').split(' '))
			if(int(faultActionId) == int(pureInfoList[GlobalDefinition.FAULT_ACTION_ID_INDEX_IN_MAP_LINE])):
				return self.GetExepectedRetValueFromMappingLine(target)
		return GlobalDefinition.NO_MAPPING_LINE	

	def GetExepectedRetValueFromMappingLine(self,mappingLine):
		pureLine = mappingLine.replace(GlobalDefinition.LINE_SEPERATOR,'')
		purePartsInfo = self.PureInfoList(pureLine.split(GlobalDefinition.SPACE_SYMBOL))
		return int(purePartsInfo[GlobalDefinition.EXPECTED_RETURN_VALUE_INDEX_IN_MAP_LINE])

			
	
	def GenerateInjectionCmd(self,cmd,pid,pName):
		return cmd +  GlobalDefinition.SPACE_SYMBOL +  GlobalDefinition.INJECTION_BY_PNAME_OPTION + GlobalDefinition.SPACE_SYMBOL + str(self.GetProgramValidName(pName)) + GlobalDefinition.SPACE_SYMBOL + SyscallClassifier.GetTOptionBySyscall(self.syscallName,self.systemcallController.GetBitVersion())#by pName

	def PureInfoList(self,infoList):
		while('' in infoList):
			infoList.remove('')
		return infoList
			
	def InitializeBeforeRunInjection(self):
		self.contentToFile = ''	
		self.injectionHeader = ''
		self.hasInjection = False	
		self.pNameCmd = None
		self.shellProc = None
		self.targetPid = None
		self.actualRetValueWithInjection = None
		self.injectionCmdHook = ''
		self.isFindSyscall = False
		self.syscallName = ''
		self.actualRetValueDict = {}
		self.expectedRetValueDict = {}
		self.injectionSuccess = True
		self.removeSucces = True
		self.inVerifySuccess = True
		self.rmVerifySuccess = True
		self.injectionOut = []
		self.removeOut = []
		self.inVerifyOut = []
		self.rmVerifyOut = []
		pass
	def fillInjectionOthers(self,row):
		partsInfo = self.systemcallController.mapFile.split('p')
		version = partsInfo[len(partsInfo)-1]
		tag = str(version) + 'm' + self.inType + '_' + str(row)
		self.resultAnalyzer.XlsWrite(2*row,1,tag)
		self.resultAnalyzer.XlsWrite(2*row,2,'nofault')
		self.resultAnalyzer.XlsWrite(2*row,3,'install')
		self.resultAnalyzer.XlsWrite(2*row,4,'workdir')
		self.resultAnalyzer.XlsWrite(2*row,5,'root')
		if('i' == self.inType):
			self.resultAnalyzer.XlsWrite(2*row,6,'pid_m')
		elif('n' == self.inType):
			self.resultAnalyzer.XlsWrite(2*row,6,'pname_m')
		self.resultAnalyzer.XlsWrite(2*row,7,'shell')
		self.resultAnalyzer.XlsWrite(2*row,8,'insuc,trisuc')	
		self.resultAnalyzer.XlsWrite(2*row,12,'sunya')
		pass

	def fillActualResult(self):

		if(not self.injectionSuccess and not self.inVerifySuccess):
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,9,'infail,verfail')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,13,'exist')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,14,''.join(self.injectionOut) + '\n' + ''.join(self.inVerifyOut))
		if(not self.injectionSuccess and self.inVerifySuccess):
			self.resultAnalyzer,XlsWrite(self.rowIndex*2,9,'infail,versuc')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,13,'exist')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,14,''.join(self.injectionOut) + '\n' + ''.join(self.inVerifyOut))
		if(self.injectionSuccess and not self.inVerifySuccess):
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,9,'insuc,verfail')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,13,'exist')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,14,''.join(self.injectionOut) + '\n' + ''.join(self.inVerifyOut))
		if(self.injectionSuccess and self.inVerifySuccess):
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,9,'insuc,versuc')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2,13,'none')
			
		if(not self.removeSuccess and not self.rmVerifySuccess):
			self.resultAnalyzer.XlsWrite(self.rowIndex*2 + 1,9,'rmfail,verfail')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2+1,13,'exist')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2+1,14,''.join(self.removeOut) + '\n' + ''.join(self.rmVerifyOut))
		if(not self.removeSuccess and self.rmVerifySuccess):
			self.resultAnalyzer.XlsWrite(self.rowIndex*2 + 1,9,'rmfail,versuc')	
			self.resultAnalyzer.XlsWrite(self.rowIndex*2+1,13,'exist')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2+1,14,''.join(self.removeOut) + '\n' + ''.join(self.rmVerifyOut))
		if(self.removeSuccess and not self.rmVerifySuccess):
			self.resultAnalyzer.XlsWrite(self.rowIndex*2 + 1,9,'rmsuc,verfail')	
			self.resultAnalyzer.XlsWrite(self.rowIndex*2+1,13,'exist')
			self.resultAnalyzer.XlsWrite(self.rowIndex*2+1,14,''.join(self.removeOut) + '\n' + ''.join(self.rmVerifyOut))
		if(self.removeSuccess and self.rmVerifySuccess):
			self.resultAnalyzer.XlsWrite(self.rowIndex*2 + 1,9,'rmsuc,versuc')	
			self.resultAnalyzer.XlsWrite(self.rowIndex*2+1,13,'none')
		
		pass
		

	def fillRemoveOthers(self,row):
		partsInfo = self.systemcallController.mapFile.split('p')
		version = partsInfo[len(partsInfo)-1]
		tag = str(version) + 'm' + self.inType+ 'r_' + str(row)
		self.resultAnalyzer.XlsWrite(2*row + 1,1,tag)
		self.resultAnalyzer.XlsWrite(2*row + 1,2,'hastargetfault')
		self.resultAnalyzer.XlsWrite(2*row + 1,3,'install')
		self.resultAnalyzer.XlsWrite(2*row + 1,4,'workdir')
		self.resultAnalyzer.XlsWrite(2*row + 1,5,'root')
		if('i' == self.inType):
			self.resultAnalyzer.XlsWrite(2*row + 1,6,'pid_m')
		elif('n' == self.inType):
			self.resultAnalyzer.XlsWrite(2*row + 1,6,'pname_m')
		self.resultAnalyzer.XlsWrite(2*row + 1,7,'shell')
		self.resultAnalyzer.XlsWrite(2*row + 1,8,'rmsuc,versuc')		
		self.resultAnalyzer.XlsWrite(2*row + 1,12,'sunya')
		pass

	def GetActualRetValueWithoutInjection(self,cmd):
		stdout = ''
		stderr = ''
		syscallHook = ''
		try:
			
			faultType = self.systemcallController.GetMappingFaultType(cmd)
			
			if(faultType == GlobalDefinition.DELAY_FAULT_TYPE):
				raise Exception	
		except Exception,e:
			self.contentToFile += '\n delay fault type : do it by hand\n'
			raise e
		try:
			pNameCmd = self.systemcallController.GenerateSyscallCmd(cmd)	
			if(GlobalDefinition.NO_MAPPING_LINE == pNameCmd):
				self.contentToFile += GlobalDefinition.INJECTION_FAIL + ": " + GlobalDefinition.NO_MAPPING_LINE + '\n'
				raise Exception
			syscallWithNoStopCmd = pNameCmd.replace(GlobalDefinition.WITH_STOP_FILE_SUFFIX,GlobalDefinition.NO_STOP_FILE_SUFFIX)
			syscallHook = syscallWithNoStopCmd	
			systemcallProc = subprocess.Popen(syscallWithNoStopCmd,shell = True,stdout = subprocess.PIPE,stderr = subprocess.PIPE)
			systemcallProc.wait()
			stdout = systemcallProc.stdout.readlines()
			stderr = systemcallProc.stderr.readlines()
			actualRetValue = self.GetActualRetValue(stdout[len(stdout) -1])
			self.isFindSyscall = True
			faultActionId = self.systemcallController.GetFaultActionId(cmd)
			self.syscallName = self.systemcallController.GetSyscallName(faultActionId)
			return actualRetValue
			
		except Exception,e:
			syscallFailInfo = '\nGet actual return value without injection fail by exception:' + str(e) + '\n' 
			syscallFailInfo += '\nsyscall program: ' + syscallHook + '\n'
			syscallFailInfo += 'stdout:' + ''.join(stdout)
			syscallFailInfo += 'stderr:' + ''.join(stderr)
			self.resultAnalyzer.RecordSyscallFailInfo(syscallFailInfo + '\n')
			self.contentToFile += syscallFailInfo
			raise e
	
	def HookSystemcall(self,pNameCmd,shellProc,targetPid):
		self.pNameCmd = pNameCmd
		self.shellProc = shellProc
		self.targetPid = targetPid
		pass
	
	def hasSystemcallHooked(self):
		if(None == self.pNameCmd or None == self.shellProc or None == self.targetPid):
			return False
		return True
	

	def GenerateWorkloadProc(self,cmd):
		
		procHook = subprocess.Popen(cmd,shell = True,stdout = subprocess.PIPE,stderr = subprocess.PIPE)
		time.sleep(0.1)#danger
		try:
			targetPid = self.GetRealTargetProcPid(procHook)
			return procHook,targetPid
		except Exception,e:
			raise e
	def GetRealTargetProcPid(self,parentProc):		
	
		queryCmd = 'pstree -p ' + str(parentProc.pid)
		queryProc = subprocess.Popen(queryCmd,shell = True,stdout = subprocess.PIPE,stderr = subprocess.PIPE)	
		queryProc.wait()
		
		output = queryProc.stdout.readlines()
		errput = queryProc.stderr.readlines()
		self.contentToFile += '\npstree output:'+''.join(output)
		self.contentToFile += 'pstree errput:'+''.join(errput) + '\n\n'
		if(len(output) > 1):
			self.contentToFile +='!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!'
			self.contentToFile += ''.join(output)
		if(0 == len(output)):
			self.contentToFile +='!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!'
			self.contentToFile += 'parent pid :' + str(parentProc.pid) + '  no child process'
			return GlobalDefinition.INVALID_PID
		try:		#analyze it with the actual output
			partsInfo = output[0].split(')')
			# pstree output is different format between suse(16) and ubuntu(32,34)
			if('16' in self.systemcallController.mapFile):
				middlePart = partsInfo[0]#suse
			else:
				middlePart = partsInfo[1]#ubuntu
			middlePartInfo = middlePart.split('(')
			finalPart = middlePartInfo[1]		
			return int(finalPart.replace(')','').replace('\n',''))
		except Exception,e:
			self.contentToFile += str(e) + '\nsyscall_emu is not stopped?\n'
			self.contentToFile += '\nworkload stdout(should be no data here):' + ''.join(parentProc.stdout.readlines()) 
			self.contentToFile += '\nworkload stderr(should be no data here):' + ''.join(parentProc.stderr.readlines()) 
			raise e

 
	def GetActualRetValue(self,outputLine):
		try:
			partsInfoList = outputLine.split(GlobalDefinition.COLON_SYMBOL)
			partsInfoList = self.PureInfoList(partsInfoList)
			return int(partsInfoList[len(partsInfoList) - 1].replace(GlobalDefinition.LINE_SEPERATOR,''))
		except Exception,e:
			self.contentToFile += 'invalid syscall output:\n' + ''.join(outputLine) + str(e)
			raise e


	def DealRemoveInjectionInfo(self,removeProc,removeCmd):
		removeSeperator = '<<<<<<<<<<<<<<<<<<<<<<<<<<<remove<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n'
		output,errOut = removeProc.communicate()
		if(not 'succeed' in output):
			self.injectionSuccess = False
			self.removeOut.append(''.join(output))			
		self.DealEachSegmentInfo(output,errOut,removeCmd,removeSeperator)
	
	def GetSystemcallRetOutput(self,systemcallOutput):
		try:		
			injectionRetOutput = []
			removeRetOurput = []	
			startIndex = 0
			for index in range(0,len(systemcallOutput)):
				if(GlobalDefinition.INJECTION_OUTPUT_TAG == systemcallOutput[index]):
					for targetIndex in range(0 , len(self.actualRetValueDict)):
						injectionRetOutput.append(systemcallOutput[index + 1 + targetIndex])

				if(GlobalDefinition.REMOVE_OUTPUT_TAG == systemcallOutput[index]):
					for targetIndex in range(0 , len(self.actualRetValueDict)):
						removeRetOurput.append(systemcallOutput[index + 1 + targetIndex])		
			
			return injectionRetOutput,removeRetOurput
		except Exception,e:
			raise e 	


	def DealEachSegmentInfo(self,output,errOut,cmd,seperator):	
		self.contentToFile += seperator + 'Cmd:' + cmd + '\n' + 'errOut:' + ''.join(errOut) + '\nstdout:' + ''.join(output)
		return output


	def DealInjectionSuccessfulInfo(self,injectionProc,cmd):
		seperator = ''
		output,errOut = injectionProc.communicate()
		if(not 'succeed' in output):
			self.injectionSuccess = False	
			self.injectionOut.append(''.join(output))		
		self.DealEachSegmentInfo(output,errOut,cmd,seperator)


