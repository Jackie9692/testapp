import GlobalDefinition
import random
from SyscallClassifier import SyscallClassifier

class MultiFaultCmdManager:
	def __init__(self,mapFile):
		self.mapFile = mapFile
	
	def GetRandomRetCmdList(self,quantity):
		if(quantity < 1):
			print('quantity must greater than 0     quantity:' + str(quantity) + '\n');

		mapFileHandler = open(self.mapFile,'r')
		lines = mapFileHandler.readlines()
		resultList = []
		exclusiveCmdIndexList = []
		
		counter = 0 
		while(counter < quantity):
			randCmdIndex = random.randint(0,len(lines)-1)
			while(randCmdIndex in exclusiveCmdIndexList):
					randCmdIndex = random.randint(0,len(lines)-1)
			cmd = lines[randCmdIndex]
			if(self.isTargetCmd(cmd,resultList)):
				resultList.append(cmd)
				counter += 1
			else:
				exclusiveCmdIndexList.append(randCmdIndex)
		
		mapFileHandler.close()
		return resultList
		
	def isDifferentSyscallCmd(self,cmd,existCmdList):
		cmdSyscall = (cmd.split(GlobalDefinition.SPACE_SYMBOL))[GlobalDefinition.SYSCALL_NAME_INDEX_IN_MAP_LINE]
		
		for index in range(0,len(existCmdList)):	
			existSyscall = (existCmdList[index].split(GlobalDefinition.SPACE_SYMBOL))[GlobalDefinition.SYSCALL_NAME_INDEX_IN_MAP_LINE]
			if(cmdSyscall == existSyscall):
				return False
		
		return True
			
	def isTargetCmd(self,cmd,resultList):
		return True == self.isRetSyscall(cmd) and True == self.isNormalCmd(cmd) and True == self.isValidCmd(cmd) and True == self.isDifferentSyscallCmd(cmd,resultList)

	def isRetSyscall(self,cmd):
		try:	
			partsInfo = cmd.replace(GlobalDefinition.LINE_SEPERATOR,'').split(GlobalDefinition.SPACE_SYMBOL)
			while('' in partsInfo):
				partsInfo.remove('')
			if(isinstance(int(partsInfo[3]),int) and GlobalDefinition.RET_FAULT_TYPE  == int(partsInfo[3])):# fault injection method
				return True
			return False
		except Exception,e:
			print(e)
			return False

	def isValidCmd(self,cmd):
		try:	
			partsInfo = cmd.replace(GlobalDefinition.LINE_SEPERATOR,'').split(GlobalDefinition.SPACE_SYMBOL)
			while('' in partsInfo):
				partsInfo.remove('')
			if(isinstance(int(partsInfo[0]),int) and int(partsInfo[0]) != 854):# fault action id
				return True
			return False
		except Exception,e:
			print(e)
			return False
	
	def GetBitVersion(self):
		if('64' in self.mapFile):
			return GlobalDefinition.BIT_64
		return GlobalDefinition.BIT_32
				
	def isNormalCmd(self,cmd):
		try:	
			partsInfo = cmd.replace(GlobalDefinition.LINE_SEPERATOR,'').split(GlobalDefinition.SPACE_SYMBOL)
			while('' in partsInfo):
				partsInfo.remove('')
			syscallName = partsInfo[1]#system call name
			
			if(GlobalDefinition.NORMAL_SYSCALL == SyscallClassifier.GetSyscallClassification(syscallName,self.GetBitVersion())):
				return True
			return False
		except Exception,e:
			print(e)
			return False	
		
		
			
		
	
	
	
 
