from MultiConfigurator import MultiConfigurator 
from MultiFaultCmdManager import MultiFaultCmdManager 
from MultiPidCmdExecutor import MultiPidCmdExecutor 
from SystemcallController import SystemcallController
from SyscallClassifier import SyscallClassifier
import GlobalDefinition

class MultiFaultTestController:
	
	def __init__(self,multiConfigurator):
		self.executorRef = None	
		self.multiConfigurator = multiConfigurator
		pass

	def StartTest(self,testCount,faultCount):
		try:
			
			multiFaultCmdManager,systemcallController,executor = self.multiConfigurator.GetEachModule()
			
			counter = 0
			while(counter < testCount):
				mappingList = multiFaultCmdManager.GetRandomRetCmdList(faultCount)
		
				executor.RunInjectionCmdList(mappingList,counter)
				counter += 1
			
			print('Test Done!\n')
		except Exception,e:
			print(e)
		
			
