import GlobalDefinition
from MultiExecutor import MultiExecutor
import os 
import subprocess 
import signal
import time
from SyscallClassifier import SyscallClassifier


class MultiPNameCmdExecutor(MultiExecutor):
	def __init__(self,systemcallController,resultAnalyzer):
		MultiExecutor.__init__(self,systemcallController,resultAnalyzer)
		self.inType = 'n'
		pass

	def GenerateInjectionCmd(self,cmd,pid,pName):
		return cmd +  GlobalDefinition.SPACE_SYMBOL +  GlobalDefinition.INJECTION_BY_PNAME_OPTION + GlobalDefinition.SPACE_SYMBOL +  str(self.GetProgramValidName(pName)) + GlobalDefinition.SPACE_SYMBOL + SyscallClassifier.GetTOptionBySyscall(self.syscallName,self.systemcallController.GetBitVersion())#by pid

	
	


	
			
	
	
