import sys

mapFiles =["map32.16","map32.34","map32.34","map64.16","map64.32","map64.34"]
pfdFile = "pfd"
filePrefix = "../../lib/"
codeFile = "tempCode.c"

retMethod = '1'

pfd = open(filePrefix + pfdFile,"r+")
pfdContent = pfd.readlines()
for line in pfdContent:
	if('#' in line ):
		pfdContent.remove(line)
pfd.close()

pfdList = [(line.replace("\n",'').split(' '))[0] for line in pfdContent]

allSys = set()
for fileName in mapFiles:
	filePath = filePrefix + fileName
	mapFile = open(filePath , 'r+')
	mapContent = mapFile.readlines()
	mapFile.close()
	allSys = allSys |  set ((line.split())[1] for line in mapContent if retMethod == (line.replace('\n','').split())[3])


codeFO = open(codeFile, "w+")
for sys in allSys:
	code = "	if(EQUAL == strcmp(syscall, \"" + sys + "\")){\n            errno = 0;\n            kill(getpid(),SIGSTOP);\n            " + sys[4:len(sys)] + "(0,0,0);\n            VERIFY_ERRNO(\"" + sys[4:len(sys)] + "\",expRetValue,errno)\n	}\n\n"
	codeFO.write(code)

