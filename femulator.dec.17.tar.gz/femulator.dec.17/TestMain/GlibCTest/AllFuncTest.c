#include <stdio.h>
#include <unistd.h>
#include <errno.h> 
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/statfs.h>
#include <sys/mount.h>
#include <utime.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <sys/mman.h>
#include <dirent.h>
#include <sys/syscall.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/capability.h>
#include <sys/reboot.h>
#include <sys/signal.h>
#include <sys/utsname.h>
#include <sched.h>
#include <sys/select.h>
#include <sys/resource.h>
#include <sys/shm.h>
#include <sys/personality.h>
#include <sys/wait.h>
#include <sys/sem.h>
#include <sys/vfs.h>
#include <sys/poll.h>
#include <sys/uio.h>
#include <sys/quota.h>
#include <dirent.h>     /* Defines DT_* constants */

#define _GNU_SOURCE



#define NO_ARGS -11
#define EQUAL  0

#define VERIFY_ERRNO(funcName,expRetValue,errno) 	{\
													hasTarget = 1;\
													if(0 == (expRetValue) + (errno)){ \
														printf("syscallName:%s,function:%s,succeed\n",syscallName,funcName);\
														if(argc ==4 ){\
															close(fd);\
														}\
														return 0;\
													}\		
													else{\
														printf("-------------syscallName:%s, function:%s fail and actual errno:%d\n",syscallName,funcName,-errno);\
														if(argc == 4){\
															close(fd);\
														}\
														return -1;\
													}\
													}	



char * myArgv[] = {"test1","test2"};
char * myEnv[] = {"test1","test2"};
char c_buffer[20];
int buffer_size = 20;
int length_size = 20;
int hasTarget = 0;

int main(int argc , char * argv[]){

	if(argc < 3){
		printf("args: <sys_xxx> <ret value> [fName]\n");
		return NO_ARGS;
	}
	char * syscallName = argv[1];
	int expRetValue = atoi(argv[2]);
	char * fName = NULL;
	int fd = 0 ;

	if(argc == 4 ){	
		fName = argv[3];
		fd = open(fName,O_RDONLY);
		if(-1 == fd){
			printf("syscallName:%s ,open file '%s' fail!\n",syscallName,fName);
			return -1;
		}
	}

	if(EQUAL == strcmp(syscallName, "sys_clone")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            fork();
            VERIFY_ERRNO("fork",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_getsockopt64")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            getsockopt(0,0,0,0,0);
            VERIFY_ERRNO("getsockopt",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_msgrcv")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            msgrcv(0,0,0,0,0);
            VERIFY_ERRNO("msgrcv",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_sendto")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sendto(fd,0,0,0,0,0);
            VERIFY_ERRNO("sendto",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_capget")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            capget(0,0);
            VERIFY_ERRNO("capget",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_open")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            open(fName,0);
            VERIFY_ERRNO("open",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_pipe")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            pipe(0);
            VERIFY_ERRNO("pipe",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_reboot")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            reboot(0);
            VERIFY_ERRNO("reboot",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_sethostname")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sethostname(0,0);
            VERIFY_ERRNO("sethostname",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_getpgid")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            getpgid();
            VERIFY_ERRNO("getpgid",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_newuname")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            uname(0);
            VERIFY_ERRNO("uname",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_newstat")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            stat(fName,0);
            VERIFY_ERRNO("stat",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_sched_getparam")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sched_getparam(0,0);
            VERIFY_ERRNO("sched_getparam",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_newfstat")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            fstat(0,0);
            VERIFY_ERRNO("fstat",expRetValue,errno)
	}
	if(EQUAL == strcmp(syscallName, "sys_newfstat64")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            fstat(0,0);
            VERIFY_ERRNO("fstat",expRetValue,errno)
	}
	if(EQUAL == strcmp(syscallName, "sys_umount")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            umount(fName);
            VERIFY_ERRNO("umount",expRetValue,errno)
	}
	if(EQUAL == strcmp(syscallName, "sys_umount2")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            umount2(0,0);
            VERIFY_ERRNO("umount2",expRetValue,errno)
	}
	if(EQUAL == strcmp(syscallName, "sys_setsockopt")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            setsockopt(fd,0,0,0,0);
            VERIFY_ERRNO("setsockopt",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_select")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            select(0,0,0,0,0);
            VERIFY_ERRNO("select",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_setpriority")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            setpriority(0,0,0);
            VERIFY_ERRNO("setpriority",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "do_shmat")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            shmat(0,0,0);
            VERIFY_ERRNO("shmat",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_stat64")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            stat(fName,0);
            VERIFY_ERRNO("stat",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_socketpair")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            socketpair(0,0,0,0);
            VERIFY_ERRNO("socketpair",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_personality")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            personality(0);
            VERIFY_ERRNO("personality",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_wait4")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            wait4(0,0,0,0);
            VERIFY_ERRNO("wait4",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_semtimedop")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            semtimedop(0,0,0,0);
            VERIFY_ERRNO("semtimedop",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_shutdown")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            shutdown(fd,0);
            VERIFY_ERRNO("shutdown",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_execve")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            execve(fName,0,0);
            VERIFY_ERRNO("execve",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_readlink")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            readlink(fName,0,0);
            VERIFY_ERRNO("readlink",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_truncate")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            truncate(fName,0);
            VERIFY_ERRNO("truncate",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_fchmod")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            fchmod(fd,0);
            VERIFY_ERRNO("fchmod",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_read")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            read(fd,0,0);
            VERIFY_ERRNO("read",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_semctl")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            semctl(0,0,0);
            VERIFY_ERRNO("semctl",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_nice")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            nice(0);
            VERIFY_ERRNO("nice",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_statfs")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            statfs(fName,0);
            VERIFY_ERRNO("statfs",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_sched_get_priority_max")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sched_get_priority_max(0);
            VERIFY_ERRNO("sched_get_priority_max",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_recvfrom")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            recvfrom(fd,0,0,0,0,0);
            VERIFY_ERRNO("recvfrom",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_fsync")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            fsync(fd);
            VERIFY_ERRNO("fsync",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_mremap")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mremap(0,0,0,0);
            VERIFY_ERRNO("mremap",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_poll")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            poll(0,0,0);
            VERIFY_ERRNO("poll",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_sched_getscheduler")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sched_getscheduler(0);
            VERIFY_ERRNO("sched_getscheduler",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_sched_rr_get_interval")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sched_rr_get_interval(0,0);
            VERIFY_ERRNO("sched_rr_get_interval",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_access")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            access(fName,0);
            VERIFY_ERRNO("access",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_mmap2")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mmap(0,0,0,0,fd,0);
            VERIFY_ERRNO("mmap",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_rename")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            rename(fName,0);
            VERIFY_ERRNO("rename",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_flock")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            flock(fd,0);
            VERIFY_ERRNO("flock",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_getsockname")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            getsockname(fd,0,0);
            VERIFY_ERRNO("getsockname",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_brk")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            brk(0);
            VERIFY_ERRNO("brk",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_fchdir")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            fchdir(fd);
            VERIFY_ERRNO("fchdir",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_utime")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            utime(fName,0);
            VERIFY_ERRNO("utime",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_kill")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            kill(0,0);
            VERIFY_ERRNO("kill",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_mmap_pgoff")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mmap(0,0,0,0,fd,0);
            VERIFY_ERRNO("mmap",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_getpeername")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            getpeername(fd,0,0);
            VERIFY_ERRNO("getpeername",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_close")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            close(fd);
            VERIFY_ERRNO("close",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_rt_sigaction")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sigaction(0,0,0);
            VERIFY_ERRNO("sigaction",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_dup2")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            dup2(fd,0);
            VERIFY_ERRNO("dup2",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_mkdir")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mkdir(fName,0);
            VERIFY_ERRNO("mkdir",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_mknod")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mknod(fName,0,0);
            VERIFY_ERRNO("mknod",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_setpgid")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            setpgid(0,0);
            VERIFY_ERRNO("setpgid",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_getsockopt")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            getsockopt(fd,0,0,0,0);
            VERIFY_ERRNO("getsockopt",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_ftruncate")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            ftruncate(fd,0);
            VERIFY_ERRNO("ftruncate",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_shmget")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            shmget(0,0,0);
            VERIFY_ERRNO("shmget",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_ptrace")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            ptrace(0,0,0,0);
            VERIFY_ERRNO("ptrace",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_write")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            write(fd,0,0);
            VERIFY_ERRNO("write",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_mount")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mount(fName,fName,fName,0,0);
            VERIFY_ERRNO("mount",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_writev")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            writev(fd,0,0);
            VERIFY_ERRNO("writev",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_rmdir")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            rmdir(fName);
            VERIFY_ERRNO("rmdir",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_chmod")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            chmod(fName,0);
            VERIFY_ERRNO("chmod",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_pause")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            pause();
            VERIFY_ERRNO("pause",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_socket")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            socket(0,0,0);
            VERIFY_ERRNO("socket",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_getdents")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            //readdir(0);
            //getdents(0,0,0);
			syscall(SYS_getdents, fd, 0, 0);
			VERIFY_ERRNO("gentdents(by syscall directly)",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_msync")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            msync(0,0,0);
            VERIFY_ERRNO("msync",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_shmat")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            shmat(0,0,0);
            VERIFY_ERRNO("shmat",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_rt_sigprocmask")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sigprocmask(0,0,0);
            VERIFY_ERRNO("sigprocmask",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_readv")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            readv(fd,0,0);
            VERIFY_ERRNO("readv",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_connect")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            connect(fd,0,0);
            VERIFY_ERRNO("connect",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_semget")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            semget(0,0,0);
            VERIFY_ERRNO("semget",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_mmap")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mmap(0,0,0,0,fd,0);
            VERIFY_ERRNO("mmap",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_setdomainname")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            setdomainname(0,0);
            VERIFY_ERRNO("setdomainname",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_getsid")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            getsid(0);
            VERIFY_ERRNO("getsid",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_sched_get_priority_min")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sched_get_priority_min(0);
            VERIFY_ERRNO("sched_get_priority_min",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_uname")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            uname(0);
            VERIFY_ERRNO("uname",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_accept")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            accept(fd,0,0);
            VERIFY_ERRNO("accept",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_munmap")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            munmap(0,0);
            VERIFY_ERRNO("munmap",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_bind")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            bind(fd,0,0);
            VERIFY_ERRNO("bind",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_fstat64")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            fstat(fd,0);
            VERIFY_ERRNO("fstat",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_rt_sigsuspend")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sigsuspend(0);
            VERIFY_ERRNO("sigsuspend",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_mprotect")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mprotect(0,0,0);
            VERIFY_ERRNO("mprotect",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_listen")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            listen(fd,0);
            VERIFY_ERRNO("listen",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_getpriority")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            getpriority(0,0);
            VERIFY_ERRNO("getpriority",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_shmdt")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            shmdt(0);
            VERIFY_ERRNO("shmdt",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_lseek")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            lseek(fd,0,0);
            VERIFY_ERRNO("lseek",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_ustat")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            ustat(0,0);
            VERIFY_ERRNO("ustat",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_mlock")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mlock(0,0);
            VERIFY_ERRNO("mlock",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_prctl")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            prctl(0,0,0,0,0);
            VERIFY_ERRNO("prctl",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_dup")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            dup(fd);
            VERIFY_ERRNO("dup",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_munlock")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            munlock(0,0);
            VERIFY_ERRNO("munlock",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_sendfile")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sendfile(fd,fd,0,0);
            VERIFY_ERRNO("sendfile",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_nanosleep")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            nanosleep(0,0);
            VERIFY_ERRNO("nanosleep",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_symlink")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            symlink(fName,fName);
            VERIFY_ERRNO("symlink",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_chdir")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            chdir(fName);
            VERIFY_ERRNO("chdir",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_fcntl64")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            fcntl(fd,0);
            VERIFY_ERRNO("fcntl",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_accept4")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            accept4(fd,0,0,0);
            VERIFY_ERRNO("accept4",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_fcntl")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            fcntl(fd,0);
            VERIFY_ERRNO("fcntl",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_shmctl")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            shmctl(0,0,0);
            VERIFY_ERRNO("shmctl",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_sendfile64")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sendfile(fd,fd,0,0);
            VERIFY_ERRNO("sendfile",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_quotactl")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            quotactl(0,0,0,0);
            VERIFY_ERRNO("quotactl",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_msgctl")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            msgctl(0,0,0);
            VERIFY_ERRNO("msgctl",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_msgget")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            msgget(0,0);
            VERIFY_ERRNO("msgget",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_modify_ldt")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            modify_ldt(0,0,0);
            VERIFY_ERRNO("modify_ldt",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscallName, "sys_msgsnd")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            msgsnd(0,0,0,0);
            VERIFY_ERRNO("msgsnd",expRetValue,errno)
	}

	if(0 == hasTarget){
		printf("========================can not find here: %s=======================\n",syscallName);
		if(argc == 4){
			close(fd);
		}
	}

	return -1;
}


