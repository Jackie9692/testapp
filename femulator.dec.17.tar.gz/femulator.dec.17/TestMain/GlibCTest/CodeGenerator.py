funcList = ["bind","fchdir","fchmod","close","connect","dup","fcntl","flock","fstat","fsync","ftruncate","getdents","getpeername","getsockname","getsockopt","listen","lseek","mmap","mmap2","map_pgoff","newfstat","read","readdir","readv","recv","recvfrom","send","sendfile64","sendto","setsockopt","shutdown","write","writev"]

codeFile = open("codeFile.c","w+")
for funcName in funcList:
	codeFile.write("\n    if(EQUAL == strcmp(glibcFuncName,\"" + str(funcName) + "\")){\n\n		errno = 0;\n		int fd = open(fName,O_WRONLY);\n		" + str(funcName) + "(fd,0,0);\n		VERIFY_ERRNO(\"" + str(funcName) + "\",expRetValue,errno)\n    }")

codeFile.close()
