import sys
sys.path.append("TestSuitBase/")
sys.path.append("FishTestSuit/")
from SystemcallController import SystemcallController
import subprocess
import time
import os
import signal
from pyExcelerator import *

resultExcel = Workbook()
ws0 = resultExcel.add_sheet("glibc single")
style = XFStyle()

pathSys = ["sys_access","sys_chdir","sys_chmod","sys_execve","sys_stat64","sys_mkdir","sys_mknod","sys_mount","sys_open","sys_readlink","sys_rename","sys_rmdir","sys_statfs","sys_symlink","sys_truncate","sys_mount","sys_newstat","sys_umount","sys_utime"]
fdSys = ["sys_accept","sys_accept4","sys_bind","sys_fchdir","sys_fchmod","sys_close","sys_connect","sys_dup","sys_dup2","sys_fcntl64","sys_flock","sys_fstat","sys_fsync","sys_ftruncate","sys_getdents","sys_getpeername","sys_getsockname","sys_getsockopt","sys_listen","sys_lseek","old_mmap","sys_mmap","sys_mmap2","sys_mmap_pgoff","sys_newfstat","sys_fstat64","sys_read","sys_readdir","sys_readv","sys_recv","sys_recvfrom","sys_send","sys_sendfile","sys_sendto","sys_setsockopt","sys_shutdown","sys_write","sys_writev"]

commandFilePath = "FishTestSuit/DataFiles/command.txt"
mapFilePath = "lib/map32.34"
unistdFilePath = "test/unistd_32_34.h"
pfdFilePath = "lib/pfd"
outPutFile = "output.txt"
noFNameFile = "noFname.txt"
ShouldFNameButNot = "ShouldFNameButNot.txt"
inFile = "inFile.txt"

lineIndex = int(sys.argv[1])
fOption = ''
tOption = ''
inType = '' #pid
if(len(sys.argv) >2):
	if(sys.argv[2] == '-f'):
		fOption = sys.argv[2]
	if(sys.argv[2] == '-t'):
		tOption = sys.argv[2]
		inType = 'pid'
	if(len(sys.argv) > 3):
		if(sys.argv[3] == '-f'):
			fOption = sys.argv[3]
		if(sys.argv[3] == '-t'):
			tOption = sys.argv[3]
			inType = 'pid'

fFile = 'aaa'


commandFile = open(commandFilePath)
commandContent = commandFile.readlines()

pfdFile = open(pfdFilePath)
pfdContent = pfdFile.readlines()
pfdFile.close()
sysController = SystemcallController("no_emu",mapFilePath,unistdFilePath)
outFd = open(outPutFile,"a+")
noFNameFile = open(noFNameFile,"a+")
sfFile = open(ShouldFNameButNot,"a+")
inFileFd = open(inFile,"a+")

def GetRealTargetProcPid(parentProc , mapFile):		
	
	queryCmd = 'pstree -p ' + str(parentProc.pid)
	queryProc = subprocess.Popen(queryCmd,shell = True,stdout = subprocess.PIPE,stderr = subprocess.PIPE)	
	queryProc.wait()
		
	output = queryProc.stdout.readlines()
	errput = queryProc.stderr.readlines()
			#analyze it with the actual output
	print(output)
	partsInfo = output[0].split(')')
	# pstree output is different format between suse(16) and ubuntu(32,34)
	if('16' in mapFile):
		middlePart = partsInfo[0]#suse
	else:
		middlePart = partsInfo[1]#ubuntu
	middlePartInfo = middlePart.split('(')
	finalPart = middlePartInfo[1]		
	return int(finalPart.replace(')','').replace('\n',''))
		
def GetInjectionCmd(fOption,tOption,basicCmd,targetPid,fFile):
	cmd = basicCmd + ' -n AllFuncTest '
	if('-t' == tOption):
		cmd = basicCmd + " -p " + str(targetPid)
		cmd = cmd + " -t 1"

	if('-f' == fOption):
		cmd = cmd+ " -f " + fFile

	return cmd

def FillInjectionOthers(lineIndex,mapFilePath,fOption,inType,style,ws0):
	if(inType == 'pid'):
		ws0.write(2*lineIndex,1,str((mapFilePath.split('p')[1])) + fOption+str('s')+"_"+str(lineIndex),style)
	else:
		ws0.write(2*lineIndex,1,str((mapFilePath.split('p')[1])) + fOption+str('ns')+"_"+str(lineIndex),style)
	ws0.write(2*lineIndex,2,'nofault',style)
	ws0.write(2*lineIndex,3,'installmod',style)
	ws0.write(2*lineIndex,4,'workDir',style)
	ws0.write(2*lineIndex,5,'root',style)
	if(inType == 'pid'):
		ws0.write(2*lineIndex,6,'pid',style)
	else:
		ws0.write(2*lineIndex,6,'pname',style)
	ws0.write(2*lineIndex,7,'shell',style)
	if('' == fOption):
		ws0.write(2*lineIndex,8,"expect:insuc,trisuc",style)
	elif('-f' == fOption and (syscallName in fdSys or syscallName in pathSys) ):
		ws0.write(2*lineIndex,8,"expect:insuc,trisuc",style)
	else:
		ws0.write(2*lineIndex,8,"expect:infail,trifail",style)

def FillRemoveOthers(lineIndex,mapFilePath,fOption,inType,style,ws0):
	if(inType == 'pid'):
		ws0.write(2*lineIndex + 1,1,str((mapFilePath.split('p')[1])) + fOption+str('sm')+"_"+str(lineIndex),style)
	else:
		ws0.write(2*lineIndex + 1,1,str((mapFilePath.split('p')[1])) + fOption+str('nsm')+"_"+str(lineIndex),style)
	ws0.write(2*lineIndex + 1,2,'has target fault',style)
	ws0.write(2*lineIndex + 1,3,'installmod',style)
	ws0.write(2*lineIndex + 1,4,'workDir',style)
	ws0.write(2*lineIndex + 1,5,'root',style)
	if(inType == 'pid'):
		ws0.write(2*lineIndex + 1,6,'pid',style)
	else:
		ws0.write(2*lineIndex + 1,6,'pname',style)
	ws0.write(2*lineIndex + 1,7,'shell',style)
	if('' == fOption):
		ws0.write(2*lineIndex + 1,8,"expect:resuc,Versuc",style)
	elif('-f' == fOption and (syscallName in fdSys or syscallName in pathSys) ):
		ws0.write(2*lineIndex + 1,8,"expect:resuc,Versuc",style)
	else:
		ws0.write(2*lineIndex + 1,8,"expect:refail,Verfail",style)


def FillInjectionActualResult(ws0,style,lineindex,injectionSuccess,injectionOut,workSuccess,workOut,fOption,syscallName,fdSys,pathSys):

	if('' == fOption):			
		if(not injectionSuccess):
			ws0.write(2*lineIndex,9,"actual:infail,trifail",style)
			ws0.write(2*lineIndex,13,"existF:exist",style)
			ws0.write(2*lineIndex,14,"depict:" + str(injectionOut[0]),style)
		elif(injectionSuccess and not workSuccess):
			ws0.write(2*lineIndex,9,"actual:insuc,trifail",style)
			ws0.write(2*lineIndex,13,"existF:exist",style)
			if(len(workOut) > 0):
				ws0.write(2*lineIndex,14,"depict:"+str(workOut[0]),style)
			else:
				ws0.write(2*lineIndex,14,"depitct:no output",style)
		else:
			ws0.write(2*lineIndex,9,"acutal:insuc,trisuc",style)
			ws0.write(2*lineIndex,13,"existF:none",style)
			
	elif('-f' == fOption):
		if(not injectionSuccess and (syscallName in fdSys or syscallName in pathSys)):
			ws0.write(2*lineIndex,9,"actual:infail,trifail",style)
			ws0.write(2*lineIndex,13,"existF:exist",style)
			ws0.write(2*lineIndex,14,"depict:" + str(injectionOut[0]),style)
		elif(not injectionSuccess and (not syscallName in fdSys and not syscallName in pathSys)):
			ws0.write(2*lineIndex,9,"actual:infail,trifail",style)
			ws0.write(2*lineIndex,13,"existF:none",style)
		elif(injectionSuccess and (syscallName in fdSys or syscallName in pathSys) and workSuccess):
			ws0.write(2*lineIndex,9,"actual:insuc,trisuc",style)
			ws0.write(2*lineIndex,13,"existF:none",style)
		elif(injectionSuccess and (syscallName in fdSys or syscallName in pathSys) and not workSuccess):
			ws0.write(2*lineIndex,9,"actual:insuc,trifail",style)
			ws0.write(2*lineIndex,13,"existF:exist",style)
			ws0.write(2*lineIndex,14,"depict:" + str(workOut[0]),style)
		elif(injectionSuccess and (not syscallName in fdSys and not syacallName in pathSys) and not workSuccess):
			ws0.write(2*lineIndex,9,"actual:insuc,trisuc",style)
			ws0.write(2*lineIndex,13,"existF:exist",style)
			ws0.write(2*lineIndex,14,"depict:should be rejected" ,style)	
		elif(injectionSuccess and (not syscallName in fdSys and not syacallName in pathSys) and workSuccess):
			ws0.write(2*lineIndex,9,"actual:insuc,trisuc",style)
			ws0.write(2*lineIndex,13,"existF:exist",style)
			ws0.write(2*lineIndex,14,"depict:should be rejected" ,style)



def FillRemoveAcutalResult(ws0,style,lineIndex,fOption,removeSuccess,removeOut,syscallName,fdSys,pathSys):
	if('' == fOption):
		if(True == removeSuccess ):
			ws0.write(2*lineIndex + 1,9,"actual:resuc,versuc",style)
			ws0.write(2*lineIndex + 1,13,"existF:none",style)
		else:
			ws0.write(2*lineIndex + 1,9,"acutal:refail,verfail",style)
			ws0.write(2*lineIndex + 1,13,"existF:exist",style)
			ws0.write(2*lineIndex + 1,14,"depict:" + str(removeOut[0]),style)

	elif('-f' == fOption):
			if(True == removeSuccess and (syscallName in fdSys or syscallName in pathSys)):
				ws0.write(2*lineIndex + 1,9,"actual:resuc,versuc",style)
				ws0.write(2*lineIndex + 1,13,"existF:none",style)
			elif(True == removeSuccess and (not syscallName in fdSys and not syscallName in pathSys)):
				ws0.write(2*lineIndex + 1,9,"acutal:resuc,versuc",style)
				ws0.write(2*lineIndex + 1,13,"existF:exist",style)
				ws0.write(2*lineIndex + 1,14,"depict:should be rejected ,remove out:" + ''.join(removeOut),style)	
			elif(False== removeSuccess and (not syscallName in fdSys and not syscallName in pathSys)):
				ws0.write(2*lineIndex + 1,9,"actual:refail,verfail",style)
				ws0.write(2*lineIndex + 1,13,"existF:none",style)
			elif(False == removeSuccess and (syscallName in fdSys or syscallName in pathSys)):
				ws0.write(2*lineIndex + 1,9,"acutal:refail,verfail",style)
				ws0.write(2*lineIndex + 1,13,"existF:exist",style)
				ws0.write(2*lineIndex + 1,14,"depict:" + str(removeOut[0]),style)

def GetRemoveCmd(cmd,lineIndex,tOption,ws0,style):
	removeCmd = cmd + " -m"
	if('' == tOption):
		ws0.write(2*lineIndex + 1,0,removeCmd,style)
	else:
		ws0.write(2*lineIndex + 1,0,'wait 1 second for fault-auto-removed',style)
	return removeCmd

while( lineIndex < len(commandContent)):
	columnIndex = 0;
	line = commandContent[lineIndex].replace("\n","")
	partsInfo = line.split(" ")

	while("" in partsInfo ):
		partsInfo.remove("")
	faultId = partsInfo[len(partsInfo) -1]
	if(1 != int(sysController.GetFaultType(int(faultId)))):
		print(faultId)
		lineIndex += 1
		continue

	syscallName = sysController.GetSyscallNameWithoutExechange(int(faultId))
	print("-----------------------------------------------------------------------------------")
	inFileFd.write("--------------------------------------------------------------------------------------\n")
	print(str(lineIndex) + ":" + syscallName) 
	inFileFd.write(str(lineIndex) + ":" + syscallName)
	inFileFd.write('\n')

	expRet = sysController.GetExpectedRetValue(int(faultId))
	if('-f' == fOption):
		workLoadCmd = "./AllFuncTest " + str(syscallName) +" " + str(expRet) + " " + fFile
	if('' == fOption):
		workLoadCmd = "./AllFuncTest " + str(syscallName) +" " + str(expRet)
	
	inFileFd.write("workLoad: " + workLoadCmd + "\n")
	print("workLoad:" + workLoadCmd)
	workProc = subprocess.Popen(workLoadCmd,shell = True,stdout = subprocess.PIPE)
	time.sleep(0.1)

	targetPid = GetRealTargetProcPid(workProc,mapFilePath)

	cmd = GetInjectionCmd(fOption,tOption,line,targetPid,fFile)
	inFileFd.write(cmd)
	inFileFd.write('\n')
	print(cmd)
	ws0.write(2*lineIndex,0,cmd,style)

	FillInjectionOthers(lineIndex,mapFilePath,fOption,inType,style,ws0)
	
	injectionProc = subprocess.Popen(cmd, shell = True,stdout = subprocess.PIPE)
	injectionProc.wait()
	injectionOut = injectionProc.stdout.readlines()
	injectionSuccess = 'succeed' in injectionOut[0]
	print(injectionOut)
	for line in injectionOut:
		inFileFd.write(line)
	inFileFd.write('\n')

	if(not injectionSuccess and (not syscallName in fdSys and not syscallName in pathSys) and '-f' == fOption):
		os.kill(targetPid,signal.SIGKILL)
	else:
		os.kill(targetPid,signal.SIGCONT)
	workProc.wait()
	workOut = workProc.stdout.readlines()
	if(len(workOut) > 0):
		workSuccess = 'succeed' in workOut[0]	
	else:
		workSuccess = True #no output because of correct injection
	FillInjectionActualResult(ws0,style,lineIndex,injectionSuccess,injectionOut,workSuccess,workOut,fOption,syscallName,fdSys,pathSys)

	print(workOut)
	for line in workOut:
		inFileFd.write(line)
	inFileFd.write('\n')

	FillRemoveOthers(lineIndex,mapFilePath,fOption,inType,style,ws0)

	if('-t' == tOption):
		time.sleep(2)
	removeCmd = GetRemoveCmd(cmd,lineIndex,tOption,ws0,style)
	removeProc = subprocess.Popen(removeCmd,shell = True, stdout = subprocess.PIPE)
	removeProc.wait()
	removeOut = removeProc.stdout.readlines()
	print(removeOut)
	removeSuccess = False
	if('' == tOption):
		removeSuccess = 'succeed' in removeOut[0]
	elif('-t' == tOption):
		if('' == fOption):
			removeSuccess = 'no such instance' in removeOut[0]
		elif('-f' == fOption and syscallName in fdSys or syscallName in pathSys):
			removeSuccess = 'no such instance' in removeOut[0]
		else:
			removeSuccess = False
			
	FillRemoveAcutalResult(ws0,style,lineIndex,fOption,removeSuccess,removeOut,syscallName,fdSys,pathSys)

	if('' == tOption):
		for line in removeOut:
			inFileFd.write(line)
		inFileFd.write('\n')
	lineIndex = lineIndex + 1;
	resultExcel.save("GlibcResult.xls")	
print("all done")
outFd.close()
noFNameFile.close()
sfFile.close()
resultExcel.save("GlibcResult.xls")
