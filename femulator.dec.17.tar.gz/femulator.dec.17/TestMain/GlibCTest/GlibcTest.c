#include <stdio.h>
#include <unistd.h>
#include <errno.h> 
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/statfs.h>
#include <sys/mount.h>
#include <utime.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <sys/mman.h>
#include <dirent.h>
#include <sys/syscall.h>

#define NO_ARGS -11
#define EQUAL  0

#define VERIFY_ERRNO(funcName,expRetValue,errno) 	{\
													hasTarget = 1;\
													if(0 == (expRetValue) + (errno)){ \
														printf("syscall:sys_%s,succeed\n",glibcFuncName);\
													}\		
													else{\
														printf("-------------syscall:sys_%s, function %s fail and actual errno:%d\n",glibcFuncName,funcName,-errno);\
													}\
													}	

#define VERIFY_FD(fd)	{\
						hasTarget = 1;\
						if(-1 == fd){\
							printf("------------------------syscall:sys_%s, fd:open file fail\n",glibcFuncName);\
							return -1;\
						 }\
						}


char * myArgv[] = {"test1","test2"};
char * myEnv[] = {"test1","test2"};
char c_buffer[20];
int buffer_size = 20;
int length_size = 20;
int hasTarget = 0;

int main(int argc , char * argv[]){

	if(argc < 4){
		printf("args: <sys_xxx> <ret value> <fName>\n");
		return NO_ARGS;
	}
	char * glibcFuncName = argv[1] + 4;
	int expRetValue = atoi(argv[2]);
	char * fName = argv[3];

	errno = 0 ;
	if(EQUAL == strcmp(glibcFuncName , "access")){	
		access(fName,R_OK);
		VERIFY_ERRNO("access",expRetValue,errno)
		
	}
	if(EQUAL == strcmp(glibcFuncName,"chdir")){
		chdir(fName);
		VERIFY_ERRNO("chdir",expRetValue,errno)
			
	}
	if(EQUAL == strcmp(glibcFuncName,"chmod")){
		chmod(fName,S_ISUID);
		VERIFY_ERRNO("chmod",expRetValue,errno)
	}
	if(EQUAL == strcmp(glibcFuncName,"execve")){
		execve(fName,myArgv,myEnv);
		VERIFY_ERRNO("execve",expRetValue,errno)
	}
	if(EQUAL == strcmp(glibcFuncName,"stat") || EQUAL == strcmp(glibcFuncName,"newstat")||EQUAL == strcmp(glibcFuncName,"stat64")||EQUAL == strcmp(glibcFuncName,"newstat64")){
		struct stat stat_buf;
		errno = 0;
		stat(fName,&stat_buf);
		VERIFY_ERRNO("stat",expRetValue,errno)

		errno = 0;
		lstat(fName,&stat_buf);
		VERIFY_ERRNO("lstat",expRetValue,errno)
	}
	if(EQUAL == strcmp(glibcFuncName,"mkdir")){
		mkdir(fName,0777);
		VERIFY_ERRNO("mkdir",expRetValue,errno)
	}
	if(EQUAL == strcmp(glibcFuncName,"mknod")){
		mknod(fName,0777,0);
		VERIFY_ERRNO("mknod",expRetValue,errno)
	}
	if(EQUAL == strcmp(glibcFuncName,"mount")){
		mount(fName,fName,fName,0,NULL);
		VERIFY_ERRNO("mount",expRetValue,errno)
	}
	if(EQUAL == strcmp(glibcFuncName,"open")){
		errno = 0;
		open(fName,O_RDONLY);
		VERIFY_ERRNO("open",expRetValue,errno)
		
		errno = 0;
		open(fName,O_RDONLY,0777);
		VERIFY_ERRNO("open",expRetValue,errno)
		
		errno = 0;
		creat(fName,0777);
		VERIFY_ERRNO("open",expRetValue,errno)
	}
	if(EQUAL == strcmp(glibcFuncName,"readlink")){
		readlink(fName,c_buffer,buffer_size);
		VERIFY_ERRNO("readlink",expRetValue,errno)
	}
	if(EQUAL == strcmp(glibcFuncName,"rename")){
		rename(fName,fName);
		VERIFY_ERRNO("rename",expRetValue,errno);
	}
	if(EQUAL == strcmp(glibcFuncName,"rmdir")){
		rmdir(fName);
		VERIFY_ERRNO("rmdir",expRetValue,errno);
	}
	if(EQUAL == strcmp(glibcFuncName,"statfs")){
		struct statfs b_statfs;
		statfs(fName,&b_statfs);
		VERIFY_ERRNO("statfs",expRetValue,errno)
	}
	if(EQUAL == strcmp(glibcFuncName,"symlink")){
		symlink(fName,fName);
		VERIFY_ERRNO("symlink",expRetValue,errno)
	}
	if(EQUAL == strcmp(glibcFuncName,"truncate")){
		truncate(fName,length_size);
		VERIFY_ERRNO("truncate",expRetValue,errno)
	}
	if(EQUAL == strcmp(glibcFuncName,"umount") || EQUAL == strcmp(glibcFuncName,"umount2")){
		errno = 0;
		umount(fName);
		VERIFY_ERRNO("umount",expRetValue,errno);

		errno = 0;
		umount2(fName,MNT_EXPIRE);
		VERIFY_ERRNO("umount2",expRetValue,errno);
	}
	if(EQUAL == strcmp(glibcFuncName,"utime")){
		errno = 0;
		struct utimbuf b_utimbuf;
		utime(fName,&b_utimbuf);
		VERIFY_ERRNO("utime",expRetValue,errno)

		errno = 0;
		struct timeval b_timeval;
		utimes(fName,&b_timeval);
		VERIFY_ERRNO("utimes",expRetValue,errno)
	}
	if(EQUAL == strcmp(glibcFuncName,"accept") || EQUAL == strcmp(glibcFuncName,"accept4")){
		errno = 0;
		int sockfd = open(fName,O_WRONLY);
		VERIFY_FD(sockfd)
		accept(sockfd, 0,0);
		VERIFY_ERRNO("accept",expRetValue,errno)

		errno = 0;
		accept4(sockfd,0,0,0);
		VERIFY_ERRNO("accept4",expRetValue,errno)
		close(sockfd);
	}

	
    
    if(EQUAL == strcmp(glibcFuncName,"bind")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		bind(fd,0,0);
		VERIFY_ERRNO("bind",expRetValue,errno)
		
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"fchdir")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		fchdir(fd);
		VERIFY_ERRNO("fchdir",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"fchmod")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		fchmod(fd,0);
		close(fd);
		VERIFY_ERRNO("fchmod",expRetValue,errno)
    }
    if(EQUAL == strcmp(glibcFuncName,"close")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		close(fd);
		VERIFY_ERRNO("close",expRetValue,errno)
    }
    if(EQUAL == strcmp(glibcFuncName,"connect")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		connect(fd,0,0);
		VERIFY_ERRNO("connect",expRetValue,errno)
			close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"dup")|| EQUAL == strcmp(glibcFuncName,"dup2")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		dup(fd);
		VERIFY_ERRNO("dup",expRetValue,errno)
		
		dup2(fd,0);
		VERIFY_ERRNO("dup1",expRetValue,errno)

		dup3(fd,0,0);
		VERIFY_ERRNO("dup2",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"fcntl64")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		fcntl(fd,0,0);
		close(fd);
		VERIFY_ERRNO("fcntl",expRetValue,errno)
    }
    if(EQUAL == strcmp(glibcFuncName,"flock")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		flock(fd,0);
		close(fd);
		VERIFY_ERRNO("flock",expRetValue,errno)
    }
    if(EQUAL == strcmp(glibcFuncName,"fstat")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		fstat(fd,0);
		close(fd);
		VERIFY_ERRNO("fstat",expRetValue,errno)
    }
    if(EQUAL == strcmp(glibcFuncName,"fsync")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		fsync(fd);
		VERIFY_ERRNO("fsync",expRetValue,errno)

		errno = 0;
		VERIFY_ERRNO("fdatasync",expRetValue,errno);
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"ftruncate")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		ftruncate(fd,0);
		VERIFY_ERRNO("ftruncate",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"getdents")){

		errno = 0;
		struct DIR *fd = opendir(fName); 
		VERIFY_FD(fd)
		readdir(fd);
		
		VERIFY_ERRNO("getdents",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"getpeername")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		getpeername(fd,0,0);
		VERIFY_ERRNO("getpeername",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"getsockname")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		getsockname(fd,0,0);
		VERIFY_ERRNO("getsockname",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"getsockopt")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		getsockopt(fd,0,0,0,0);
		VERIFY_ERRNO("getsockopt",expRetValue,errno)
		close(fd);

    }
    if(EQUAL == strcmp(glibcFuncName,"listen")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		listen(fd,0);
		VERIFY_ERRNO("listen",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"lseek")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		lseek(fd,0,0);
		VERIFY_ERRNO("lseek",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"mmap")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		mmap(0,0,0,0,fd,0);
		VERIFY_ERRNO("mmap",expRetValue,errno)
		close(fd);

    }
    if(EQUAL == strcmp(glibcFuncName,"mmap2")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		mmap(0,0,0,0,fd,0);
		VERIFY_ERRNO("mmap2",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"map_pgoff")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		mmap(0,0,0,0,fd,0);
		VERIFY_ERRNO("map",expRetValue,errno)
		close(fd);

		//errno = 0;
		//mmap2(0,0,0,0,fd,0);
		//VERIFY_ERRNO("mmap2",expRetValue,errno);
    }

    if(EQUAL == strcmp(glibcFuncName,"newfstat")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		fstat(fd,0);
		VERIFY_ERRNO("fstat",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"read")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		
		VERIFY_FD(fd)
		read(fd,0,0);
		VERIFY_ERRNO("read",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"readdir")){

		errno = 0;
		struct DIR *fd = opendir(fName); 
		VERIFY_FD(fd)
		readdir(fd);
		VERIFY_ERRNO("readdir",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"readv")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		readv(fd,0,0);
		VERIFY_ERRNO("readv",expRetValue,errno)
		close(fd);

    }
    if(EQUAL == strcmp(glibcFuncName,"recv")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		recv(fd,0,0,0);
		VERIFY_ERRNO("recv",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"recvfrom")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		recvfrom(fd,0,0,0,0,0);
		close(fd);
		VERIFY_ERRNO("recvfrom",expRetValue,errno)
    }
    if(EQUAL == strcmp(glibcFuncName,"send")){

		errno = 0;
	
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		send(fd,0,0,0);
		VERIFY_ERRNO("send",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"sendfile64")){

		errno = 0;

		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
				
		sendfile64(fd,fd,0,0);
		VERIFY_ERRNO("sendfile64",expRetValue,errno)		
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"sendto")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		sendto(fd,0,0,0,0,0);
		VERIFY_ERRNO("sendto",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"setsockopt")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		setsockopt(fd,0,0,0,0);
		VERIFY_ERRNO("setsockopt",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"shutdown")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		shutdown(fd,0);
		VERIFY_ERRNO("shutdown",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"write")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		write(fd,0,0);
		VERIFY_ERRNO("write",expRetValue,errno)
		close(fd);
    }
    if(EQUAL == strcmp(glibcFuncName,"writev")){

		errno = 0;
		int fd = open(fName,O_WRONLY);
		VERIFY_FD(fd)
		writev(fd,0,0);
		VERIFY_ERRNO("writev",expRetValue,errno)
		close(fd);
    }
	if(0 == hasTarget){
		printf("========================can not find here: %s=======================\n",glibcFuncName);
	}
	return 0;
}


