	if(EQUAL == strcmp(syscall, "sys_clone")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            clone(0,0,0);
            VERIFY_ERRNO("clone",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_getsockopt64")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            getsockopt64(0,0,0);
            VERIFY_ERRNO("getsockopt64",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_msgrcv")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            msgrcv(0,0,0);
            VERIFY_ERRNO("msgrcv",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_sendto")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sendto(0,0,0);
            VERIFY_ERRNO("sendto",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_capget")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            capget(0,0,0);
            VERIFY_ERRNO("capget",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_open")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            open(0,0,0);
            VERIFY_ERRNO("open",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_pipe")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            pipe(0,0,0);
            VERIFY_ERRNO("pipe",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_reboot")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            reboot(0,0,0);
            VERIFY_ERRNO("reboot",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_sethostname")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sethostname(0,0,0);
            VERIFY_ERRNO("sethostname",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_getpgid")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            getpgid(0,0,0);
            VERIFY_ERRNO("getpgid",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_newuname")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            newuname(0,0,0);
            VERIFY_ERRNO("newuname",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_newstat")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            newstat(0,0,0);
            VERIFY_ERRNO("newstat",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_sched_getparam")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sched_getparam(0,0,0);
            VERIFY_ERRNO("sched_getparam",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_newfstat")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            newfstat(0,0,0);
            VERIFY_ERRNO("newfstat",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_umount")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            umount(0,0,0);
            VERIFY_ERRNO("umount",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_setsockopt")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            setsockopt(0,0,0);
            VERIFY_ERRNO("setsockopt",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_select")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            select(0,0,0);
            VERIFY_ERRNO("select",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_setpriority")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            setpriority(0,0,0);
            VERIFY_ERRNO("setpriority",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "do_shmat")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            hmat(0,0,0);
            VERIFY_ERRNO("hmat",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_stat64")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            stat64(0,0,0);
            VERIFY_ERRNO("stat64",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_socketpair")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            socketpair(0,0,0);
            VERIFY_ERRNO("socketpair",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_personality")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            personality(0,0,0);
            VERIFY_ERRNO("personality",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_wait4")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            wait4(0,0,0);
            VERIFY_ERRNO("wait4",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_semtimedop")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            semtimedop(0,0,0);
            VERIFY_ERRNO("semtimedop",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_shutdown")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            shutdown(0,0,0);
            VERIFY_ERRNO("shutdown",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_execve")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            execve(0,0,0);
            VERIFY_ERRNO("execve",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_readlink")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            readlink(0,0,0);
            VERIFY_ERRNO("readlink",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_truncate")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            truncate(0,0,0);
            VERIFY_ERRNO("truncate",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_fchmod")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            fchmod(0,0,0);
            VERIFY_ERRNO("fchmod",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_read")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            read(0,0,0);
            VERIFY_ERRNO("read",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_semctl")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            semctl(0,0,0);
            VERIFY_ERRNO("semctl",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_nice")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            nice(0,0,0);
            VERIFY_ERRNO("nice",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_statfs")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            statfs(0,0,0);
            VERIFY_ERRNO("statfs",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_sched_get_priority_max")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sched_get_priority_max(0,0,0);
            VERIFY_ERRNO("sched_get_priority_max",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_recvfrom")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            recvfrom(0,0,0);
            VERIFY_ERRNO("recvfrom",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_fsync")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            fsync(0,0,0);
            VERIFY_ERRNO("fsync",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_mremap")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mremap(0,0,0);
            VERIFY_ERRNO("mremap",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_poll")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            poll(0,0,0);
            VERIFY_ERRNO("poll",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_sched_getscheduler")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sched_getscheduler(0,0,0);
            VERIFY_ERRNO("sched_getscheduler",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_sched_rr_get_interval")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sched_rr_get_interval(0,0,0);
            VERIFY_ERRNO("sched_rr_get_interval",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_access")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            access(0,0,0);
            VERIFY_ERRNO("access",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_mmap2")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mmap2(0,0,0);
            VERIFY_ERRNO("mmap2",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_rename")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            rename(0,0,0);
            VERIFY_ERRNO("rename",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_flock")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            flock(0,0,0);
            VERIFY_ERRNO("flock",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_getsockname")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            getsockname(0,0,0);
            VERIFY_ERRNO("getsockname",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_brk")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            brk(0,0,0);
            VERIFY_ERRNO("brk",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_fchdir")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            fchdir(0,0,0);
            VERIFY_ERRNO("fchdir",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_utime")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            utime(0,0,0);
            VERIFY_ERRNO("utime",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_kill")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            kill(0,0,0);
            VERIFY_ERRNO("kill",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_mmap_pgoff")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mmap_pgoff(0,0,0);
            VERIFY_ERRNO("mmap_pgoff",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_getpeername")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            getpeername(0,0,0);
            VERIFY_ERRNO("getpeername",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_close")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            close(0,0,0);
            VERIFY_ERRNO("close",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_rt_sigaction")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            rt_sigaction(0,0,0);
            VERIFY_ERRNO("rt_sigaction",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_dup2")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            dup2(0,0,0);
            VERIFY_ERRNO("dup2",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_mkdir")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mkdir(0,0,0);
            VERIFY_ERRNO("mkdir",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_mknod")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mknod(0,0,0);
            VERIFY_ERRNO("mknod",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_setpgid")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            setpgid(0,0,0);
            VERIFY_ERRNO("setpgid",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_getsockopt")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            getsockopt(0,0,0);
            VERIFY_ERRNO("getsockopt",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_ftruncate")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            ftruncate(0,0,0);
            VERIFY_ERRNO("ftruncate",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_shmget")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            shmget(0,0,0);
            VERIFY_ERRNO("shmget",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_ptrace")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            ptrace(0,0,0);
            VERIFY_ERRNO("ptrace",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_write")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            write(0,0,0);
            VERIFY_ERRNO("write",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_mount")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mount(0,0,0);
            VERIFY_ERRNO("mount",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_writev")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            writev(0,0,0);
            VERIFY_ERRNO("writev",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_rmdir")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            rmdir(0,0,0);
            VERIFY_ERRNO("rmdir",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_chmod")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            chmod(0,0,0);
            VERIFY_ERRNO("chmod",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_pause")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            pause(0,0,0);
            VERIFY_ERRNO("pause",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_socket")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            socket(0,0,0);
            VERIFY_ERRNO("socket",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_getdents")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            getdents(0,0,0);
            VERIFY_ERRNO("getdents",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_msync")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            msync(0,0,0);
            VERIFY_ERRNO("msync",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_shmat")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            shmat(0,0,0);
            VERIFY_ERRNO("shmat",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_rt_sigprocmask")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            rt_sigprocmask(0,0,0);
            VERIFY_ERRNO("rt_sigprocmask",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_readv")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            readv(0,0,0);
            VERIFY_ERRNO("readv",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_connect")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            connect(0,0,0);
            VERIFY_ERRNO("connect",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_semget")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            semget(0,0,0);
            VERIFY_ERRNO("semget",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_mmap")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mmap(0,0,0);
            VERIFY_ERRNO("mmap",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_setdomainname")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            setdomainname(0,0,0);
            VERIFY_ERRNO("setdomainname",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_getsid")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            getsid(0,0,0);
            VERIFY_ERRNO("getsid",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_sched_get_priority_min")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sched_get_priority_min(0,0,0);
            VERIFY_ERRNO("sched_get_priority_min",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_uname")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            uname(0,0,0);
            VERIFY_ERRNO("uname",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_accept")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            accept(0,0,0);
            VERIFY_ERRNO("accept",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_munmap")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            munmap(0,0,0);
            VERIFY_ERRNO("munmap",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_bind")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            bind(0,0,0);
            VERIFY_ERRNO("bind",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_fstat64")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            fstat64(0,0,0);
            VERIFY_ERRNO("fstat64",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_rt_sigsuspend")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            rt_sigsuspend(0,0,0);
            VERIFY_ERRNO("rt_sigsuspend",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_mprotect")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mprotect(0,0,0);
            VERIFY_ERRNO("mprotect",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_listen")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            listen(0,0,0);
            VERIFY_ERRNO("listen",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_getpriority")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            getpriority(0,0,0);
            VERIFY_ERRNO("getpriority",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_shmdt")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            shmdt(0,0,0);
            VERIFY_ERRNO("shmdt",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_lseek")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            lseek(0,0,0);
            VERIFY_ERRNO("lseek",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_ustat")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            ustat(0,0,0);
            VERIFY_ERRNO("ustat",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_mlock")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            mlock(0,0,0);
            VERIFY_ERRNO("mlock",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_prctl")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            prctl(0,0,0);
            VERIFY_ERRNO("prctl",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_dup")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            dup(0,0,0);
            VERIFY_ERRNO("dup",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_munlock")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            munlock(0,0,0);
            VERIFY_ERRNO("munlock",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_sendfile")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sendfile(0,0,0);
            VERIFY_ERRNO("sendfile",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_nanosleep")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            nanosleep(0,0,0);
            VERIFY_ERRNO("nanosleep",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_symlink")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            symlink(0,0,0);
            VERIFY_ERRNO("symlink",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_chdir")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            chdir(0,0,0);
            VERIFY_ERRNO("chdir",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_fcntl64")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            fcntl64(0,0,0);
            VERIFY_ERRNO("fcntl64",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_accept4")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            accept4(0,0,0);
            VERIFY_ERRNO("accept4",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_fcntl")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            fcntl(0,0,0);
            VERIFY_ERRNO("fcntl",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_shmctl")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            shmctl(0,0,0);
            VERIFY_ERRNO("shmctl",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_sendfile64")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            sendfile64(0,0,0);
            VERIFY_ERRNO("sendfile64",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_quotactl")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            quotactl(0,0,0);
            VERIFY_ERRNO("quotactl",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_msgctl")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            msgctl(0,0,0);
            VERIFY_ERRNO("msgctl",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_msgget")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            msgget(0,0,0);
            VERIFY_ERRNO("msgget",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_modify_ldt")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            modify_ldt(0,0,0);
            VERIFY_ERRNO("modify_ldt",expRetValue,errno)
	}

	if(EQUAL == strcmp(syscall, "sys_msgsnd")){
            errno = 0;
            kill(getpid(),SIGSTOP);
            msgsnd(0,0,0);
            VERIFY_ERRNO("msgsnd",expRetValue,errno)
	}

