import sys
sys.path.append('TestSuitBase/')
sys.path.append('MultiFaultTestSuit/')

from MultiFaultTestController import MultiFaultTestController
from MultiConfigurator import MultiConfigurator	
import GlobalDefinition
print('*********************************multi fault injection test*******************************\n')

multiConfigurator = MultiConfigurator(GlobalDefinition.CONFIGURATION_FILE,GlobalDefinition.MAP_FILE_64_16_KEY,GlobalDefinition.UNISTD_64_16_FILE_KEY,GlobalDefinition.PID_EXECUTOR_TYPE)

multiFaultTestController = MultiFaultTestController(multiConfigurator)
multiFaultTestController.StartTest(100,5)
