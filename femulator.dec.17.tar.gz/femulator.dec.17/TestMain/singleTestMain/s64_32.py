import sys
sys.path.append('TestSuitBase/')
sys.path.append('FishTestSuit/')

from Configurator import Configurator 
from TestController import TestController
import GlobalDefinition

configurator = Configurator(GlobalDefinition.CONFIGURATION_FILE,GlobalDefinition.MAP_FILE_64_32_KEY,GlobalDefinition.UNISTD_64_32_FILE_KEY,GlobalDefinition.PID_EXECUTOR_TYPE)

testController = TestController(configurator)
testController.StartTest()
