"""Global define"""
global OPEN_FILE_SUCCESS 
OPEN_FILE_SUCCESS = 'open file successfully'
global OPEN_FILE_FAIL 
OPEN_FILE_FAIL = 'open file fail'
global LINE_SEPERATOR
LINE_SEPERATOR = '\n'
global FILE_END_LINE
FILE_END_LINE = ''
global INVALID_INJECTION_CMD
INVALID_INJECTION_CMD = 'invalid injection cmd'
global INVALID_SYSCALL_CMD
INVALID_SYSCALL_CMD = 'invalid syscall cmd'
global SPACE_SYMBOL
SPACE_SYMBOL = ' '
global INVALID_PID
INVALID_PID  = -1

global INJECTION_BY_PID_OPTION
INJECTION_BY_PID_OPTION = '-p'
global INJECTION_BY_PNAME_OPTION
INJECTION_BY_PNAME_OPTION = '-n'


"""CmdExecutor define"""
global INJECTION_SUCCESS 
INJECTION_SUCCESS = 'injection successful'
global INJECTION_TIMEOUT
INJECTION_TIMEOUT = 'injection timeout'
global INJECTION_FAIL
INJECTION_FAIL = 'injection fail'
global ACTION_SUCCESS
ACTION_SUCCESS = 'action success'
global ACTION_FAIL
ACTION_FAIL = 'action fail'

global SLEEP_TIME_INTERVAL 
SLEEP_TIME_INTERVAL = 0.1
global TIMEOUT_VALUE
TIMEOUT_VALUE = 5
global INVALID_RET_VALUE_STR 
INVALID_RET_VALUE_STR = '-1011'

global PID_EXECUTOR_TYPE
PID_EXECUTOR_TYPE = 'pid'
global PNAME_EXECUTOR_TYPE
PNAME_EXECUTOR_TYPE = 'pName'

global INJECTION_OUTPUT_TAG
INJECTION_OUTPUT_TAG = 'injection:\n'
global REMOVE_OUTPUT_TAG
REMOVE_OUTPUT_TAG = 'remove injection:\n'


global T1_OPTION 
T1_OPTION = '-T1'
global T2_OPTION 
T2_OPTION = '-T2'
global NO_T 
NO_T = ' '
global REMOVE_OPTION 
REMOVE_OPTION = '-m'

"""CmdManager define"""
global CURSOR_INDEX_INVALID 
CURSOR_INDEX_INVALID = 'cursor index invalid'
global END_OF_FILE 
END_OF_FILE = 'end of file'
global ADJUST_SUCCESS 
ADJUST_SUCCESS = 'adjust successfully'
global INVALID_FILE
INVALID_FILE = 'invalid file'
global INVALID_INDEX 
INVALID_INDEX = -1

"""InjectionTracer define"""
global COLON_SYMBOL
COLON_SYMBOL = ':'
global TRACE_SUCCESSFUL_STR
TRACE_SUCCESSFUL_STR = 'trace succesful'
global LAST_COMMAND_SURVIVE
LAST_COMMAND_SURVIVE = 'survive'
global LAST_COMMAND_DIE 
LAST_COMMAND_DIE = 'die'
global COMMAND_INDEX_TRACE_LINE_INDEX
COMMAND_INDEX_TRACE_LINE_INDEX = 1
global LAST_COMMAND_STATUS_TRACE_LINE_INDEX
LAST_COMMAND_STATUS_TRACE_LINE_INDEX = 0

"""Configurator define"""
global CONFIGURATION_FILE
CONFIGURATION_FILE = 'TestSuitBase/Configuration.txt' # same location with Configurator.py
global ANNOTATION_SYMBOL
ANNOTATION_SYMBOL = '#'

global KEY_INDEX 
KEY_INDEX = 0
global VALUE_INDEX 
VALUE_INDEX = 1

#xxx:ccc -> xxx is key;ccc is value [IN Configuration.txt]
#single------------------------------------------------------------------------------------------------------
global PID_RESULT_FILE_KEY 
PID_RESULT_FILE_KEY = 'PidResultFile'
global PID_INJECTION_FAIL_FILE_KEY 
PID_INJECTION_FAIL_FILE_KEY = 'PidInjectinFailFile'
global PID_SYSCALL_FAIL_FILE_KEY 
PID_SYSCALL_FAIL_FILE_KEY  = 'PidSyscallFailFile'
global PNAME_RESULT_FILE_KEY 
PNAME_RESULT_FILE_KEY = 'PnameResultFile'
global PNAME_INJECTION_FAIL_FILE_KEY 
PNAME_INJECTION_FAIL_FILE_KEY = 'PnameInjectinFailFile'
global PNAME_SYSCALL_FAIL_FILE_KEY 
PNAME_SYSCALL_FAIL_FILE_KEY  = 'PnameSyscallFailFile'

global TRACE_FILE_KEY
TRACE_FILE_KEY = 'traceFile'
global COMMAND_FILE_KEY
COMMAND_FILE_KEY = 'commandFile'
global SYSTEMCALL_EMU_FILE_KEY
SYSTEMCALL_EMU_FILE_KEY = 'systemcallEmuFile'

#multi----------------------------------------------------------------------------------------------------------------
global MULTI_PID_RESULT_FILE_KEY 
MULTI_PID_RESULT_FILE_KEY = 'MultiPidResultFile'
global MULTI_PID_INJECTION_FAIL_FILE_KEY 
MULTI_PID_INJECTION_FAIL_FILE_KEY = 'MultiPidInjectinFailFile'
global MULTI_PID_SYSCALL_FAIL_FILE_KEY 
MULTI_PID_SYSCALL_FAIL_FILE_KEY  = 'MultiPidSyscallFailFile'
global MULTI_PNAME_RESULT_FILE_KEY 
MULTI_PNAME_RESULT_FILE_KEY = 'MultiPnameResultFile'
global MULTI_PNAME_INJECTION_FAIL_FILE_KEY 
MULTI_PNAME_INJECTION_FAIL_FILE_KEY = 'MultiPnameInjectinFailFile'
global MULTI_PNAME_SYSCALL_FAIL_FILE_KEY 
MULTI_PNAME_SYSCALL_FAIL_FILE_KEY  = 'MultiPnameSyscallFailFile'

global MULTI_SYSTEMCALL_EMU_FILE_KEY
MULTI_SYSTEMCALL_EMU_FILE_KEY = 'MultiSystemcallEmuFile'
#public -----------------------------------------------------------------------------------------------------------
global EXECUTOR_TYPE_KEY
EXECUTOR_TYPE_KEY = 'ExecutorType'

global MAP_FILE_64_16_KEY
MAP_FILE_64_16_KEY = 'mapFile_64_16'
global MAP_FILE_64_32_KEY
MAP_FILE_64_32_KEY = 'mapFile_64_32'
global MAP_FILE_64_34_KEY
MAP_FILE_64_34_KEY = 'mapFile_64_34'
global MAP_FILE_32_16_KEY
MAP_FILE_32_16_KEY = 'mapFile_32_16'
global MAP_FILE_32_32_KEY
MAP_FILE_32_32_KEY = 'mapFile_32_32'
global MAP_FILE_32_34_KEY
MAP_FILE_32_34_KEY = 'mapFile_32_34'

global UNISTD_32_16_FILE_KEY
UNISTD_32_16_FILE_KEY = 'unistdFile_32_16'
global UNISTD_32_34_FILE_KEY
UNISTD_32_34_FILE_KEY = 'unistdFile_32_34'
global UNISTD_64_16_FILE_KEY
UNISTD_64_16_FILE_KEY = 'unistdFile_64_16'
global UNISTD_64_34_FILE_KEY
UNISTD_64_34_FILE_KEY = 'unistdFile_64_34'
global UNISTD_64_32_FILE_KEY
UNISTD_64_32_FILE_KEY = 'unistdFile_64_32'
global UNISTD_32_32_FILE_KEY
UNISTD_32_32_FILE_KEY = 'unistdFile_32_32'

global NO_STOP_FILE_SUFFIX
NO_STOP_FILE_SUFFIX = 'nsemu'
global WITH_STOP_FILE_SUFFIX
WITH_STOP_FILE_SUFFIX = 'emu'

global BIT_64
BIT_64 = 'bit 64'
global BIT_3
BIT_32 = 'bit 32'


"""SystemcallController"""
global FAULT_ACTION_ID_INDEX_IN_INJECTION_CMD 
FAULT_ACTION_ID_INDEX_IN_INJECTION_CMD = 2

global INVALID_FAULT_ACTION_ID
INVALID_FAULT_ACTION_ID = -111

global FAULT_ACTION_ID_INDEX_IN_MAP_LINE
FAULT_ACTION_ID_INDEX_IN_MAP_LINE = 0
global SYSCALL_NAME_INDEX_IN_MAP_LINE
SYSCALL_NAME_INDEX_IN_MAP_LINE = 1
global EXPECTED_RETURN_VALUE_INDEX_IN_MAP_LINE
EXPECTED_RETURN_VALUE_INDEX_IN_MAP_LINE = 2
global FAULT_TYPE_INDEX_IN_MAP_LINE  # DELAY OR NORMAL
FAULT_TYPE_INDEX_IN_MAP_LINE = 3
global NO_MAPPING_LINE
NO_MAPPING_LINE = 'no mapping line'

global DELAY_FAULT_TYPE 
DELAY_FAULT_TYPE = 2
global RET_FAULT_TYPE 
RET_FAULT_TYPE = 1

"""syscall classification """
global SOCKET_SYSCALL 
SOCKET_SYSCALL = 'socket syscall'
global IPC_SYSCALL 
IPC_SYSCALL = 'ipc syscall'
global NORMAL_SYSCALL 
NORMAL_SYSCALL = 'normal syscall'






