import GlobalDefinition
import os
from pyExcelerator import *
import time 
global IS_SYNC
IS_SYNC =False

class ResultAnalyzer:
	def __init__(self,outputInfoFile,injectionFailFile,syscallFailFile):
		self.outputInfoFile = outputInfoFile
		self.injectionFailFile = injectionFailFile
		self.syscallFailFile = syscallFailFile
		self.excelFile = outputInfoFile +str(time.time()) + '.xls'

		self.excel = Workbook()
		self.sheet = self.excel.add_sheet(outputInfoFile)
		self.style = XFStyle()
	
	def XlsSave(self):
		self.excel.save(self.excelFile)
		pass
	
	def XlsWrite(self,row,column,content):
		self.sheet.write(row,column,content,self.style)

	def RecordOutputInfo(self,outputInfo):
		if(True == IS_SYNC):
			outputInfoFileHandler = os.open(self.outputInfoFile,os.O_RDWR|os.O_APPEND|os.O_SYNC|os.O_CREAT)
		else:
			outputInfoFileHandler = os.open(self.outputInfoFile,os.O_RDWR|os.O_APPEND|os.O_CREAT)		
	
		if(not outputInfoFileHandler):
			print('cannot open:' + self.outputInfoFile)
			raise Exception
	
		for line in outputInfo:
			os.write(outputInfoFileHandler,str(line))
			if(True == IS_SYNC):
				os.fsync(injectionFailFileHandler)
		os.close(outputInfoFileHandler)

	def RecordInjectionFailInfo(self,injectionFailInfo):
		if(True == IS_SYNC):
			injectionFailFileHandler = os.open(self.injectionFailFile,os.O_RDWR|os.O_APPEND|os.O_SYNC|os.O_CREAT)
		else:
			injectionFailFileHandler = os.open(self.injectionFailFile,os.O_RDWR|os.O_APPEND|os.O_CREAT)	
		if(not injectionFailFileHandler):
			print('cannot open:' + self.injectionFailFile)
			raise Exception
		for line in injectionFailInfo:
			os.write(injectionFailFileHandler,str(line))
			if(True == IS_SYNC):
				os.fsync(injectionFailFileHandler)
		os.close(injectionFailFileHandler)

	def RecordSyscallFailInfo(self,syscallFailInfo):
		if(True == IS_SYNC):
			syscallFailFileHandler = os.open(self.syscallFailFile,os.O_RDWR|os.O_APPEND|os.O_SYNC|os.O_CREAT)
		else:
			syscallFailFileHandler = os.open(self.syscallFailFile,os.O_RDWR|os.O_APPEND|os.O_CREAT)	
		if(not syscallFailFileHandler):
			print('cannot open:' + self.syscallFailFile)
			raise Exception
	
		for line in syscallFailInfo:
			os.write(syscallFailFileHandler,str(line))
			if(True == IS_SYNC):
				os.fsync(syscallFailFileHandler)
		os.close(syscallFailFileHandler)
