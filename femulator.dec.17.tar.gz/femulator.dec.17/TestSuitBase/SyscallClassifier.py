import GlobalDefinition

class SyscallClassifier:
	
	sockcall = ["sys_socket","sys_bind" ,"sys_connect","sys_listen","sys_accept","sys_accept4","sys_getsockname","sys_getpeername","sys_socketpair","sys_send","sys_recv","sys_sendto","sys_recvfrom","sys_getsockopt","sys_shutdown","sys_setsockopt","sys_sendmsg","sys_recvmsg"]
	
	ipccall = ["sys_semctl","sys_semtimedop","sys_semget","sys_msgctl","sys_msgget","sys_msgsnd","sys_msgrcv","sys_shmat","sys_shmdt","sys_shmget","sys_shmctl" ]
	
	TOptionDict = {GlobalDefinition.SOCKET_SYSCALL:GlobalDefinition.NO_T,GlobalDefinition.IPC_SYSCALL:GlobalDefinition.T2_OPTION,GlobalDefinition.NORMAL_SYSCALL:GlobalDefinition.T1_OPTION}	

	syscallExchangeList = {"do_shmat":"sys_shmat","sys_newstat":"sys_stat","sys_newfstat":"sys_fstat","sys_newuname":"sys_uname","sys_umount":"sys_umount2","sys_mmap_pgoff":"sys_mmap2","sys_accept4":"sys_accept"}
		
	syscallExchangeList_64 = {"sys_sendfile64":"sys_sendfile"}

	emuFile = {GlobalDefinition.SOCKET_SYSCALL:'sockcall_emu' , GlobalDefinition.IPC_SYSCALL:'ipccall_emu',GlobalDefinition.NORMAL_SYSCALL:'syscall_emu'}
	@staticmethod
	def GetSyscallClassification(syscallName,bitVersion):
		syscallName = SyscallClassifier.SyscallNameExchange(syscallName,bitVersion) # classified by valid syscallname after exchanging

		if(GlobalDefinition.BIT_64 == bitVersion):
			return GlobalDefinition.NORMAL_SYSCALL
		if(syscallName in SyscallClassifier.sockcall):
			return GlobalDefinition.SOCKET_SYSCALL
		if(syscallName in SyscallClassifier.ipccall):
			return GlobalDefinition.IPC_SYSCALL

		return GlobalDefinition.NORMAL_SYSCALL	
	
	@staticmethod
	def GetTOptionBySyscall(syscallName,bitVersion):
		return SyscallClassifier.TOptionDict[SyscallClassifier.GetSyscallClassification(syscallName,bitVersion)]

	@staticmethod
	def SyscallNameExchange(syscallName,bitVersion):
		
		for key in SyscallClassifier.syscallExchangeList:
			if(syscallName == key):
				return SyscallClassifier.syscallExchangeList[syscallName]
		
		if(bitVersion == GlobalDefinition.BIT_64):
			for key in SyscallClassifier.syscallExchangeList_64:
				if(syscallName == key):
					return SyscallClassifier.syscallExchangeList_64[syscallName]

		return syscallName

	@staticmethod
	def GetTargetEmuFile(syscallName,bitVersion):
		if(GlobalDefinition.BIT_64 == bitVersion):
			return SyscallClassifier.emuFile[GlobalDefinition.NORMAL_SYSCALL]
		return SyscallClassifier.emuFile[SyscallClassifier.GetSyscallClassification(syscallName,bitVersion)]
	
			
		
