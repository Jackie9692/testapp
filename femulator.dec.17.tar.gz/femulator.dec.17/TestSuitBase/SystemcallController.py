import GlobalDefinition
import re
from SyscallClassifier import SyscallClassifier

class SystemcallController:
	def __init__(self,systemcallEmuFilePath,mapFile,unistdFile):
		self.systemcallEmuFilePath = systemcallEmuFilePath
		self.mapFile = mapFile
		self.unistdFile = unistdFile

	def GenerateSyscallCmd(self,injectionCmd):

		faultActionId = self.GetFaultActionId(injectionCmd)
		if(GlobalDefinition.INVALID_FAULT_ACTION_ID == faultActionId ):
			print(GlobalDefinition.INVALID_INJECTION_CMD + GlobalDefinition.LINE_SEPERATOR)
			return GlobalDefinition.INVALID_INJECTION_CMD 
		
		syscallName = self.GetSyscallName(faultActionId)
		if(GlobalDefinition.NO_MAPPING_LINE == syscallName):
			print(GlobalDefinition.NO_MAPPING_LINE + " to get syscall ; faultActionId:" + str(faultActionId) + GlobalDefinition.LINE_SEPERATOR)
			return GlobalDefinition.NO_MAPPING_LINE 
			
		expectedRetValue = self.GetExpectedRetValue(faultActionId) #could be merged to optimize,but not now
		if(GlobalDefinition.NO_MAPPING_LINE == str(expectedRetValue)):
			print(GlobalDefinition.NO_MAPPING_LINE + " to get ret value ; faultActionId:" + str(faultActionId) + GlobalDefinition.LINE_SEPERATOR)
			return GlobalDefinition.NO_MAPPING_LINE
		
		return self.GetValidSyscallCmd(syscallName,expectedRetValue)

	def GetValidSyscallCmd(self,syscallName,expectedRetValue):
		if(GlobalDefinition.BIT_64 == self.GetBitVersion()):
			return self.systemcallEmuFilePath + self.GetTargetEmuFile(syscallName) + GlobalDefinition.SPACE_SYMBOL + self.unistdFile + GlobalDefinition.SPACE_SYMBOL + syscallName +GlobalDefinition.SPACE_SYMBOL+ str(expectedRetValue)

		if(GlobalDefinition.NORMAL_SYSCALL == SyscallClassifier.GetSyscallClassification(syscallName,self.GetBitVersion())):
			return self.systemcallEmuFilePath + self.GetTargetEmuFile(syscallName) + GlobalDefinition.SPACE_SYMBOL + self.unistdFile + GlobalDefinition.SPACE_SYMBOL + syscallName +GlobalDefinition.SPACE_SYMBOL+ str(expectedRetValue)

		return self.systemcallEmuFilePath + self.GetTargetEmuFile(syscallName) + GlobalDefinition.SPACE_SYMBOL + syscallName +GlobalDefinition.SPACE_SYMBOL+ str(expectedRetValue)

	def GetTargetEmuFile(self,syscallName):
		return 	SyscallClassifier.GetTargetEmuFile(syscallName,self.GetBitVersion())
	
	def GetBitVersion(self):
		if('64' in self.unistdFile):
			return GlobalDefinition.BIT_64
		return GlobalDefinition.BIT_32


	def GetMappingFaultType(self,injectionCmd):
		faultActionId = self.GetFaultActionId(injectionCmd)
		
		if(GlobalDefinition.INVALID_FAULT_ACTION_ID == faultActionId ):
			print(GlobalDefinition.INVALID_INJECTION_CMD + GlobalDefinition.LINE_SEPERATOR)
			return GlobalDefinition.INVALID_INJECTION_CMD 
		
		faultType =self.GetFaultType(faultActionId)
		if(GlobalDefinition.NO_MAPPING_LINE == faultType):
			print(GlobalDefinition.NO_MAPPING_LINE + " to get fault type ; faultActionId:" + str(faultActionId) + GlobalDefinition.LINE_SEPERATOR)
			return GlobalDefinition.NO_MAPPING_LINE 
		
		return int(faultType)

	def GetExpectedRetValue(self,faultActionId):
		expectedRetStr = self.__GetMapLinePart(faultActionId,GlobalDefinition.EXPECTED_RETURN_VALUE_INDEX_IN_MAP_LINE)
		
		return int(expectedRetStr)
	

	def GetSyscallName(self,faultActionId):
		
		syscallNameInMap = self.__GetMapLinePart(faultActionId,GlobalDefinition.SYSCALL_NAME_INDEX_IN_MAP_LINE)
		syscallName = SyscallClassifier.SyscallNameExchange(syscallNameInMap,self.GetBitVersion())
		return syscallName
	def GetSyscallNameWithoutExechange(self,faultActionId):
		return self.__GetMapLinePart(faultActionId,GlobalDefinition.SYSCALL_NAME_INDEX_IN_MAP_LINE)

	def GetFaultType(self,faultActionId):
		return self.__GetMapLinePart(faultActionId,GlobalDefinition.FAULT_TYPE_INDEX_IN_MAP_LINE)

	def __GetMapLinePart(self,faultActionId,partIndex):

		targetLine = self.__GetMapLine(faultActionId)
		if(GlobalDefinition.NO_MAPPING_LINE == targetLine):
			return GlobalDefinition.NO_MAPPING_LINE
		
		partsInfoList = targetLine.replace(GlobalDefinition.LINE_SEPERATOR,'').split(GlobalDefinition.SPACE_SYMBOL)
		partsInfoList = self.__PureInfoList(partsInfoList)
		if(partIndex >= len(partsInfoList)):
			return GlobalDefinition.NO_MAPPING_LINE
		
		return str(partsInfoList[partIndex]).replace(GlobalDefinition.LINE_SEPERATOR,'')
		
	def __GetMapLine(self,faultActionId):
		mapFileHandler = open(self.mapFile,'r')
		if(not mapFileHandler):
			print(GlobalDefinition.OPEN_FILE_FAIL + ":" + self.mapFile)
			return GlobalDefinition.OPEN_FILE_FAIL
		
		content = mapFileHandler.readlines()
		mapFileHandler.close()		
		
		for index in range(0,len(content)):
			partsInfoList = content[index].replace(GlobalDefinition.LINE_SEPERATOR,'').split(GlobalDefinition.SPACE_SYMBOL)
			partsInfoList = self.__PureInfoList(partsInfoList)
			if(GlobalDefinition.FAULT_ACTION_ID_INDEX_IN_MAP_LINE >= len(partsInfoList)):
				continue
			if(faultActionId == int(partsInfoList[GlobalDefinition.FAULT_ACTION_ID_INDEX_IN_MAP_LINE])):
				return content[index]
		
		return GlobalDefinition.NO_MAPPING_LINE
		
			
	def GetFaultActionId(self,injectionCmd):
		partsInfoList = injectionCmd.replace(GlobalDefinition.LINE_SEPERATOR,'').split(GlobalDefinition.SPACE_SYMBOL)
		partsInfoList = self.__PureInfoList(partsInfoList)
		if( GlobalDefinition.FAULT_ACTION_ID_INDEX_IN_INJECTION_CMD >= len(partsInfoList)):
			return GlobalDefinition.INVALID_FAULT_ACTION_ID
		
		return int(partsInfoList[GlobalDefinition.FAULT_ACTION_ID_INDEX_IN_INJECTION_CMD])

	def __PureInfoList(self,infoList):
		if('' in infoList):
			infoList.remove('')
		return infoList
	

