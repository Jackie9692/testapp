#define _GNU_SOURCE 
#define __USE_GNU 
#include <sched.h> 
#include <stdlib.h> 
#include <stdio.h> 
#include <unistd.h> 
#include <time.h>

unsigned long get_interval(int reset) 
{
        static struct timeval last_tv;

        struct timeval tv; 
        unsigned long interval;

        if(gettimeofday(&tv,NULL) != 0) { 
                perror("gettimeofday"); 
                exit(0); 
        } 
        interval = (tv.tv_sec - last_tv.tv_sec) * 1000 * 1000+ \
                (tv.tv_usec - last_tv.tv_usec);
        if (reset)
                last_tv = tv;
        return interval; 
}

#define cycle 200000 // 200ms

int main(int argc,char *argv[]) 
{ 
        pid_t pid; 
        int cpu, pct, ret, i;
        cpu_set_t mask; 
        unsigned long idle, busy;

        for (i = 0;i < sysconf(_SC_OPEN_MAX); i++)
                close(i);

        cpu = atoi(argv[1]);
        //pct = atoi(argv[2]);
        pct = 80;

        CPU_ZERO(&mask); 
        CPU_SET(cpu, &mask); 

        pid = getpid(); 
        ret = sched_setaffinity(pid, sizeof(mask), &mask);
        if (ret != 0) {
                perror("sched_setaffinity");
                return -1;
        }

        busy = pct * (cycle / 100);
        idle = (100-pct) * (cycle / 100);

        for (;;) { 
                while (get_interval(0) < busy)
                        ;
                get_interval(1);
                while (get_interval(0) < idle)
                        usleep(cycle/1000);  
                get_interval(1);
        } 

        return 0;
}

