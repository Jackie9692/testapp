#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main(int argc,char *argv[]){
        int i;
        for (i = 0;i < sysconf(_SC_OPEN_MAX); i++)
                close(i);
	if(argc < 2){
		printf("<forkQuantity>\n");
		return 0;
	}
	
	long forkQuantity = atoi(argv[1]);

	long  counter = 0;
	int childPid= -1;
	while(counter++ < forkQuantity && childPid != 0){
		childPid = fork();
	}

	if(childPid != 0){
		pause();
	}

	return 0;
}
