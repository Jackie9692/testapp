#include <asm/uaccess.h>
#include <linux/kallsyms.h>
#include "base.h"
#include "param.h"
#include "file.h"

struct map_t {
        char token;
        on_create_t on_create;
        on_judge_t on_judge;
        on_destroy_t on_destroy;
};

static struct map_t s_maps[] =  {
        { '=', on_eq_create, on_eq_judge, on_eq_destroy },
        { '@', on_file_create, on_file_judge, on_file_destroy },
        { '\0', NULL, NULL, NULL }
#define MID_END 2
};

static int check_params(struct base_t *b)
{
        int i;
        for (i = 0; i < PARAM_NUM; ++i) {
                if (b->params[i].mid < 0 || b->params[i].mid >= MID_END) // not set, ignore
                        continue;
                if (s_maps[b->params[i].mid].on_judge(i, b->params[i].value, b) == 0) {
                        return 0; // set, but not satisfied
                }
        }

        return 1;
}

static inline unsigned long *kernelstack_pointer(void)
{
        /* ss esp eflags cs eip and other registers */
        /* see asm/calling.h & system_call in entry.S */
#ifdef CONFIG_X86_32
        return ((unsigned long *)current->thread.correct_regname(sp0)) - \
                sizeof(struct pt_regs) / sizeof(void *);
#else /* CONFIG_X86_32 */
        return ((unsigned long *)current->thread.correct_regname(sp0)) - \
                (sizeof(struct pt_regs)) / sizeof(void *) + OFFSET_PARTIAL;
#endif /* !CONFIG_X86_32 */
}

unsigned long syscall_arg(int pos)
{
        unsigned long *sp = kernelstack_pointer();
#ifdef CONFIG_X86_32
        return sp[pos];
#else /* CONFIG_X86_32 */
        static const int map[6] = {
                OFFSET_RDI - OFFSET_PARTIAL,
                OFFSET_RSI - OFFSET_PARTIAL,
                OFFSET_RDX - OFFSET_PARTIAL,
                OFFSET_R10 - OFFSET_PARTIAL,
                OFFSET_R8 - OFFSET_PARTIAL,
                OFFSET_R9 - OFFSET_PARTIAL,
        };

        return sp[map[pos]];
#endif /* !CONFIG_X86_32 */
}

unsigned long kercall_arg(int pos)
{
        unsigned long *sp = (unsigned long *)task_pt_regs(current);
#ifdef CONFIG_X86_32
        return sp[pos];
#else /* CONFIG_X86_32 */
        static const int map[6] = {
                OFFSET_RDI - OFFSET_PARTIAL,
                OFFSET_RSI - OFFSET_PARTIAL,
                OFFSET_RDX - OFFSET_PARTIAL,
                OFFSET_RCX - OFFSET_PARTIAL,
                OFFSET_R8 - OFFSET_PARTIAL,
                OFFSET_R9 - OFFSET_PARTIAL,
        };

        return sp[map[pos]];
#endif /* !CONFIG_X86_32 */
}

unsigned long syscall_arg_from_regs(struct pt_regs *regs, int pos)
{
#ifdef CONFIG_X86_32
        return ((unsigned long *)regs)[pos];
#else /* CONFIG_X86_32 */
        static const int map[6] = {
                OFFSET_RDI,
                OFFSET_RSI,
                OFFSET_RDX,
                OFFSET_R10,
                OFFSET_R8,
                OFFSET_R9,
        };

        return ((unsigned long *)regs)[map[pos]];
#endif /* !CONFIG_X86_32 */
}

unsigned long kercall_arg_from_regs(struct pt_regs *regs, int pos)
{
#ifdef CONFIG_X86_32
        return ((unsigned long *)regs)[pos];
#else /* CONFIG_X86_32 */
        static const int map[6] = {
                OFFSET_RDI,
                OFFSET_RSI,
                OFFSET_RDX,
                OFFSET_RCX,
                OFFSET_R8,
                OFFSET_R9,
        };

        return ((unsigned long *)regs)[map[pos]];
#endif /* !CONFIG_X86_32 */
}

static void **s_current_kprobe;

static inline void my_reset_current_kprobe(void)
{
#ifdef HIGH_VERSION
        (*SHIFT_PERCPU_PTR(s_current_kprobe, my_cpu_offset)) = NULL;
#else
#ifdef CONFIG_X86_32
        (*RELOC_HIDE(s_current_kprobe, __per_cpu_offset[smp_processor_id()])) = NULL;
#else
        (*RELOC_HIDE(s_current_kprobe, __my_cpu_offset())) = NULL;
#endif
#endif
}

static int base_pre_handler(struct kprobe *kp, struct pt_regs *regs)
{
        int ret = 0;
        struct base_t *b = base_from_kprobe(kp);

        if (atomic_read(&b->ready_flag) == 0)
                return 0;

        if (ignore_handler(b) || check_params(b) == 0)
                return 0;


        if (b->pre_handler) {
                on_fault_hit(b);
                ret = b->pre_handler(b, regs);
        }

        if (ret) {
                //regs->flags &= ~X86_EFLAGS_IF;
                //trace_hardirqs_off();
                my_reset_current_kprobe();
                preempt_enable_no_resched();
        }

        return ret;
}

static void base_post_handler(struct kprobe *kp, struct pt_regs *regs, unsigned long flags)
{
        struct base_t *b = base_from_kprobe(kp);

        if (atomic_read(&b->ready_flag) == 0)
                return;

        if (ignore_handler(b) || check_params(b) == 0)
                return;

        if (b->post_handler) {
                on_fault_hit(b);
                b->post_handler(b, regs, flags);
        }
}

static int base_ret_handler(struct kretprobe_instance *ki, struct pt_regs *regs)
{
        int ret = 0;
        struct base_t *b = base_from_kretprobe(ki->rp);

        if (atomic_read(&b->ready_flag) == 0)
                return 0;

        if (ignore_handler(b) || check_params(b) == 0)
                return 0;


        if (b->ret_handler) {
                on_fault_hit(b);
                ret = b->ret_handler(b, regs);
        }

        return ret;
}

int parse_params_to_list(char *raw, char *params[], int size)
{
        int i = 0;
#define SEP ':'
        while (i < size) {
                if (*raw != '\0')
                        params[i++] = raw;
                while (*raw && *raw != SEP)
                        ++raw;
                if (*raw == '\0')
                        break;
                *(raw++) = '\0';
        }

        return i;
}

int fill_kprobe_addr(struct kprobe *kp, const char *syscall)
{
#ifdef LOW_VERSION
        kp->addr = (kprobe_opcode_t*)kallsyms_lookup_name(syscall);
        if (kp->addr == NULL)
                return -1;
#else
        kp->symbol_name = syscall;
#endif
        return 0;
}

int init_base_injector(struct base_t *b, const char *param_str, const char **new_param_pos)
{
        int i, j, ret;
        char params_store[PARAM_MAX+1], *params[1+PARAM_NUM] = { NULL };

        atomic_set(&b->ready_flag, 0);

        strcpy(params_store, param_str);
        ret = parse_params_to_list(params_store, params, 1+PARAM_NUM);
        if (ret < 1) {
                log_error("need function name");
                return -1;
        }

        if (new_param_pos) {
                *new_param_pos = params[ret-1] + strlen(params[ret-1]);
                if (params_store + strlen(param_str) != *new_param_pos)
                        *new_param_pos += 1;
                *new_param_pos = param_str + (*new_param_pos - params_store);
        }

        strcpy(b->fname, params[0]);

        if (b->pre_handler || b->post_handler) {
                b->kp.pre_handler = base_pre_handler;
                b->kp.post_handler = base_post_handler;

                if (fill_kprobe_addr(&b->kp, b->fname)) {
                        log_error("find syscall %s failed", b->fname);
                        goto init_end;
                }
                if ((ret = register_kprobe(&b->kp)) < 0) {
                        log_error("register_kprobe failed, returned %d", ret);
                        if (ret == -22)
                                log_error("perhaps kprobe can not find symbol %s?", b->fname);
                        b->kp.addr = NULL;
                        goto init_end;
                }
                log_debug("kprobe plant at 0x%p %pS", b->kp.addr, b->kp.addr);
        }

        if (b->ret_handler) {
                b->kretp.handler = base_ret_handler;

                if (fill_kprobe_addr(&b->kretp.kp, b->fname)) {
                        log_error("find syscall %s failed", b->fname);
                        goto init_end;
                }
                if ((ret = register_kretprobe(&b->kretp)) < 0) {
                        log_error("register_kretprobe failed, returned %d", ret);
                        if (ret == -22)
                                log_error("perhaps kprobe can not find symbol %s?", b->fname);
                        b->kretp.kp.addr = NULL;
                        goto init_end;
                }
                log_debug("kretprobe plant at 0x%p %pS", b->kretp.kp.addr, b->kretp.kp.addr);
        }

        for (i = 0; i < PARAM_NUM; ++i) {
                b->params[i].mid = MID_END;
                if (params[i+1] == NULL || params[i+1][0] == '\0') { // not set, ignore
                        continue;
                }
                // find matching parser
                j = 0;
                while (s_maps[j].token && s_maps[j].token != params[i+1][0]) {
                        ++j;
                }
                b->params[i].mid = j;
                if (j == MID_END) { // not found 
                        log_warning("can not recognize parameter %d %s", i, params[i+1]);
                        continue;
                }
                
                b->params[i].value = s_maps[j].on_create(params[i+1]+1); // skip token
                if (b->params[i].value == NULL) { //parse error, ignore
                        log_warning("can not parse parameter %d %s", i, params[i+1]);
                        b->params[i].mid = MID_END;
                }
        }

        return 0;

init_end:
        if (b->kp.addr)
                unregister_kprobe(&b->kp);
        if (b->kretp.kp.addr)
                unregister_kretprobe(&b->kretp);
        return -1;
}

void notify_pause(struct base_t *base)
{
        atomic_set(&base->ready_flag, 0);
}

void notify_ready(struct base_t *base)
{
        atomic_set(&base->ready_flag, 1);
}

void free_base_injector(struct base_t *b)
{
        int i;
        /* unregister probes before we release parameter checker resource */
        if (b->kp.addr)
                unregister_kprobe(&b->kp);
        if (b->kretp.kp.addr)
                unregister_kretprobe(&b->kretp);

        for (i = 0; i < PARAM_NUM; ++i) {
                if (b->params[i].mid < 0 || b->params[i].mid >= MID_END) {
                        continue;
                }
                if (s_maps[b->params[i].mid].on_destroy) {
                        s_maps[b->params[i].mid].on_destroy(b->params[i].value);
                }
        }
}

int on_base_init(void)
{
#if defined(CURRENT_KPROBE)
        s_current_kprobe = (void **)CURRENT_KPROBE;
#elif defined(HAVE_KALLSYMS_LOOKUP_NAME)
        s_current_kprobe = (void **)kallsyms_lookup_name("current_kprobe");
#else
        s_current_kprobe = NULL;
#endif
        if (s_current_kprobe == NULL) {
                log_error("cannot find current_kprobe");
                return 1;
        }
        return 0;
}

void on_base_exit(void)
{
}

