#ifndef __BASE_H__
#define __BASE_H__

#include <linux/kprobes.h>
#include "frame.h"
#define FNAME_MAX PARAM_MAX
#define PARAM_NUM 6

struct base_t;

typedef void *(*on_create_t)(const char *param);
typedef int (*on_judge_t)(int pos, void *value, struct base_t *b);
typedef void (*on_destroy_t)(void *value);

struct param_t {
        int mid; // id in maps
        void *value;
};

typedef int (*pre_handler_t)(struct base_t *base, struct pt_regs *reg);
typedef void (*post_handler_t)(struct base_t *base, struct pt_regs *reg, unsigned long flags);
typedef int (*ret_handler_t)(struct base_t *base, struct pt_regs *reg);

struct base_t {
        struct kprobe kp;
        struct kretprobe kretp;
        atomic_t ready_flag;
        char fname[FNAME_MAX+1];
        pre_handler_t pre_handler;
        post_handler_t post_handler;
        ret_handler_t ret_handler;
        struct param_t params[PARAM_NUM];
};
#define base_from_kprobe(kp) ((struct base_t *)(kp))
#define base_from_kretprobe(kp) ((struct base_t *)(((char *)(kp))-sizeof(struct kprobe)))

int init_base_injector(struct base_t *base, const char *param_str, const char **new_param_pos);
void notify_pause(struct base_t *base);
void notify_ready(struct base_t *base);
void free_base_injector(struct base_t *base);

int parse_params_to_list(char *raw, char *params[], int size);
int fill_kprobe_addr(struct kprobe *kp, const char *syscall);

#include <linux/version.h>

#if LINUX_VERSION_CODE == KERNEL_VERSION(2,6,34)
#define HAVE_KALLSYMS_LOOKUP_NAME
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,32)
#define HIGH_VERSION
#elif LINUX_VERSION_CODE == KERNEL_VERSION(2,6,16)
#define LOW_VERSION
#else
#pragma error "unsupported kernel version!"
#endif

#ifdef CONFIG_X86_32

#ifdef HIGH_VERSION
#define correct_regname(reg) reg
#else
#define correct_regname(reg) e##reg
#endif

#elif defined CONFIG_X86_64 /* CONFIG_X86_32 */

#ifdef HIGH_VERSION
#define correct_regname(reg) reg
#else
#define correct_regname(reg) r##reg
#endif /* CONFIG_X86_64 */

#else

#pragma error "unsupported architecture"

#endif /* !CONFIG_X86_32 && !CONFIG_X86_64 */

#ifdef CONFIG_X86_32
#define OFFSET_EBX 0
#define OFFSET_ECX 1
#define OFFSET_EDX 2
#define OFFSET_ESI 3
#define OFFSET_EDI 4
#define OFFSET_EBP 5
#define OFFSET_AX  6
#else /* CONFIG_X86_32 */
#define OFFSET_RDI 14
#define OFFSET_RSI 13
#define OFFSET_RDX 12
#define OFFSET_RCX 11 /* used in kernel c calling */
#define OFFSET_R10 7  /* used in syscall */
#define OFFSET_R8  9
#define OFFSET_R9  8
#define OFFSET_PARTIAL 6 /* used in system_call */
#define OFFSET_AX  10
#endif /* !CONFIG_X86_32 */

#define return_value(regs) *(((unsigned long *)(regs))+OFFSET_AX)
#define current_pc(regs) *(((unsigned long *)(regs))+sizeof(struct pt_regs)/sizeof(void *)-5)
unsigned long syscall_arg(int pos);
unsigned long kercall_arg(int pos);
unsigned long syscall_arg_from_regs(struct pt_regs *regs, int pos);
unsigned long kercall_arg_from_regs(struct pt_regs *regs, int pos);

#define is_sys_call(f) (*(const unsigned int *)(f) == \
        *(const unsigned int *)"sys_") 
#define call_arg(f, n) (is_sys_call(f)? \
        syscall_arg(n): kercall_arg(n))

// copy from 3.11.4
extern long _strncpy_from_user(char *dst, const char __user *src, long count);

#ifdef HIGH_VERSION
#include <linux/semaphore.h>
#else
#include <asm/semaphore.h>
#endif

#endif

