#include "confuse.h"
#include <linux/random.h>
#include <asm/uaccess.h>

#define BUFFSIZE 256

static int ret_handler(struct base_t *base, struct pt_regs *regs)
{
        char buf[BUFFSIZE];

        // TODO: only effect on sys_read
        char *user_buf = (char *)syscall_arg(1);
        size_t ret, to_copy, count = (size_t)return_value(regs);

        while (count > 0) {
                to_copy = min((size_t)BUFFSIZE, count);
                get_random_bytes(buf, to_copy);
                if ((ret = copy_to_user(user_buf, buf, to_copy))) {
                        log_error("can not confuse %zu(%zu) bytes in user space", to_copy, ret);
                        break;
                }
                user_buf += to_copy;
                count -= to_copy;
        }

        return 0;
}

int confuse_attacher(const struct fault *fault)
{
        struct confuse_t *confuse;

        confuse = fault->data;
        confuse->base.ret_handler = ret_handler;
        if (init_base_injector(&confuse->base, fault->param, NULL)) {
                log_error("init_base_injector failed");
                return -1;
        }
        notify_ready(&confuse->base);

        return 0;
}

int confuse_detacher(const struct fault *fault)
{
        notify_pause(&((struct confuse_t *const)fault->data)->base);
        free_base_injector(&((struct confuse_t *const)fault->data)->base);

        return 0;
}

