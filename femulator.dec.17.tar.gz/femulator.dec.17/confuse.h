#ifndef __CONFUSE_H__
#define __CONFUSE_H__

#include "base.h"

struct confuse_t {
        struct base_t base;
};

int confuse_attacher(const struct fault *fault);
int confuse_detacher(const struct fault *fault);

#endif

