#include "delay.h"

static void post_handler(struct base_t *base, struct pt_regs *regs, unsigned long flags)
{
        // we can not sleep in kprobe handler
#ifdef HIGH_VERSION
        struct timeval start, curr;
        struct delay_t *delay = (struct delay_t *)base;
        do_gettimeofday(&start);
        do {
                do_gettimeofday(&curr);
        } while ((curr.tv_sec - start.tv_sec) * 1000 + \
                (curr.tv_usec - start.tv_usec) / 1000 < delay->delay);
#else
        int i = 0x7fffffff;
        while (i-- > 0) {
                __asm__ __volatile__("nop");
        }
        log_warning("delay is ignored");
#endif
}

static int parse_param(char *param, int *delay)
{
        if (sscanf(param, "%d", delay) != 1)
                return -1;

        return 0;
}

int delay_attacher(const struct fault *fault)
{
        struct delay_t *delay;
        const char *new_param;
        char params_store[PARAM_MAX+1], *params[1] = { NULL };

        delay = fault->data;
        delay->base.pre_handler = NULL;
        delay->base.post_handler = post_handler;
        if (init_base_injector(&delay->base, fault->param, &new_param)) {
                log_error("init_base_injector failed");
                return -1;
        }

        strcpy(params_store, new_param);
        if (parse_params_to_list(params_store, params, 1) < 1 || \
                parse_param(params[0], &delay->delay)) {
                free_base_injector(&delay->base);
                log_error("can not parse parameter: %s", new_param);
                return -1;
        }
        notify_ready(&delay->base);

        return 0;
}

int delay_detacher(const struct fault *fault)
{
        notify_pause(&((struct delay_t *const)fault->data)->base);
        free_base_injector(&((struct delay_t *const)fault->data)->base);

        return 0;
}

