#ifndef __DELAY_H__
#define __DELAY_H__

#include "base.h"

struct delay_t {
        struct base_t base;
        int delay;
};

int delay_attacher(const struct fault *fault);
int delay_detacher(const struct fault *fault);

#endif

