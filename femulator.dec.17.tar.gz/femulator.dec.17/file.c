#include <asm/uaccess.h>
#include <linux/kallsyms.h>
#include "base.h"
#include "list.h"

#define NAME_MAX 255

#ifdef HIGH_VERSION
#include <linux/fdtable.h>
#else
#include <linux/reiserfs_fs.h>
#include <linux/file.h>
#include <linux/mount.h>
#endif
#include <linux/fs.h>
#include <linux/gfp.h>

#define PATHNAME_MAX 511

static struct files_struct *(*fn_get_files_struct)(struct task_struct *task);
static void (*fn_put_files_struct)(struct files_struct *files);

static struct files_struct *_get_files_struct(struct task_struct *task)
{
        struct files_struct *files;

        task_lock(task);
        files = task->files;
        if (files)
                atomic_inc(&files->count);
        task_unlock(task);

        return files;
}

void _put_files_struct(struct files_struct *files)
{
        if (atomic_dec_and_test(&files->count)) {
                log_error("fd may leek here!!!");
        }
}

static int test_fd_path(int fd, const char *name)
{
        int ret = 0;
        struct files_struct *files = NULL;
        struct file *file;
        char *pathname, pathbuff[PATHNAME_MAX+1];
#ifdef HIGH_VERSION
        struct path path;
#else
        struct dentry *dentry;
        struct vfsmount *mnt;
#endif

        files = _get_files_struct(current);
        if (files == NULL)
                return -ENOENT;

        /*
         * We are not taking a ref to the file structure, so we must
         * hold ->file_lock.
         */
#ifdef HIGH_VERSION
        spin_lock(&files->file_lock);
        if ((file = fcheck_files(files, fd)) == NULL) {
                spin_unlock(&files->file_lock);
                _put_files_struct(files);
                return -ENOENT;
        }

        path = file->f_path;
        path_get(&file->f_path);
        spin_unlock(&files->file_lock);

        pathname = d_path(&path, pathbuff, PATHNAME_MAX+1);
        path_put(&path);

        if (IS_ERR(pathname)) {
                _put_files_struct(files);
                return PTR_ERR(pathname);
        }

#else /* HIGH_VERSION */
        // proc_fd_link
        rcu_read_lock();
        if ((file = fcheck_files(files, fd)) == NULL) {
                rcu_read_unlock();
                _put_files_struct(files);
                return -ENOENT;
        }

        mnt = mntget(file->f_vfsmnt);
        dentry = dget(file->f_dentry);
        rcu_read_unlock();

        // do_proc_readlink

        pathname = d_path(dentry, mnt, pathbuff, PATHNAME_MAX+1);
        ret = PTR_ERR(pathname);
        if (IS_ERR(pathname)) {
                _put_files_struct(files);
                return -ENOMEM;
        }

#endif /* !HIGH_VERSION */
        //log_debug("path: %s(%s)", pathname, name);
        ret = strcmp(name, pathname) == 0 ? 0 : 1;
        _put_files_struct(files);

        return ret;
}

void *on_file_create(const char *param)
{
        void *str;

        str = mmalloc(strlen(param)+1);
        if (str == NULL)
                return NULL;
        strcpy(str, param);

        return str;
}

int on_file_judge(int pos, void *value, struct base_t *b)
{
        int fd = syscall_arg(pos);
        if (test_fd_path(fd, (char *)value) == 0)
                return 1;

        return 0;
}

void on_file_destroy(void *value)
{
        if (value)
                mfree(value);
}

int on_file_init(void)
{
        fn_put_files_struct =
#if defined(PUT_FILES_STRUCT)
                (void (*)(struct files_struct *))PUT_FILES_STRUCT;
#elif defined(HAVE_KALLSYMS_LOOKUP_NAME)
                (void (*)(struct files_struct *))kallsyms_lookup_name("put_files_struct");
#else
                NULL;
#endif
        if (fn_put_files_struct == NULL) {
                log_error("cannot find put_files_struct");
                return 1;
        }
        fn_get_files_struct =
#if defined(PUT_FILES_STRUCT)
                (struct files_struct *(*)(struct task_struct *))GET_FILES_STRUCT;
#elif defined(HAVE_KALLSYMS_LOOKUP_NAME)
                (struct files_struct *(*)(struct task_struct *))kallsyms_lookup_name("get_files_struct");
#else
                NULL;
#endif
        if (fn_get_files_struct == NULL) {
                log_error("cannot find get_files_struct");
                return 1;
        }
        return 0;
}

void on_file_exit(void)
{
}

