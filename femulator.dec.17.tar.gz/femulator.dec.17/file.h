#ifndef __FILE_MON_H__
#define __FILE_MON_H__

#include "base.h"

void *on_file_create(const char *param);
int on_file_judge(int pos, void *value, struct base_t *b);
void on_file_destroy(void *value);

#endif

