#include "frame.h"
#include "list.h"

#include <linux/kprobes.h>
#include <linux/hardirq.h>
#include <linux/device.h>

// methods
#include "return.h"
#include "delay.h"
#include "reboot.h"
#include "confuse.h"

#ifndef max
#define max(a, b) ((a) > (b) ? (a) : (b))
#endif
#ifndef min
#define min(a, b) ((a) < (b) ? (a) : (b))
#endif

typedef int (*init_t)(void);
typedef void (*exit_t)(void);

struct method_init_t {
        init_t init;
        exit_t exit; 
};

extern int on_file_init(void);
extern void on_file_exit(void);
extern int on_base_init(void);
extern void on_base_exit(void);

static struct method_init_t s_inits[] = {
        { on_base_init, on_base_exit },
        { on_file_init, on_file_exit },
        { NULL, NULL }
};

typedef int (*attacher_t)(const struct fault *fault);
typedef int (*detacher_t)(const struct fault *fault);

struct method_t {
        attacher_t attacher;
        detacher_t detacher;
        unsigned long size;
};

struct empty_t {
};

static int empty_attacher(const struct fault *fault)
{
        return 0;
}

static int empty_detacher(const struct fault *fault)
{
        return 0;
}

static struct method_t s_methods[] = {
        { return_attacher, return_detacher, sizeof(struct return_t)  },         /*  1 */
        { delay_attacher, delay_detacher, sizeof(struct delay_t)  },            /*  2 */
        { reboot_attacher, reboot_detacher, sizeof(struct reboot_t)  },         /*  3 */
        { confuse_attacher, confuse_detacher, sizeof(struct confuse_t)  },      /*  4 */
        { empty_attacher, empty_detacher, sizeof(struct empty_t)  },            /*  5 */
#define METHOD_END                                                                  6
};

static struct bus_type pseudo_bus = {
        .name = "fi_pseudo_bus",
};

static struct list_t *s_fault_list;

int g_log_level = LOG_DEBUG;

#define invalid_aid -1
#define invalid_pid -1
#define invalid_method 0
#define default_time 0

static int s_aid = invalid_aid;
static char s_hash[HASH_LENGTH+1];
static int s_pid = invalid_pid;
static char s_pname[PNAME_MAX+1];
static int s_method = invalid_method;
static char s_param[PARAM_MAX+1];
static int s_time = default_time;

static void reset_all(void)
{
        s_aid = invalid_aid;
        memset(s_hash, 0, HASH_LENGTH+1);
        s_pid = invalid_pid;
        memset(s_pname, 0, PNAME_MAX+1);
        s_method = invalid_method;
        memset(s_param, 0, PARAM_MAX+1);
        s_time = default_time;
}

#ifdef CONFIG_SMP
static DECLARE_MUTEX(s_lock);
#define my_bus_lock() down(&s_lock)
#define my_bus_unlock() up(&s_lock)
static DECLARE_MUTEX(s_query_lock);
#define my_query_lock() down(&s_query_lock)
#define my_query_unlock() up(&s_query_lock)
#else
#define my_bus_lock()
#define my_bus_unlock()
#define my_query_lock()
#define my_query_unlock()
#endif

#define bus_store_int(name, buff_size, value) \
        static ssize_t bus_store_##name(struct bus_type *bus, const char *buf, size_t count) \
{ \
        char buff[(buff_size)+1]; \
        my_bus_lock(); \
        if (count > (buff_size)) { \
                log_warning("input(%s) is longer than buffer size", #name); \
        } \
        memcpy(buff, buf, min(count, (size_t)(buff_size))); \
        buff[min(count, (size_t)(buff_size))] = 0; \
        if (sscanf(buff, "%d", &(value)) != 1) { \
                log_error("bus: cannot store %s as "#name, buff); \
        } \
        my_bus_unlock(); \
        return count; \
}

#define bus_store_string(name, buff_size, value) \
        static ssize_t bus_store_##name(struct bus_type *bus, const char *buf, size_t count) \
{ \
        my_bus_lock(); \
        if (count > (buff_size)) { \
                log_warning("input(%s) is longer than buffer size", #name); \
        } \
        strncpy((value), buf, min(count, (size_t)(buff_size))); \
        (value)[min(count, (size_t)(buff_size))] = 0; \
        my_bus_unlock(); \
        return count; \
}

bus_store_int(log_level, BUFF_MAX, g_log_level);
bus_store_int(aid, BUFF_MAX, s_aid);
bus_store_string(hash, HASH_LENGTH, s_hash);
bus_store_int(pid, BUFF_MAX, s_pid);
bus_store_string(pname, PNAME_MAX, s_pname);
bus_store_int(method, BUFF_MAX, s_method);
bus_store_string(param, PARAM_MAX, s_param);
bus_store_int(time, BUFF_MAX, s_time);

static long s_left_to_print;

static int check_fault_validation(const struct fault *fault)
{
        struct timespec ts;
        getnstimeofday(&ts);
        if (fault->ltime > 0) {
#define nsectosec(t) ((t) / 1000000000)
                if (ts.tv_sec - fault->itime.tv_sec + \
                                nsectosec(ts.tv_nsec - fault->itime.tv_nsec) > fault->ltime) {
                        return 0;       // faults has expired
                }
        }
        return 1;
}

static int list_valid_fault_by_hash(void *hash, void *item)
{
        struct fault *fault = item;
        if (check_fault_validation(fault) == 0) {
                log_debug("fault(%s) ignored while it has expired", fault->hash);
                return 0;
        }
        return strcmp(fault->hash, hash) == 0;
}

static ssize_t fi_insert(struct bus_type *bus, char *buf)
{
        int ret;
        struct fault *fault;

        my_bus_lock();
        /* check parameter vailidation */
        if (s_method <= 0 || s_method >= METHOD_END) {
                log_error("invalid method index: %d", s_method);
                my_bus_unlock();
                return scnprintf(buf, PAGE_SIZE, "%d\n", -1);
        }
        if (strcmp(s_hash, "") == 0 || strcmp(s_hash, "0") == 0) {
                log_error("invalid hash value: %s", s_hash);
                my_bus_unlock();
                return scnprintf(buf, PAGE_SIZE, "%d\n", -1);
        }
        /* check whether fault has already inserted */
        my_query_lock();

        fault = (struct fault *)list_item_if(s_fault_list, list_valid_fault_by_hash, (void *)s_hash);
        if (fault) {
                log_warning("fault(%s) already exists", s_hash);
                my_query_unlock();
                my_bus_unlock();
                return scnprintf(buf, PAGE_SIZE, "-1\n");
        }

        my_query_unlock();

        if (s_pid == invalid_pid && s_pname[0] == '\0') {
                log_warning("both pid and process name are not set");
        }

        fault = mmalloc(sizeof(struct fault)+s_methods[s_method-1].size);
        if (fault == NULL) {
                log_error("can not allocate memory");
                my_bus_unlock();
                return scnprintf(buf, PAGE_SIZE, "%d\n", -1);
        }
        memset(fault, 0, sizeof(struct fault)+s_methods[s_method-1].size);
        fault->aid = s_aid;
        strcpy(fault->hash, s_hash);
        fault->pid = s_pid;
        strcpy(fault->pname, s_pname);
        fault->method = s_method;
        strcpy(fault->param, s_param);
        //atomic_set(&fault->hits, 0);
        fault->hits.counter = 0;
        fault->data = &fault->data + 1;
        fault->ltime = s_time;
        // record injection time
        getnstimeofday(&fault->itime);

        reset_all();

        my_bus_unlock();

        if ((ret = s_methods[fault->method-1].attacher(fault)) != 0) {
                log_error("can not initialize for method %d", fault->method);
                mfree(fault);
                return scnprintf(buf, PAGE_SIZE, "%d\n", -1);
        }

        my_query_lock();
        /* fault list may change, so the query should be reset */
        s_left_to_print = 0;
        if ((ret = list_rinsert_at(s_fault_list, 0, fault)) < 0) {
                log_error("can not insert struct fault into list");
                s_methods[fault->method-1].detacher(fault);
                mfree(fault);
                my_query_unlock();
                return scnprintf(buf, PAGE_SIZE, "%d\n", -1);
        }
        my_query_unlock();

        log_debug("injection succeed (hash: %s)", fault->hash);

        return scnprintf(buf, PAGE_SIZE, "0\n");
}

static int remove_fault_by_hash(void *hash, void *item)
{
        struct fault *fault = (struct fault *)item;
        if (strcmp(fault->hash, hash) == 0) {
                s_methods[fault->method-1].detacher(fault);
                mfree(fault);
                return 1;
        }
        return 0;
}

static int remove_expired_faults(void *ctx, void *item)
{
        struct fault *fault = (struct fault *)item;
        if (check_fault_validation(fault) == 0) {
                s_methods[fault->method-1].detacher(fault);
                mfree(fault);
                return 1;
        }
        return 0;
}

static ssize_t fi_remove(struct bus_type *bus, char *buf)
{
        int ret;
        char hash[HASH_LENGTH+1];

        my_bus_lock();

        strcpy(hash, s_hash);

        reset_all();

        my_bus_unlock();

        my_query_lock();
        /* fault list may change, so the query should be reset */
        s_left_to_print = 0;
        ret = list_remove_if(s_fault_list, remove_expired_faults, NULL);
        if (ret)
                log_debug("remove %d expired faults", ret);

        ret = list_remove_if(s_fault_list, remove_fault_by_hash, (void *)hash);
        if (ret == 0) {
                log_warning("no fault's hash is %s ", hash);
                my_query_unlock();
                return scnprintf(buf, PAGE_SIZE, "-1\n");
        }
        BUG_ON(ret != 1);
        my_query_unlock();

        log_debug("remove succeed (hash: %s)", hash);

        return scnprintf(buf, PAGE_SIZE, "1\n");
}

#define query_fmt "pid: %d| pname: %s| param: %s| method: %d| aid: %d| hits: %d\n"
#define query_list(f) (f)->pid, (f)->pname, (f)->param, (f)->method, (f)->aid, atomic_read(&(f)->hits)

static int count_valid_faults(void *ctx, void *item)
{
        struct fault *fault = item;
        if (check_fault_validation(fault))
                *(int *)ctx += 1;
        return 1;
}

static int print_valid_faults(void *ctx, void *item)
{
        char *buf = ((void **)ctx)[0];
        int *cnt = ((void **)ctx)[1];
        long *skip = (long *)&((void **)ctx)[2];
        struct fault *fault = item;

        if ((*skip)-- > 0)
                return 1;

        if (*cnt >= PAGE_SIZE-1)
                return 0;

        // TODO: remove it from list
        if (check_fault_validation(fault)) {
                *cnt += scnprintf(buf+*cnt, PAGE_SIZE-*cnt, query_fmt, query_list(fault));
                s_left_to_print -= 1;
        }

        return 1;
}

static ssize_t fi_query(struct bus_type *bus, char *buf)
{
        ssize_t cnt = 0;
        struct fault *fault;
        char hash[HASH_LENGTH+1];

        my_bus_lock();

        strcpy(hash, s_hash);

        my_bus_unlock();

        my_query_lock();
        if (strcmp(hash, "0") == 0) {
                char *zero;
                void *ctx[3];
                long tmp, len = 0;

                list_traverse(s_fault_list, count_valid_faults, &len);
                ctx[0] = buf;
                ctx[1] = &cnt;
                if (s_left_to_print <= 0) {
                        ctx[2] = (void *)0;
                        s_left_to_print = len;
                }
                else {
                        ctx[2] = (void *)(len - s_left_to_print);
                }
                cnt += scnprintf(buf/*+cnt*/, PAGE_SIZE/*-cnt*/, "%10ld %10ld\n", 0l, s_left_to_print);

                tmp = s_left_to_print;
                list_traverse(s_fault_list, print_valid_faults, ctx);
                for (zero = buf+cnt; zero > buf; zero--) {
                        if (*zero == '\n') {
                                zero[1] = '\0';
                                break;
                        }
                }
                if (buf+cnt - zero - 1 != 0) {
                        s_left_to_print += 1;
                }
                cnt -= buf+cnt - zero - 1;
                if (scnprintf(buf/*+cnt*/, 11, "%10ld", tmp - s_left_to_print) != 10) {
                        log_error("output number of faults failed");
                }
        }
        else {
                fault = (struct fault *)list_item_if(s_fault_list, list_valid_fault_by_hash, (void *)hash);
                if (fault == NULL) {
                        log_debug("no fault's hash is %s ", hash);
                        my_query_unlock();
                        return scnprintf(buf, PAGE_SIZE, "-1\n");
                }
                cnt = scnprintf(buf, PAGE_SIZE, query_fmt, query_list(fault));
        }
        my_query_unlock();

        return cnt;
}

BUS_ATTR(log_level, S_IWUGO, NULL, bus_store_log_level);
BUS_ATTR(aid, S_IWUGO, NULL, bus_store_aid);
BUS_ATTR(hash, S_IWUGO, NULL, bus_store_hash);
BUS_ATTR(pid, S_IWUGO, NULL, bus_store_pid);
BUS_ATTR(pname, S_IWUGO, NULL, bus_store_pname);
BUS_ATTR(method, S_IWUGO, NULL, bus_store_method);
BUS_ATTR(param, S_IWUGO, NULL, bus_store_param);
BUS_ATTR(time, S_IWUGO, NULL, bus_store_time);

BUS_ATTR(insert, S_IRUGO, fi_insert, NULL);
BUS_ATTR(remove, S_IRUGO, fi_remove, NULL);
BUS_ATTR(query, S_IRUGO, fi_query, NULL);

extern int check_license_valid(void);

static int detach_all_faults(void *ctx, void *f)
{
        struct fault *fault = (struct fault *)f;

        s_methods[fault->method-1].detacher(fault);
        mfree(fault);

        return 1;
}

static int init_frame_module(void)
{
        int ret, i, j;

        if (check_license_valid() == 0) {
                log_info("license has expired");
                return -1;
        }

        if ((ret = bus_register(&pseudo_bus)) < 0) {
                log_error("sysfs: error register bus: %d", ret);
                return ret;
        }

#define bus_file_init(bus, name) \
        if ((ret = bus_create_file(&(bus), &bus_attr_##name)) < 0) { \
                log_error("sysfs: error creating busfile: "#name"(%d)", ret); \
                goto error; \
        }

        bus_file_init(pseudo_bus, insert);
        bus_file_init(pseudo_bus, remove);
        bus_file_init(pseudo_bus, query);
        bus_file_init(pseudo_bus, log_level);
        bus_file_init(pseudo_bus, aid);
        bus_file_init(pseudo_bus, hash);
        bus_file_init(pseudo_bus, pid);
        bus_file_init(pseudo_bus, pname);
        bus_file_init(pseudo_bus, method);
        bus_file_init(pseudo_bus, param);
        bus_file_init(pseudo_bus, time);

        if ((s_fault_list = create_list()) == NULL) {
                log_error("list: can not create list");
                goto error;
        }

        for (i = 0; s_inits[i].init; ++i) {
                if (s_inits[i].init()) {
                        for (j = 0; j < i; ++j) {
                                if (s_inits[j].exit)
                                        s_inits[j].exit();
                        }
                        log_error("init %d error", i);
                        goto error;
                }
        }

        log_info("frame initialized");

        return 0;

error:
        if (s_fault_list) {
                list_remove_if(s_fault_list, detach_all_faults, NULL);
                free_list(s_fault_list);
        }
        bus_remove_file(&pseudo_bus, &bus_attr_time);
        bus_remove_file(&pseudo_bus, &bus_attr_param);
        bus_remove_file(&pseudo_bus, &bus_attr_method);
        bus_remove_file(&pseudo_bus, &bus_attr_pname);
        bus_remove_file(&pseudo_bus, &bus_attr_pid);
        bus_remove_file(&pseudo_bus, &bus_attr_hash);
        bus_remove_file(&pseudo_bus, &bus_attr_aid);
        bus_remove_file(&pseudo_bus, &bus_attr_log_level);
        bus_remove_file(&pseudo_bus, &bus_attr_query);
        bus_remove_file(&pseudo_bus, &bus_attr_remove);
        bus_remove_file(&pseudo_bus, &bus_attr_insert);
        bus_unregister(&pseudo_bus);
        return ret;
}

static void exit_frame_module(void)
{
        int i;

        for (i = 0; s_inits[i].exit; ++i) {
                s_inits[i].exit();
        }

        list_remove_if(s_fault_list, detach_all_faults, NULL);
        free_list(s_fault_list);

        bus_remove_file(&pseudo_bus, &bus_attr_time);
        bus_remove_file(&pseudo_bus, &bus_attr_param);
        bus_remove_file(&pseudo_bus, &bus_attr_method);
        bus_remove_file(&pseudo_bus, &bus_attr_pname);
        bus_remove_file(&pseudo_bus, &bus_attr_pid);
        bus_remove_file(&pseudo_bus, &bus_attr_hash);
        bus_remove_file(&pseudo_bus, &bus_attr_aid);
        bus_remove_file(&pseudo_bus, &bus_attr_log_level);
        bus_remove_file(&pseudo_bus, &bus_attr_query);
        bus_remove_file(&pseudo_bus, &bus_attr_remove);
        bus_remove_file(&pseudo_bus, &bus_attr_insert);
        bus_unregister(&pseudo_bus);
        log_info("frame cleanup");
}

int ignore_handler(void *pdata)
{
        struct fault *fault;

        fault = (struct fault *)((char *)pdata - \
                        (unsigned long)&(((struct fault*)0)->data) - sizeof(void *));
#define pid_set(p) ((p) != invalid_pid)
#define pname_set(p) ((p)[0] != '\0')
        if (in_interrupt())
                return 1;
        if (pid_set(fault->pid) && fault->pid != current->pid)
                return 1;
        if (pname_set(fault->pname) && strcmp(current_thread_info()->task->comm, fault->pname) != 0)
                return 1;
        if (check_fault_validation(fault) == 0) {
                log_debug("fault(%s) ignored while it has expired", fault->hash);
                return 1;
        }
        return 0;
}

void debug_print_fault(const struct fault *fault)
{
        log_debug("fault begin");
        log_debug("aid %d", fault->aid);
        log_debug("pid %d", fault->pid);
        log_debug("method %d", fault->method);
        log_debug("hits %d", atomic_read(&fault->hits));
        log_debug("pname %s", fault->pname);
        log_debug("param %s", fault->param);
        log_debug("hash %s", fault->hash);
        log_debug("itime %lds %ldns", fault->itime.tv_sec, fault->itime.tv_nsec);
        log_debug("ltime %ld", fault->ltime);
        log_debug("data %p", fault->data);
        log_debug("fault end");
}

void on_fault_hit(void *pdata)
{
        int hits;
        struct fault *fault;

        fault = (struct fault *)((char *)pdata - \
                        (unsigned long)&(((struct fault*)0)->data) - sizeof(void *));

        hits = atomic_inc_return(&fault->hits);
        log_info("fault(%s) hit %dth time", fault->hash, hits);
}

module_init(init_frame_module);
module_exit(exit_frame_module);

MODULE_LICENSE("GPL");

