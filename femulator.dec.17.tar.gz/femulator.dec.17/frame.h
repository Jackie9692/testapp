#ifndef __FRAME_H__
#define __FRAME_H__

#include <linux/vmalloc.h>

#define mmalloc vmalloc
#define mfree vfree

#include <linux/time.h>

#define HASH_LENGTH 32
#define BUFF_MAX 255
#define PNAME_MAX 255
#define PARAM_MAX 255

struct fault {
        int aid;
        int pid;
        int method;
        atomic_t hits;
        char pname[PNAME_MAX+1];
        char param[PARAM_MAX+1];
        char hash[HASH_LENGTH+1];
        // injection time
        struct timespec itime;
        // lasting time
        long ltime;
        void *data;
};

int ignore_handler(void *pdata);
void on_fault_hit(void *pdata);

#define LOG_DEBUG       4
#define LOG_INFO        3
#define LOG_WARNING     2
#define LOG_ERROR       1

extern int g_log_level;
#define fmt_wrapper(fmt) "<FI>@%s(%d) "fmt"\n"
#define fmt_for_log(fmt) fmt_wrapper(fmt)
#define fmt_for_log_detail(fmt) fmt_wrapper("%s:%d "fmt)

#define printk_for_log(level, ...) do { if ((level) <= g_log_level) printk(__VA_ARGS__); } while(0)
#define log_wrapper(level, prefix, fmt, ...) printk_for_log(level, prefix fmt, current->comm, current->pid, ##__VA_ARGS__)

#define log_debug(fmt, ...)   log_wrapper(LOG_DEBUG, KERN_DEBUG, fmt_for_log("debug: "fmt), ##__VA_ARGS__)
#define log_info(fmt, ...)    log_wrapper(LOG_INFO, KERN_INFO, fmt_for_log("info: "fmt), ##__VA_ARGS__)
#define log_warning(fmt, ...) log_wrapper(LOG_WARNING, KERN_ERR, fmt_for_log_detail("warning: "fmt), __FILE__, __LINE__, ##__VA_ARGS__)
#define log_error(fmt, ...)   log_wrapper(LOG_ERROR, KERN_ERR, fmt_for_log_detail("error: "fmt), __FILE__, __LINE__, ##__VA_ARGS__)

#endif

