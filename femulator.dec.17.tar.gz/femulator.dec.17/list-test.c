#include <stdio.h>
#include "list.h"

int print_list(void *ctx, void *node)
{
        printf("%ld ", (long)node);
        return 1;
}

int main(int argc, char *argv[])
{
        struct list_t *list;
        list = create_list();
        
        list_rinsert_at(list, 0, (void *)2);
        list_traverse(list, print_list, NULL);
        puts("");
        list_rtraverse(list, print_list, NULL);
        puts("");

        list_rinsert_at(list, 0, (void *)1);
        list_traverse(list, print_list, NULL);
        puts("");
        list_rtraverse(list, print_list, NULL);
        puts("");

        list_rinsert_at(list, 9, (void *)3);
        list_traverse(list, print_list, NULL);
        puts("");
        list_rtraverse(list, print_list, NULL);
        puts("");

        list_remove_at(list, 9);
        list_traverse(list, print_list, NULL);
        puts("");
        list_rtraverse(list, print_list, NULL);
        puts("");

        list_remove_at(list, 1);
        list_traverse(list, print_list, NULL);
        puts("");
        list_rtraverse(list, print_list, NULL);
        puts("");

        list_rinsert_at(list, 1, (void *)2);
        list_traverse(list, print_list, NULL);
        puts("");
        list_rtraverse(list, print_list, NULL);
        puts("");

        list_remove_at(list, 2);
        list_traverse(list, print_list, NULL);
        puts("");
        list_rtraverse(list, print_list, NULL);
        puts("");

        list_remove_at(list, 0);
        list_traverse(list, print_list, NULL);
        puts("");
        list_rtraverse(list, print_list, NULL);
        puts("");

        free_list(list);

        return 0;
}
