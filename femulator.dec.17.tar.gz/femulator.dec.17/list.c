#include "list.h"

#ifdef LIST_TEST

#include <stdlib.h>

#undef mmalloc
#define mmalloc malloc
#undef mfree
#define mfree free

#endif /* LIST_TEST */


#ifdef CONFIG_SMP
#define list_lock(l) down(&((struct list_t *)(l))->lock);
#define list_unlock(l) up(&((struct list_t *)(l))->lock);
#else
#define list_lock(l)
#define list_unlock(l)
#endif

struct node_t {
        void *item;
        struct node_t *prev;
        struct node_t *next;
};

struct list_t *create_list(void)
{
        struct list_t *list;
        list = mmalloc(sizeof(struct list_t));
        if (list != NULL) {
                list->head = NULL;
                list->tail = NULL;
        }
#ifdef CONFIG_SMP
        init_MUTEX(&list->lock);
#endif
        return list;
}

static int remove_all(void *ctx, void *node)
{
        return 1;
}

void free_list(struct list_t *list)
{
        list_remove_if(list, remove_all, NULL);
        mfree(list);
}

int list_length(const struct list_t *list)
{
        int len = 0;
        struct node_t *node;

        list_lock(list);
        for (node = list->head; node; node = node->next) {
                ++len;
        }
        list_unlock(list);

        return len;
}

void *list_item_if(const struct list_t *list, traverse_fn t, void *ctx)
{
        struct node_t *node;

        list_lock(list);
        for (node = list->head; node; node = node->next) {
                if (t(ctx, node->item)) {
                        list_unlock(list);
                        return node->item;
                }
        }
        list_unlock(list);

        return NULL;
}

static int list_item_by_index(void *ctx, void *item)
{
        return (*(int *)ctx)-- == 0;
}

void *list_item_at(const struct list_t *list, int index)
{
        return list_item_if(list, list_item_by_index, &index);
}

int list_insert_at(struct list_t *list, int index, void *item)
{
        int n = 0;
        struct node_t **curr, *nnode;

        list_lock(list);
        for (curr = &list->head; *curr;) {
                if (index-- == 0) {
                        break;
                }
                else {
                        curr = &(*curr)->next;
                }
                ++n;
        }

        nnode = mmalloc(sizeof(struct node_t));
        if (nnode == NULL) {
                list_unlock(list);
                return -1;
        }

        nnode->item = item;
        nnode->prev = NULL;
        nnode->next = *curr;

        if (*curr) {
                nnode->prev = (*curr)->prev;
                (*curr)->prev = nnode;
        }
        else {
                nnode->prev = list->tail;
                list->tail = nnode;
        }
        *curr = nnode;

        list_unlock(list);
        return n;
}

int list_rinsert_at(struct list_t *list, int rindex, void *item)
{
        int n = 0;
        struct node_t **curr, *nnode;

        list_lock(list);
        for (curr = &list->tail; *curr;) {
                if (rindex-- == 0) {
                        break;
                }
                else {
                        curr = &(*curr)->prev;
                }
                ++n;
        }

        nnode = mmalloc(sizeof(struct node_t));
        if (nnode == NULL) {
                list_unlock(list);
                return -1;
        }

        nnode->item = item;
        nnode->prev = *curr;
        nnode->next = NULL;

        if (*curr) {
                nnode->next = (*curr)->next;
                (*curr)->next = nnode;
        }
        else {
                nnode->next = list->head;
                list->head = nnode;
        }
        *curr = nnode;

        list_unlock(list);
        return n;
}

int list_remove_if(struct list_t *list, remove_fn rm, void *ctx)
{
        int ret, i = 0;
        struct node_t **curr, *entry;

        list_lock(list);
        for (curr = &list->head; *curr;) {
                entry = *curr;
                if ((ret = rm(ctx, entry->item)) > 0) {
                        *curr = entry->next;
                        if (*curr) {
                                (*curr)->prev = entry->prev;
                        }
                        else {
                                list->tail = entry->prev;
                        }
                        mfree(entry);
                        ++i;
                }
                else if (ret == 0) {
                        curr = &(*curr)->next;
                }
                else {
                        break;
                }
        }

        list_unlock(list);
        return i;
}

static int remove_by_index(void *ctx, void *node)
{
        int *index = (int *)ctx;
        if (*index > 0) {
                *index -= 1;
                return 0;
        }
        else if (*index == 0) {
                *index -= 1;
                return 1;
        }
        return -1;
}

int list_remove_at(struct list_t *list, int index)
{
        return list_remove_if(list, remove_by_index, &index);
}

void list_traverse(const struct list_t *list, traverse_fn t, void *ctx)
{
        const struct node_t *node;

        list_lock(list);
        for (node = list->head; node; node = node->next) {
                if (t(ctx, node->item) == 0) {
                        break;
                }
        }
        list_unlock(list);
}

void list_rtraverse(const struct list_t *list, traverse_fn t, void *ctx)
{
        const struct node_t *node;

        list_lock(list);
        for (node = list->tail; node; node = node->prev) {
                if (t(ctx, node->item) == 0) {
                        break;
                }
        }
        list_unlock(list);
}

