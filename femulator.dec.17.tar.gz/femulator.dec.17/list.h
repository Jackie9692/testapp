#ifndef LIST_TEST
#include "base.h"
#endif

#ifndef __LIST_H__
#define __LIST_H__

struct node_t;

struct list_t {
        struct node_t *head;
        struct node_t *tail;
#ifdef CONFIG_SMP
        struct semaphore lock;
#endif
};

typedef int (*traverse_fn)(void *ctx, void *node);
typedef int (*remove_fn)(void *ctx, void *node);

struct list_t *create_list(void);
void free_list(struct list_t *list);
int list_length(const struct list_t *list);
void *list_item_if(const struct list_t *list, traverse_fn t, void *ctx);
void *list_item_at(const struct list_t *list, int index);
int list_insert_at(struct list_t *list, int index, void *item);
int list_rinsert_at(struct list_t *list, int rindex, void *item);
int list_remove_if(struct list_t *list, remove_fn rm, void *ctx);
int list_remove_at(struct list_t *list, int index);
void list_traverse(const struct list_t *list, traverse_fn t, void *ctx);
void list_rtraverse(const struct list_t *list, traverse_fn t, void *ctx);

#endif

