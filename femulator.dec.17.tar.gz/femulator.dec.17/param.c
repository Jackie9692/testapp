#include "base.h"
#include <asm/uaccess.h>

struct eq_t {
        int type; // 0 for value, 1 for string
        void *value;
};

#define STRING_MAX 511

void *on_eq_create(const char *param)
{
        void *ret;
        if (param && param[0] == '\"') {
                int len = strlen(param);
                if (len < 2 || len - 2 > STRING_MAX) {
                        log_warning("too short/long param %s", param);
                        return NULL;
                }
                if (param[len-1] != '\"') {
                        log_warning("param is not a string %s", param);
                        return NULL;
                }
                ret = mmalloc(sizeof(struct eq_t) + len-1);
                if (ret == NULL)
                        return NULL;
                ((struct eq_t *)ret)->value = (char *)ret + sizeof(struct eq_t);
                ((struct eq_t *)ret)->type = 1;
                memcpy(((struct eq_t *)ret)->value, param+1, len-2);
                ((char *)((struct eq_t *)ret)->value)[len-2] = '\0';
                return ret;
        }
        else {
                unsigned long val;
                if (param[0] != '0') { // decimal
                        if (sscanf(param, "%lu", &val) != 1) {
                                log_warning("param is not a decimal value %s", param);
                                return NULL;
                        }
                }
                else if (param[0] == '0' && param[1] == 'x') { // hexadecimal
                        if (sscanf(param, "%lx", &val) != 1) {
                                log_warning("param is not a hexadecimal value %s", param);
                                return NULL;
                        }
                }
                else if (param[0] == '0') { // try as octal
                        if (sscanf(param, "%lo", &val) != 1) {
                                log_warning("param is not a decimal value %s", param);
                                return NULL;
                        }
                }
                else {
                        log_warning("param is not a value %s", param);
                        return NULL;
                }
                ret = mmalloc(sizeof(struct eq_t));
                if (ret == 0)
                        return NULL;
                ((struct eq_t *)ret)->type = 0;
                ((struct eq_t *)ret)->value = (void *)val;
                return ret;
        }

        return NULL;
}

int on_eq_judge(int pos, void *value, struct base_t *b)
{
        struct eq_t *eq = value;
        if (eq->type == 0) {
                unsigned long arg = (unsigned long)call_arg(b->fname, pos);
                if (arg == (unsigned long)eq->value)
                        return 1;
        }
        else {
                int ret;
                char buf[STRING_MAX+1];

                ret = _strncpy_from_user(buf, (char *)call_arg(b->fname, pos), STRING_MAX+1);
                if (ret < 0) {
                        log_error("can not copy string from %p", (char *)call_arg(b->fname, pos));
                        return 0;
                }
                if (ret == STRING_MAX+1) {
                        buf[STRING_MAX] = '\0';
                        log_warning("string to long %s", buf);
                        return 0;
                }
                if (strcmp(buf, eq->value) == 0)
                        return 1;
        }

        return 0;
}

void on_eq_destroy(void *value)
{
        if (value)
                mfree(value);
}

