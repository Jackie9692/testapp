#ifndef __PARAM_H__
#define __PARAM_H__

#include "base.h"

void *on_eq_create(const char *param);
int on_eq_judge(int pos, void *value, struct base_t *b);
void on_eq_destroy(void *value);

#endif

