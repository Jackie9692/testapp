#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>

int fd;

void *load(void *arg)
{
        int ret;
        char buf[32];

        errno = 0;
        while (1) {
                ret = read(fd, buf, 32);
                if (ret < 0) {
                        //printf("errno: %d\n", errno);
                }
        }
}

void *load2(void *arg)
{
        int ret;
        char buf[32];

        while (1) {
        fd = open("exist", 0);
        ret = read(fd, buf, 32);
                        printf("errno: %d\n", errno);
        if (fd > 0)
                close(fd);
        }
}

int main(int argc, char *argv[])
{
        pthread_t pid[4];

        fd = open("exist", 0);
        if (fd < 0) {
                perror("open");
                return -1;
        }
        if (pthread_create(pid+0, NULL, load, NULL)) {
                perror("phread_create");
                return -1;
        }
        if (pthread_create(pid+1, NULL, load, NULL)) {
                perror("phread_create");
                return -1;
        }
        if (pthread_create(pid+2, NULL, load, NULL)) {
                perror("phread_create");
                return -1;
        }
        if (pthread_create(pid+3, NULL, load2, NULL)) {
                perror("phread_create");
                return -1;
        }

        while (1)
                ;

        if (fd > 0)
                close(fd);
        return 0;
}
