#include "reboot.h"
#include <linux/reboot.h>

static void post_handler(struct base_t *base, struct pt_regs *regs, unsigned long flags)
{
        kernel_restart(NULL);
}

int reboot_attacher(const struct fault *fault)
{
        struct reboot_t *reboot;

        if (strncmp(fault->param, "all", 3) == 0) {
                log_debug("dafasd");
                kernel_restart(NULL);
        }

        reboot = fault->data; 
        reboot->base.pre_handler = NULL;
        reboot->base.post_handler = post_handler;
        if (init_base_injector(&reboot->base, fault->param, NULL)) {
                log_error("init_base_injector failed");
                return -1;
        }
        notify_ready(&reboot->base);

        return 0;
}

int reboot_detacher(const struct fault *fault)
{
        notify_pause(&((struct reboot_t *const)fault->data)->base);
        free_base_injector(&((struct reboot_t *const)fault->data)->base);
        
        return 0;
}

