#ifndef __REBOOT_H__
#define __REBOOT_H__

#include "base.h"

struct reboot_t {
        struct base_t base;
};

int reboot_attacher(const struct fault *fault);
int reboot_detacher(const struct fault *fault);

#endif

