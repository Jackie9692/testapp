#include "return.h"

volatile static const int s_false = 0;
static int pre_handler(struct base_t *base, struct pt_regs *regs)
{
        struct return_t *r = (struct return_t *)base;

        if (s_false) { // sth impossible
        restorer:
                __asm__ __volatile__("ret");
        }

        current_pc(regs) = (unsigned long)&&restorer;
        return_value(regs)= r->retval;

        return 1;
}

static int parse_param(char *param, int *retval)
{
        if (sscanf(param, "%d", retval) != 1)
                return -1;

        return 0;
}

int return_attacher(const struct fault *fault)
{
        struct return_t *ret;
        const char *new_param;
        char params_store[PARAM_MAX+1], *params[1] = { NULL };

        ret = fault->data;
        ret->base.pre_handler = pre_handler;
        ret->base.post_handler = NULL;
        if (init_base_injector(&ret->base, fault->param, &new_param)) {
                log_error("init_base_injector failed");
                return -1;
        }

        strcpy(params_store, new_param);
        if (parse_params_to_list(params_store, params, 1) < 1 || \
                parse_param(params[0], &ret->retval)) {
                log_error("can not parse parameter: %s", new_param);
                free_base_injector(&ret->base);
                return -1;
        }
        notify_ready(&ret->base);

        return 0;
}

int return_detacher(const struct fault *fault)
{
        notify_pause(&((struct return_t *const)fault->data)->base);
        free_base_injector(&((struct return_t *const)fault->data)->base);

        return 0;
}

