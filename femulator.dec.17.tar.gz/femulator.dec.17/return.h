#ifndef __RETURN_H_
#define __RETURN_H_

#include "base.h"

struct return_t {
        struct base_t base;
        int retval;
};

int return_attacher(const struct fault *fault);
int return_detacher(const struct fault *fault);

#endif

