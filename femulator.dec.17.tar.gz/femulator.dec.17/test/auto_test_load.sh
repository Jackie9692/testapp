#!/bin/bash

LONG_BIT=`getconf LONG_BIT`
linux_version=`uname -r | grep -o 2\.6\.[0-9][0-9]`
map=
if [ $LONG_BIT -eq 32 ]; then
        if [ $linux_version = "2.6.34" ]; then
                map="../lib/map32.34"
        elif [ $linux_version = "2.6.32" ]; then
                map="../lib/map32.32"
        elif [ $linux_version = "2.6.16" ]; then
                map="../lib/map32.16"
        fi
else
        if [ $linux_version = "2.6.34" ]; then
                map="../lib/map64.34"
        elif [ $linux_version = "2.6.32" ]; then
                map="../lib/map64.32"
        elif [ $linux_version = "2.6.16" ]; then
                map="../lib/map64.16"
        fi
fi

while read line; do
        i=0
        for var in $line; do
                if [ $i -eq 0 ]; then
                        id=$var
                elif [ $i -eq 1 ]; then
                        func=$var
                elif [ $i -eq 2 ]; then
                        retval=$var
                elif [ $i -eq 3 ]; then
                        method=$var
                fi
                i=$(($i + 1))
        done
        #if [ $method -ne 1 -a $method -ne 2 ]; then
        if [ $method -ne 1 ]; then
                echo skip $id
                continue
        fi
        if [ $method -eq 1 -a $retval -gt 0 ]; then
                retval=$(($retval * -1))
        fi
        #(
        #flock -x 200
        if [ "${func:0:3}" = "do_" ]; then
                #./syscall_test_load.sh $method $id ${func:3} $retval $func >/dev/null 2>&1
                ./syscall_test_load.sh $method $id ${func:3} $retval $func
        else # sys_
                #./syscall_test_load.sh $method $id ${func:4} $retval $func
                ./syscall_test_load.sh $method $id ${func:4} $retval $func >/dev/null 2>&1
        fi
        #) 200>/var/lock/mylockfile1

        if [ $? -eq 0 ]; then
                echo id: $id Success
        elif [ $? -eq 2 ]; then
                echo id: $id: $func not found
        else
                echo id: $id Failed @ $func
        fi
        #echo "$id $func $retval"
done < $map

