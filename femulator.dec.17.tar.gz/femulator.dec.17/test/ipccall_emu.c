#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/net.h>

int main(int argc, char *argv[])
{
        int flag;
        char *callname;
        int method, ret, retval, myerrno;
        struct timeval before, after;

        if (argc < 3) {
                puts("usage: sockcall_emu <ipccall> <retval>");
                return -1;
        }
        method = atoi(argv[1]);
        callname = argv[2];
        retval = atoi(argv[3]);

        ret = -1;
        errno = 0;
        flag = htonl(*(int *)callname);
        gettimeofday(&before, NULL);
        switch (flag)
        {
        case (int)'semt':
                ret = semtimedop(0x12345678, 0, 0);
                break;
        case (int)'semg':
                ret = semget(0x12345678, 0, 0);
                break;
        case (int)'semc':
                ret = semctl(0x12345678, 0, 0);
                break;
        case (int)'msgc':
                ret = msgctl(0x12345678, 0, 0);
                break;
        case (int)'msgg':
                ret = msgget(0x12345678, 0, 0);
                break;
        case (int)'msgs':
                ret = msgsnd(0x12345678, 0, 0);
                break;
        case (int)'msgr':
                ret = msgrcv(0x12345678, 0, 0);
                break;
        case (int)'shma':
                ret = shmat(0x12345678, 0, 0);
                break;
        case (int)'shmd':
                ret = shmdt(0x12345678, 0, 0);
                break;
        case (int)'shmg':
                ret = shmget(0x12345678, 0, 0);
                break;
        case (int)'shmc':
                ret = shmctl(0x12345678, 0, 0);
                break;
        }
        gettimeofday(&after, NULL);

        if (method == 1) {
                myerrno = errno;
                printf("return: %d errno: %d\n", ret, myerrno);
                perror("ipccall");
        }
        else if (method == 2) {
                int ms;
                double p;
                ms = (after.tv_sec - before.tv_sec) * 1000000;
                ms += after.tv_usec - before.tv_usec;
                p = (ms / 1000 - retval) / (double)retval;
                printf("delay: %d, actual delay: %d(%lf)\n", retval, ms/1000, p);
                if (p > 0.05 && p < -0.05) {
                        return -1;
                }
                return 0;
        }

        if (retval < 0 && myerrno != retval*-1) {
                return -1;
        }

        return 0;
}

