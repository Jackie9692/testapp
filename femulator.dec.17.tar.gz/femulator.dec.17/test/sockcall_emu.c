#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char *argv[])
{
        int flag;
        char *callname;
        int method, ret, retval, myerrno;
        struct timeval before, after;

        if (argc < 3) {
                puts("usage: sockcall_emu <method> <sockcall> <retval>");
                return -1;
        }
        method = atoi(argv[1]);
        callname = argv[2];
        retval = atoi(argv[3]);

        ret = -1;
        errno = 0;
        if (strcmp(callname, "sendto") == 0)
                callname = "sent";
        else if (strcmp(callname, "recvfrom") == 0)
                callname = "recf";
        else if (strcmp(callname, "sendmsg") == 0)
                callname = "senm";
        else if (strcmp(callname, "recvmsg") == 0)
                callname = "recm";
        else if (strcmp(callname, "socketpair") == 0)
                callname = "socp";
        else if (strcmp(callname, "getsockopt") == 0)
                callname = "geto";

        flag = htonl(*(int *)callname);
        gettimeofday(&before, NULL);
        switch (flag)
        {
        case (int)'sock':
                ret = socket(0, 0, 0);
                break;
        case (int)'bind':
                ret = bind(0, 0, 0);
                break;
        case (int)'conn':
                ret = connect(0, 0, 0);
                break;
        case (int)'list':
                ret = listen(0, 0, 0);
                break;
        case (int)'acce':
                ret = accept(0, 0, 0);
                break;
        case (int)'gets':
                ret = getsockname(0, 0, 0);
                break;
        case (int)'getp':
                ret = getpeername(0, 0, 0);
                break;
        case (int)'socp':
                ret = socketpair(0, 0, 0);
                break;
        case (int)'send':
                ret = send(0, 0, 0);
                break;
        case (int)'recv':
                ret = recv(0, 0, 0);
                break;
        case (int)'sent':
                ret = sendto(0, 0, 0);
                break;
        case (int)'recf':
                ret = recvfrom(0, 0, 0);
                break;
        case (int)'shut':
                ret = shutdown(0, 0, 0);
                break;
        case (int)'sets':
                ret = setsockopt(0, 0, 0);
                break;
        case (int)'geto':
                ret = getsockopt(0, 0, 0);
                break;
        case (int)'senm':
                ret = sendmsg(0, 0, 0);
                break;
        case (int)'recm':
                ret = recvmsg(0, 0, 0);
                break;
        }
        gettimeofday(&after, NULL);

        if (method == 1) {
                myerrno = errno;
                printf("return: %d errno: %d\n", ret, myerrno);
                perror("sockcall");
        }
        else if (method == 2) {
                int ms;
                double p;
                ms = (after.tv_sec - before.tv_sec) * 1000000;
                ms += after.tv_usec - before.tv_usec;
                p = (ms / 1000 - retval) / (double)retval;
                printf("delay: %d, actual delay: %d(%lf)\n", retval, ms/1000, p);
                if (p > 0.05 && p < -0.05) {
                        return -1;
                }
                return 0;
        }

        if (retval <= 0 && myerrno != retval*-1) {
                return -1;
        }

        return 0;
}

