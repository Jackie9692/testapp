#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

static char grep_word[256];
static char buffer[256];

int main(int argc, char *argv[])
{
        FILE *fp;
        char *filename;
        int method, ret, num, retval, fd, fd_pos, myerrno;
        struct timeval before, after;
        if (argc < 4) {
                puts("usage: syscall_emu <method> <sys_call_num> <retval> [filename] [position]");
                return -1;
        }
        filename = NULL;
        fd = -1;
        fd_pos = 0;
        method = atoi(argv[1]);
        num = atoi(argv[2]);
        retval = atoi(argv[3]);
        if (argc == 6) {
                filename = argv[4];
                fd_pos = atoi(argv[5]);
        }

        if (filename) {
                fd = open(filename, O_CREAT);
                if (fd == -1) {
                        perror("open");
                        return -1;
                }
        }

        //printf("fd_pos: %d\n", fd_pos);
        errno = 0;
        gettimeofday(&before, NULL);
        //switch (fd_pos) {
        //case 1:
        //        ret = syscall(num, fd, 0x55667788, 0x99aabbcc, 0xddeeff00, 0x12345678, 0x9abcdef0);
        //        break;
        //case 2:
        //        ret = syscall(num, 0x11223344, fd, 0x99aabbcc, 0xddeeff00, 0x12345678, 0x9abcdef0);
        //        break;
        //case 3:
        //        ret = syscall(num, 0x11223344, 0x55667788, fd, 0xddeeff00, 0x12345678, 0x9abcdef0);
        //        break;
        //case 4:
        //        ret = syscall(num, 0x11223344, 0x55667788, 0x99aabbcc, fd, 0x12345678, 0x9abcdef0);
        //        break;
        //case 5:
        //        ret = syscall(num, 0x11223344, 0x55667788, 0x99aabbcc, 0xddeeff00, fd, 0x9abcdef0);
        //        break;
        //case 6:
        //        ret = syscall(num, 0x11223344, 0x55667788, 0x99aabbcc, 0xddeeff00, 0x12345678, fd);
        //        break;
        //default:
        //        ret = syscall(num, 0x11223344, 0x55667788, 0x99aabbcc, 0xddeeff00, 0x12345678, 0x9abcdef0);
        //        break;
        //}
        printf("calling syscall\n");
        ret = syscall(num, 0x11223344, 0x55667788, 0x99aabbcc, 0xddeeff00, 0x12345678, 0x9abcdef0);
        gettimeofday(&after, NULL);

        if (method == 1) {
                myerrno = errno;
                printf("return: %d errno: %d\n", ret, myerrno);
                perror("syscall");
        }
        else if (method == 2) {
                int ms;
                double p;
                ms = (after.tv_sec - before.tv_sec) * 1000000;
                ms += after.tv_usec - before.tv_usec;
                p = (ms / 1000 - retval) / (double)retval;
                printf("delay: %d, actual delay: %d(%lf)\n", retval, ms/1000, p);
                if (p > 0.05 || p < -0.05) {
                        return -1;
                }
                return 0;
        }

        if (fd > 0 && close(fd) < 0) {
                perror("warning: close");
        }

        if (retval < 0 && myerrno != retval*-1) {
                return -1;
        }

        return 0;
}

