#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

char g_headers[] = "\
#include <errno.h>\n\
#include <stdio.h>\n\
#include <fcntl.h>\n\
#include <unistd.h>\n\
#include <sched.h>\n\
#include <signal.h>\n\
#include <poll.h>\n\
#include <sys/types.h>\n\
#include <sys/stat.h>\n\
#include <sys/file.h>\n\
#include <sys/mount.h>\n\
#include <sys/wait.h>\n\
#include <sys/ipc.h>\n\
#include <sys/shm.h>\n\
#include <sys/prctl.h>\n\
#include <sys/mman.h>\n\
#include <sys/utsname.h>\n\
#include <sys/socket.h>\n\
#include <sys/sendfile.h>\n\
#include <sys/uio.h>\n\
#include <sys/personality.h>\n\
#include <sys/ptrace.h>\n\
#include <sys/reboot.h>\n\
#include <dirent.h>\n\
//#include <sys/capability.h>\n\
";

int main(int argc, char *argv[])
{
        int fd, ret, retval;
        FILE *fp;
        char *pch;
        char *function = argv[1];
        char *headers = argv[2];
        char *parameters = argv[3];
        char tmpname[] = P_tmpdir"/gen.XXXXXX";
        char cmd[256] = {0};
        int first_blood = 1;

        if (argc < 5) {
                puts("usage: <function> <headers> <parameters> <retval>");
                return -1;
        }

        retval = atoi(argv[4]);
        if ((fd = mkstemp(tmpname)) == -1) {
                perror("tmpfile");
                return -1;
        }
        if ((fp = fdopen(fd, "w+")) == NULL) {
                close(fd);
                perror("fdopen");
                return -1;
        }
        //printf("filename: %s\n", tmpname);

        fputs(g_headers, fp);
        pch = strtok(headers, ",");
        while (pch != NULL) {
                fprintf(fp, "#include <%s>\n", pch);
                pch = strtok(NULL, ",");
        }
        fputs("int main(int argc, char *argv[]) { int ret, err; errno = 0; ", fp);

        fprintf(fp, "ret = (int)%s(", function);
        pch = strtok(parameters, ",");
        while (pch != NULL) {
                if (strcmp(pch, "void") == 0) {
                        fputs(", ", fp);
                        break;
                }
                if (first_blood)
                        fprintf(fp, "(%s)(0x12345678), ", pch);
                else
                        fprintf(fp, "(%s)(0x0), ", pch);
                first_blood = 0;
                pch = strtok(NULL, ",");
        }
        fseek(fp, -2, SEEK_CUR);
        fprintf(fp, "); \
                err = errno; \
                perror(\"%s\"); \
                printf(\"ret: %%d, errno: %%d\\n\", ret, err); \
                if (err == %d) return 0; else return -1; }\n", function, retval*-1);

        fflush(fp);

        sprintf(cmd, "cat %s", tmpname);
        system(cmd);

        sprintf(cmd, "gcc -xc %s", tmpname);
        ret = system(cmd);
        unlink(tmpname);
        fclose(fp);

        if (WEXITSTATUS(ret) != 0) {
                return -1;
        }

        ret = system("./a.out; exit #?");
        if (WEXITSTATUS(ret) != 0) {
                puts("Gen Failed");
                return -1;
        }

        puts("Gen Success");
        return 0;
}
