#!/bin/bash

func=$1
retval=$2
found=0

while read line; do
        i=0
        func_=`echo "$line" | awk -F':' '{print $1}'`
        headers=`echo "$line" | awk -F':' '{print $2}'`
        if [ -z "$header" ]; then
                headers="stdio.h"
        fi
        parameters=`echo "$line" | awk -F':' '{print $3}'`
        if [[ "$func_" = "$func" ]]; then
                found=1
                break
        fi
done < "function.list"

if [ $found -eq 0 ]; then
        echo "can not find $func"
        exit 1;
fi

#echo "./syscall_gen $func $headers $parameters $retval"
./syscall_gen $func "$headers" "$parameters" $retval
exit $?

