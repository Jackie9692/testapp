#!/bin/bash

LONG_BIT=`getconf LONG_BIT`
uname=`uname -r`
fname=""

method=$1
id=$2
function=sys_$3
retval=$4
ori_func=$5
filename=$6
socket=0
ipc=0

bus_path="/sys/bus/fi_pseudo_bus"

if [ $LONG_BIT -eq 32 ]; then
    if `echo $uname | grep -q "2.6.16"`; then
        fname="unistd_32_16.h"
    elif `echo $uname | grep -q "2.6.32"`; then
        fname="unistd_32_32.h"
    else
        fname="unistd_32_34.h"
    fi
else
    if `echo $uname | grep -q "2.6.16"`; then
        fname="unistd_64_16.h"
    elif `echo $uname | grep -q "2.6.32"`; then
        fname="unistd_64_32.h"
    else
        fname="unistd_64_34.h"
    fi
fi
echo $fname
if [ $LONG_BIT -eq 32 -a \( \
        "$function" == "sys_socket" -o \
        "$function" == "sys_bind" -o \
        "$function" == "sys_connect" -o \
        "$function" == "sys_listen" -o \
        "$function" == "sys_accept" -o \
        "$function" == "sys_accept4" -o \
        "$function" == "sys_getsockname" -o \
        "$function" == "sys_getpeername" -o \
        "$function" == "sys_socketpair" -o \
        "$function" == "sys_send" -o \
        "$function" == "sys_recv" -o \
        "$function" == "sys_sendto" -o \
        "$function" == "sys_recvfrom" -o \
        "$function" == "sys_shutdown" -o \
        "$function" == "sys_setsockopt" -o \
        "$function" == "sys_getsockopt" -o \
        "$function" == "sys_sendmsg" -o \
        "$function" == "sys_recvmsg" \) ]; then
        if [ "$function" = "sys_accept4" ]; then
                function="sys_accept"
        fi
        pname="sockcall_emu"
        socket=1
elif [ $LONG_BIT -eq 32 -a \( \
        "$function" == "sys_semtimedop" -o \
        "$function" == "sys_semget" -o \
        "$function" == "sys_semctl" -o \
        "$function" == "sys_msgctl" -o \
        "$function" == "sys_msgget" -o \
        "$function" == "sys_msgsnd" -o \
        "$function" == "sys_msgrcv" -o \
        "$function" == "sys_shmat" -o \
        "$function" == "sys_shmdt" -o \
        "$function" == "sys_shmget" -o \
        "$function" == "sys_shmctl" \) ]; then
        pname="ipccall_emu"
        ipc=1
else
        if [ "$function" = "sys_newstat" ]; then
                function="sys_stat"
        fi
        if [ "$function" = "sys_newfstat" ]; then
                function="sys_fstat"
        fi
        if [ "$function" = "sys_newuname" ]; then
                function="sys_uname"
        fi
        if [ "$function" = "sys_umount" ]; then
                function="sys_umount2"
        fi
        if [ "$function" = "sys_mmap_pgoff" ]; then
                function="sys_mmap2"
        fi
        if [ $LONG_BIT -eq 64 -a "$function" = "sys_sendfile64" ]; then
                function="sys_sendfile"
        fi
        syscall=`grep -E "#define __NR_${function:4}[[:space:]]+[0-9]*$" $fname | grep -o "[0-9]*\$"`
        if [ -z "$syscall" ]; then
                echo $function not found
                exit 1;
        fi
        pname="syscall_emu"
        echo $function: $syscall
fi

if [ $# -eq 6 ]; then
        echo lalala
else
        cd ..
        ret=1
        param=""
        if [ $socket -eq 1 ]; then
                ./fish -i $id -n $pname
                #./fish -i $id -n $pname -s
                #cat /sys/bus/fi_pseudo_bus/query
        elif [ $ipc -eq 1 ]; then
                ./fish -i $id -n $pname -T2
                #./fish -i $id -n $pname -T2 -s
                #cat /sys/bus/fi_pseudo_bus/query
        else
                ./fish -i $id -n $pname -T1
                #./fish -i $id -n $pname -T1 -s
                #cat /sys/bus/fi_pseudo_bus/query
        fi
        ret=$?
        if [ $ret -ne 0 ]; then
                exit 1;
        fi
        cd test
fi

if [ $socket -eq 1 ]; then
        ./sockcall_emu $method ${function:4} $retval
elif [ $ipc -eq 1 ]; then
        ./ipccall_emu $method ${function:4} $retval
elif [ $# -eq 6 ]; then
        ./syscall_emu $method $syscall $retval $filename $4
else
        ./syscall_emu $method $syscall $retval
fi

if [ $? -eq 0 ]; then
        echo Success
else
        cd ..
        ./fish -i $id -n $pname -m
        cd test
        exit 1;
fi

cd ..
./fish -i $id -n $pname -m
cd test

