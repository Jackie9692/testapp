#!/bin/bash

LONG_BIT=`getconf LONG_BIT`
uname=`uname -r`
fname=""

method=$1
id=$2
function=$3
retval=$4
ori_func=$5
filename=$6
socket=0
ipc=0
pname="a.out"

socket=0
ipc=0

if [ $LONG_BIT -eq 32 -a \( \
        "$function" == "socket" -o \
        "$function" == "bind" -o \
        "$function" == "connect" -o \
        "$function" == "listen" -o \
        "$function" == "accept" -o \
        "$function" == "accept4" -o \
        "$function" == "getsockname" -o \
        "$function" == "getpeername" -o \
        "$function" == "socketpair" -o \
        "$function" == "send" -o \
        "$function" == "recv" -o \
        "$function" == "sendto" -o \
        "$function" == "recvfrom" -o \
        "$function" == "shutdown" -o \
        "$function" == "setsockopt" -o \
        "$function" == "getsockopt" -o \
        "$function" == "sendmsg" -o \
        "$function" == "recvmsg" \) ]; then
        if [ "$function" = "accept4" ]; then
                function="accept"
        fi
        socket=1
elif [ $LONG_BIT -eq 32 -a \( \
        "$function" == "semtimedop" -o \
        "$function" == "semget" -o \
        "$function" == "semctl" -o \
        "$function" == "msgctl" -o \
        "$function" == "msgget" -o \
        "$function" == "msgsnd" -o \
        "$function" == "msgrcv" -o \
        "$function" == "shmat" -o \
        "$function" == "shmdt" -o \
        "$function" == "shmget" -o \
        "$function" == "shmctl" \) ]; then
        ipc=1
fi
if [ $function == "newstat" ]; then
        function="stat"
fi
if [ $function == "stat64" ]; then
        function="stat"
fi
if [ $function == "newfstat" ]; then
        function="fstat"
fi
if [ $function == "fstat64" ]; then
        function="fstat"
fi
if [ $function == "fcntl64" ]; then
        function="fcntl"
fi
if [ $function == "wait4" ]; then
        function="wait"
fi
if [ $function == "newuname" ]; then
        function="uname"
fi
if [ $function == "rt_sigaction" ]; then
        function="sigaction"
fi
if [ $function == "rt_sigprocmask" ]; then
        function="sigprocmask"
fi
if [ $function == "rt_sigprocmask" ]; then
        function="sigprocmask"
fi
if [ $function == "rt_sigsuspend" ]; then
        function="sigsuspend"
fi
if [ $function == "sendto" ]; then
        function="send"
fi
if [ $function == "recvfrom" ]; then
        function="recv"
fi
if [ $function == "sendfile64" ]; then
        function="sendfile"
fi
if [ $function == "mmap2" ]; then
        function="mmap"
fi

if [ $# -eq 6 ]; then
        echo lalala
else
        cd ..
        ret=1
        param=""
        if [ $socket -eq 1 ]; then
                ./fish -i $id -n $pname
        elif [ $function == "wait" ]; then
                ./fish -i $id -n $pname -T2
        elif [ $ipc -eq 1 ]; then
                ./fish -i $id -n $pname -T2
        else
                ./fish -i $id -n $pname -T3
        fi
        ret=$?
        if [ $ret -ne 0 ]; then
                exit 1;
        fi
        echo -n 0 > "/sys/bus/fi_pseudo_bus/hash"
        cat "/sys/bus/fi_pseudo_bus/query"
        cd test
fi

./syscall_gen.sh $function $retval
ret=$?
echo -n 0 > "/sys/bus/fi_pseudo_bus/hash"
cat "/sys/bus/fi_pseudo_bus/query"

if [ $ret -eq 0 ]; then
        echo Success
else
        cd ..
        ./fish -i $id -n $pname -m
        cd test
        exit 1;
fi

cd ..
./fish -i $id -n $pname -m
cd test

